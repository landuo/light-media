#!/usr/bin/env python3
"""Prepared original whole transfer-method material witness, real fixed native codec, recording ports."""
from __future__ import annotations
import ast,base64,collections.abc,copy,gzip,hashlib,json,os,sys,typing
from pathlib import Path,PurePosixPath
from types import SimpleNamespace
ROOT=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305')
HERE=ROOT/'source-collectors/material-large01/s02-annex01'
VENDOR=ROOT/'source-runtime/material-large-deps01/unpacked'
assert sys.flags.isolated and sys.flags.no_site and sys.flags.dont_write_bytecode and len(sys.argv)==1
class CollectorBoundary(BaseException):pass
def require(ok,message):
    if not ok:raise CollectorBoundary(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def check_inputs():
    raw=(HERE/'input-bindings.json').read_bytes();m=json.loads(raw)
    for r in m['inputs']:
        b=Path(r['path']).read_bytes();require(len(b)==r['bytes'] and sha(b)==r['sha256'],'input drift: '+r['path'])
    for p in m['absent_cache_paths']:require(not Path(p).exists(),'unexpected bytecode cache')
    return m,sha(raw)
def absent():
    prefixes=('app','requests','urllib3','socket','_socket','ssl','qbittorrentapi','transmission_rpc','torrentool','bencode.bencode')
    require(not any(n==p or n.startswith(p+'.') for n in sys.modules for p in prefixes),'forbidden package/fallback imported')
absent();manifest,manifest_sha=check_inputs();node_spec=json.loads((HERE/'source-nodes.json').read_text());recipes=json.loads((HERE/'owned-inputs.json').read_text())
READS={str(Path(r['path']).resolve()) for r in manifest['inputs']}|set(manifest['absent_cache_paths'])|{str((HERE/'input-bindings.json').resolve())}
REJECT=[]
def audit(event,args):
    if event=='import' and any(args[0]==p or args[0].startswith(p+'.') for p in ('bencode.bencode','requests','urllib3','socket','_socket','ssl','app','qbittorrentapi','transmission_rpc','torrentool')):
        REJECT.append(event+':'+args[0]);raise CollectorBoundary('forbidden import before initialization')
    if event=='open':
        p,mode,flags=args
        ok=isinstance(p,(str,bytes,os.PathLike)) and str(Path(os.fsdecode(p)).resolve()) in READS
        ok=ok and (mode is None or not any(c in mode for c in 'wax+')) and not(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if not ok:REJECT.append(event);raise CollectorBoundary('unapproved read/write')
    elif event.startswith(('socket.','subprocess.','ctypes.')) or event in ('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','os.putenv','os.unsetenv','os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.link','os.symlink','os.truncate'):
        REJECT.append(event);raise CollectorBoundary('forbidden side effect: '+event)
sys.addaudithook(audit)
sys.path.insert(0,str(VENDOR))
from bencode import bdecode as REAL_DECODE,bencode as REAL_ENCODE
require(not REJECT,'native initialization swallowed an audit rejection')
require(REAL_DECODE.__module__=='bencode._bencode' and REAL_ENCODE.__module__=='bencode._bencode','real native fast-bencode required, never fallback')
require(Path(sys.modules['bencode._bencode'].__file__).resolve()==VENDOR/'bencode/_bencode.cpython-312-x86_64-linux-gnu.so','native module path differs')
require(sha(Path(sys.modules['bencode._bencode'].__file__).read_bytes())=='cb1d8b537741f3fe8835c7d08644c874ff60cfda48d9c1be14042bd8c0171854','native module bytes differ')
absent();TRACE=[];LOGS=[]
def normal(v):
    if type(v) is bytes:return {'type':'bytes','length':len(v),'sha256':sha(v)}
    if type(v) is str and len(v)>4096:
        b=v.encode();return {'type':'str','characters':len(v),'utf8_bytes':len(b),'sha256':sha(b)}
    if type(v) is dict:
        require(all(type(k)is str for k in v),'unselected dict key');return {k:normal(x) for k,x in v.items()}
    if type(v) is tuple:return {'type':'tuple','items':[normal(x) for x in v]}
    if type(v) is list:return [normal(x) for x in v]
    require(v is None or type(v) in (str,bool,int,float),'unselected value type');return v
def record(op,**fields):TRACE.append({'op':op,**normal(fields)})
def bdecode(value):
    record('codec.bdecode.call',value=value)
    result=REAL_DECODE(value);record('codec.bdecode.return',value=result);return result
def bencode(value):
    record('codec.bencode.call',value=value)
    result=REAL_ENCODE(value);record('codec.bencode.return',value=result);return result
def build_input(recipe):
    require(recipe['repeat_ascii']=='x' and recipe['repeat_count']==(16<<20)+1,'fixed finite input changed')
    raw=base64.b64decode(recipe['prefix_base64'],validate=True)+b'x'*recipe['repeat_count']+base64.b64decode(recipe['suffix_base64'],validate=True)
    require(len(raw)==recipe['bytes'] and sha(raw)==recipe['sha256'],'input recipe digest differs');return raw
HASH='1'*40;NEW_HASH='2'*40;BACKUP='/backup/'+HASH+'.torrent';RESUME='/backup/'+HASH+'.fastresume';TEMP='/temp/'+HASH+'.torrent'
FS={BACKUP:build_input(recipes['torrent']),RESUME:build_input(recipes['resume'])};BEFORE={k:normal(v) for k,v in FS.items()}
class RecordingPath:
    def __init__(self,p):self.path=str(p)
    def __truediv__(self,name):return RecordingPath(str(PurePosixPath(self.path)/name))
    def __str__(self):return self.path
    def exists(self):
        require(self.path in ('/backup',BACKUP,RESUME,TEMP),'unselected FS path');value=self.path=='/backup' or self.path in FS
        record('fs.exists',path=self.path,value=value);return value
    def read_bytes(self):
        require(self.path in (BACKUP,RESUME,TEMP) and self.path in FS,'unselected FS read')
        value=FS[self.path];record('fs.read',path=self.path,value=value);return value
    def write_bytes(self,value):
        require(self.path==TEMP and type(value)is bytes,'unselected FS write')
        record('fs.write',path=self.path,value=value);FS[self.path]=value;return len(value)
class Logger:
    def __getattr__(self,level):
        require(level in ('info','warn','warning','error'),'unselected log')
        def emit(message):LOGS.append({'level':level,'message':str(message)});record('log',level=level,message=str(message))
        return emit
TORRENT={'hash':HASH,'save_path':'/source/data','tags':'owned','category':'owned','state':'pausedUP','progress':1,'amount_left':0}
class SourcePort:
    def is_inactive(self):record('source.is_inactive');return False
    def get_completed_torrents(self):record('source.get_completed_torrents');return [copy.deepcopy(TORRENT)]
class DestinationPort:
    def is_inactive(self):record('destination.is_inactive');return False
    def get_torrents(self,ids):require(ids==[HASH],'unselected lookup');record('destination.get_torrents',ids=ids);return [],False
    def add_torrent(self,**kwargs):record('destination.add_torrent',kwargs=kwargs);return True,[]
    def get_torrent_id_by_tag(self,tags):require(tags=='r'*10,'unselected tag');record('destination.get_torrent_id_by_tag',tags=tags);return NEW_HASH
SERVICES={'source':SimpleNamespace(name='source',type='qbittorrent',instance=SourcePort()),'destination':SimpleNamespace(name='destination',type='qbittorrent',instance=DestinationPort())}
class DownloaderHelper:
    def get_service(self,name):require(name in SERVICES,'unselected service');record('helper.get_service',name=name);return SERVICES[name]
    def is_downloader(self,name,service):require(name in ('qbittorrent','transmission'),'unselected type');record('helper.is_downloader',name=name,service=service.name);return name==service.type
class EventPort:
    def is_set(self):record('event.is_set',value=False);return False
class StringPort:
    @staticmethod
    def generate_random_str(n):require(n==10,'unselected random input');record('random.generate',n=n);return 'r'*n
def forbidden(*args,**kwargs):raise CollectorBoundary('unexpected source branch/dependency')
def save_data(**kwargs):record('storage.save_data',kwargs=kwargs)
source=Path(node_spec['path']);raw=source.read_bytes();require(sha(raw)==node_spec['sha256'],'original plugin drift')
text=raw.decode();original=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='TorrentTransfer');selected=[]
for expected in node_spec['nodes']:
    node=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name==expected['name'])
    require(sha(ast.dump(node,include_attributes=False).encode())==expected['ast_sha256'],'whole selected method AST differs')
    require(not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(node)),'selected method import')
    selected.append(copy.deepcopy(node))
scaffold=ast.ClassDef(name='TorrentTransfer',bases=[],keywords=[],body=selected,decorator_list=[],type_params=[])
module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),scaffold],type_ignores=[])
ns={'__name__':'__selected_transfer_material__','os':os,'Path':RecordingPath,'logger':Logger(),
    'settings':SimpleNamespace(TEMP_PATH=RecordingPath('/temp')),'DownloaderHelper':DownloaderHelper,'StringUtils':StringPort,'bdecode':bdecode,'bencode':bencode}
exec(compile(ast.fix_missing_locations(module),str(source),'exec'),ns)
obj=object.__new__(ns['TorrentTransfer'])
for k,v in recipes['instance_fields'].items():setattr(obj,k,copy.deepcopy(v))
obj._event=EventPort();obj.systemmessage=SimpleNamespace(put=forbidden);obj.save_data=save_data;obj.post_message=forbidden;obj.check_recheck=forbidden;obj._TorrentTransfer__add_recheck_torrents=forbidden
LINES=0
def budget(frame,event,arg):
    global LINES
    if event=='line' and frame.f_code.co_filename==str(source):
        LINES+=1
        if LINES>10000:raise CollectorBoundary('fatal harness source-line budget, not source business None')
    return budget
sys.settrace(budget)
try:
    try:value=obj.transfer();outcome={'kind':'return','python_type':type(value).__name__,'value':normal(value)}
    except Exception as error:outcome={'kind':'exception','class':type(error).__name__,'message':str(error)}
finally:sys.settrace(None)
after={k:normal(FS[k]) for k in (BACKUP,RESUME)}
output=None
if TEMP in FS:
    value=FS[TEMP];encoded=gzip.compress(value,mtime=0);require(gzip.decompress(encoded)==value,'actual output compression roundtrip failed')
    output={**normal(value),'recovery_encoding':'gzip-base64','gzip_base64':base64.b64encode(encoded).decode(),'gzip_bytes':len(encoded),'gzip_sha256':sha(encoded)}
absent();_,after_sha=check_inputs();require(after_sha==manifest_sha,'manifest drift')
require(not REJECT,'audit rejection occurred even if native code swallowed it')
print(json.dumps({'status':'ACTUAL_COMPLETE_ORIGINAL_TRANSFER_METHOD_SELECTED_VALID_MATERIAL','MoviePilot_dependency_commit':manifest['MoviePilot_dependency_commit'],
 'plugin_sha256':node_spec['sha256'],'python':{'version':sys.version,'executable':sys.executable},'input_manifest_sha256':manifest_sha,
 'input_recipes':recipes,'root_calls':1,'native_codec_calls':[x['op'] for x in TRACE if x['op'].startswith('codec.')],
 'outcome':outcome,'trace':TRACE,'logs':LOGS,'backup_before':BEFORE,'backup_after':after,'temporary_material_actual':output,
 'source_line_events':LINES,'input_drift':[],'audit_rejections':REJECT,'forbidden_packages_and_pure_fallback_absent':True,
 'native_codec_module':str(Path(sys.modules['bencode._bencode'].__file__).resolve()),
 'not_claimed':['real filesystem/cache/daemon','whole plugin initialization/scheduler','malformed C/overflow/UB behavior','target Go execution','source runtime unlimited physical memory']},ensure_ascii=False,indent=2))
