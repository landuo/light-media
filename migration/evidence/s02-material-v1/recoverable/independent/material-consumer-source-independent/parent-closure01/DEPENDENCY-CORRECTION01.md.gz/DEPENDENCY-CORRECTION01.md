# Dependency correction — S02 parent acceptance HOLD

This append-only correction supersedes the **current parent-acceptance conclusion**, not the historical observations, of seal `3eff82e1…`. Original seal/report/readbacks remain untouched. Adoption/push must wait for the two affected installed-worker regression roots and their independent actual review; no new source/product/Go execution occurs in this correction.

## Exact missed dependency

`internal/app/plugin_shared_local_torrent_backup_worker_test.go` is byte-identical to the old delivered test, but its execution dependencies are not: the current SDK selects `prepare_material` on the real negotiated bridge, and the current installed fixture reports `material_prepare` without allocating the legacy handle. Thus test-file hash equality is insufficient to inherit these roots as current-composition regression credit.

- `ownedLocalBackupWorkerBytes` lines179–181 still requires legacy `read=ceil(bytes/chunk)`, `release=1`, and `total=reads+2`.
- `ownedLocalBackupWorkerWarm` lines193–196 still unconditionally requires `PriorReleasedHandleDenied`.
- Current fixture only emits that field when a real legacy released handle exists; the material path has no such handle. Requiring it is not a valid material observation, and fabricating a released-handle observation or counting private material frames as ordinary read/release would be incorrect.

Affected roots are exactly:
1. `TestSharedLocalTorrentBackupActualWorkerRecoveryAndScopes` — source original/rebuilt bytes, missing-resume repair, malformed material skip/repair, configured-downloader refusal followed by recovery, same-worker identity, expired prior callback denial, source WARNs and unchanged backup/temp bytes.
2. `TestSharedLocalTorrentBackupActualWorkerPagedAndCold` — complete bytes, successful nonnil empty input, same-worker scope, retained deterministic temp, cold new worker/configuration and backup preservation.

These assertions contain useful business/authority/regression coverage and must not be removed because the new large-material roots passed. Correct only material-vs-legacy observations while retaining all original behavior/safety assertions; retain the old file/preimage and historical actual results. Do not label an absent legacy handle as denied in material mode. TLS is assigned exact test delta/gate and actual evidence review; this parent reviewer will attach that final proof in successor seal02.

## What remains valid / what is pending

The fixed S02 parent scope does not expand. Source large/native observations, source→target codec/FS review, new App/SDK normal/race, ordinary CLI, unchanged age-cleanup/source selection and historical executions remain valid at their exact layers. The original `12 equal / 6 delta` direct-file count is a true byte observation, but **not sufficient evidence that these two unchanged test files' changed dependencies have been covered**.

No new implementation defect is inferred from the stale assertions and no runtime failure is fabricated: the identified old two roots have not been executed with their corrected successor yet. Whole-parent acceptance is now pending that finite regression, rather than currently accepted for publication. No NAS/daemon/browser/S03/S12 or theoretical matrix is added.
