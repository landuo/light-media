# Private spool: finite actual acceptance

**ACCEPT the frozen owned-IO component**, not material transport or consumer completion. Normal four roots and race two selected lifecycle/claim roots actually passed with no fail/skip or stderr. Original tool receipts, raw test events and exact program hashes agree. The 1,505 / 1,542 input maps match before/after compile/after test and this independent current readback; every declared input and retained generated test source is accounted for.

The normal gate exercises a 65 MiB + 1 byte owned stream, empty material, incremental SHA/length, cross-page reads and exact owned cleanup. Validation/error cases cover size, digest, offset, checked integer overflow and owned reader/write errors. Guard/cancellation and concurrency gates exercise poisoned state, no failed post-read publication, single claim and revoke/join ordering. Race acceptance is limited to its two named roots; it is not a race build of any worker.

The earlier draft remaining-length and reader-error issues were corrected before candidate01. Its exact two source files remain frozen. The adjacent `.torrent` sentinel is synthetic fixture data, not a rerun of S02; actual S02 truncate/write/final-read semantics and observable leftovers are not changed by this component. Arbitrary caller reader cancellation remains the integrating owner's responsibility.

Vet was explicitly not run. The inherited explanation is historical, not a new observed vet failure. No IPC/grant negotiation, production SDK/host/consumer, source-equivalence, physical infinity, permission/inode/symlink probe or network acceptance is inferred. The reviewer did not rerun Go or source.
