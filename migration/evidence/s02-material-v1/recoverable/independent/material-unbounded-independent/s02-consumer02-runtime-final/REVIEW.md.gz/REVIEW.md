# S02 material consumer — finite actual ACCEPT

- App normal2: session11898 / a1b4c5→4565f8 exit0; 6,431 exact inputs. Pure owned-FS/source-large comparison and real installed serial SDK-worker/cold root pass.
- Legacy SDK2: same successor candidate, 2,095 inputs; exact unnegotiated old roots pass.
- App race1: 6,440 inputs, both App test program and worker built with -race; installed-worker/cold root passes. Last two gates share outer42047 / 570d2e→ce5eaf exit0.

All before/aftercompile/aftertest maps equal independent current readback; generated source, virtual→backing declarations, actual programs and fixture SHA match. No failed/skipped root, stderr, or race warning. Original01 was statically held, never executed; two-line owned fixture fix remains documented, not a product change. Vet NOT_RUN.

Evidence supports actual source-derived >16MiB reconstruction followed by complete material SDK bytes, fixed-cap grant, missing-resume skip without grant, invalid configured downloader error without grant and same-worker recovery, nonnil empty result, previous-caller denial, per-invocation private-spool cleanup while deterministic source temp remains, original backup bytes/mtime preserved, and same-DB cold App/new worker without artifact refetch. These are assertions executed inside the retained roots; stdout does not independently archive business response bodies or numeric PIDs, so none are reconstructed here. Normal/race stdout contains the expected missing-resume WARN and existing cold command-registration-unavailable WARN; neither is suppressed or a test skip.

Layer: real App.New/HTTP handler/SQLite/installation/owned artifact peer/Go worker/SDK/material protocol/filesystem. Artifact peer is fixed tcp4, two GET routes and no forwarding. Existing statistics-center isolation is explicitly retained. This is not ordinary server App.Start/CLI, real qB/TR daemon, all material consumers, or parent completion. Source original large-run and meta's source→target FS/codec review retain their separate provenance.
