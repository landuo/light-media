# Affected installed-worker tests03 — PREEXEC READY

Only the existing shared test helpers are maintained for the now-negotiated material/v1 fixture. Both original root bodies are byte-identical: source bytes/skip/failure/logs, same-worker recovery, original backup preservation, retained deterministic temp and cold database/new-worker assertions remain.

New helpers require the actual prepare_material count, zero ordinary read/release, exact grant contract/capability/direction/kind/length/SHA and bounded page size; skipped results have no grant. No legacy handle was allocated: its observation must be absent, not a fabricated denial. Actual previous HostCaller rejection, PID/init/invocation checks remain. Every response also checks that the exact transport-spool directory is empty. This does not claim a private grant attack or replace the already actual framework revocation evidence. Existing unnegotiated SDK roots retain legacy protocol coverage.

Artifact peer is now explicitly tcp4 before start; exactly the same GET/index and GET/worker paths and installation checks, no forwarding, alternate address family, environment/proxy edits or real downloader. Same frozen fixture and all 21 production files; new large tests unchanged. 46-map gate is precisely old45 plus the one maintained test. Original runner and offline compiler configuration unchanged.

Coordinator may run only gates03/run.sh app-maintained, normal two roots, current1006. No new race or unrelated matrix is required for these test-only assertions. This is not runtime PASS and does not yet release the publication/parent HOLD. Old code/CLI/source facts remain intact; the new actual result must close the identified dependency before revised publication. Reviewer did not run Go/source/service.
