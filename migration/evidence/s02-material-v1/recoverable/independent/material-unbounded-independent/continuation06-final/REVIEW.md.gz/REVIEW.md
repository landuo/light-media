# Continuation06 — negotiated owned-process finite acceptance

**ACCEPT at the tested framework layer.** Normal8 and race4 completed with original tool exit0. Independent review read all original test events, root/subtest selection, candidate source, full three-stage maps, current files, declarations/generated test source, actual test programs and terminal receipts. Normal1976 and race2013 inputs match at all recorded phases/current readback. No FAIL/SKIP or stderr; vet NOT_RUN.

The five new roots actually start owned children from the exact built test binary, use real Start/Serve or ServeConcurrent, and assert:

- Separate material opt-in/ACK and real Handler bridge; serial 65 MiB + 1 transfer crosses the former ordinary cumulative byte ceiling with exact length/SHA/finish, two ordinary callbacks and same-process subsequent call. Stale Handler bridge and expired callback ticket are denied, and owned port Close occurs exactly once.
- Two overlapping invocations in one concurrent child transfer independent read/upload material through the actual single reader/write lock with 4 KiB physical frames and more than64 pages. Per-invocation data/hash/offset, host-side physical byte observations, callback count and exact scope cleanup pass. The subsequent ordinary call retains the same child.
- Feature-disabled new worker and the complete pre-feature serve-body fixture remain ordinary. The fixture uses current test-package dependencies, not a historical executable. Explicit material opt-in for short-lived Run refuses to fabricate a persistent generation.
- Actual blocked material reads cancel and join their owned port. Serial cancellation retains terminal child teardown/reaping; concurrent cancellation retains invocation-only behavior and permits an ordinary probe through the same Client. Both modes reject a guaranteed-unissued token before any port Read and clean its issued scope.

The three existing normal ordinary-budget/session roots also pass. Race covers only concurrent transfer, both-mode cancellation/unissued-token roots and physical-budget regression; the large serial transfer is normal-only. Child PID/content/count conclusions are assertions in the hash-bound tests plus their actual successful raw events—not fabricated standalone packet capture/PID transcript data.

Candidate04 core seam and05 compile-only evidence remain at their own inputs. This new result covers actual framework negotiation/routing and its private bridge, not public business SDK operations, external spool composition, S02/S03/S12 App/installed-worker/CLI consumers, real HTTP/downloaders or whole-parent completion. Ordinary quotas/deadlines are not globally relaxed and no page-based budget reset was added. No reviewer Go/source/network/child execution occurred.
