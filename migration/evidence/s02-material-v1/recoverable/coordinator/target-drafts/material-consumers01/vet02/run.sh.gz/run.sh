#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/a1d82674c6f8/plugins-cloud-20261028/toolchain/env.sh
export GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off CGO_ENABLED=1 GOMAXPROCS=2
export GOFLAGS="-mod=readonly -p=1 -buildvcs=false"
exec python3 /workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305/target-drafts/material-consumers01/vet02/run_vet.py
