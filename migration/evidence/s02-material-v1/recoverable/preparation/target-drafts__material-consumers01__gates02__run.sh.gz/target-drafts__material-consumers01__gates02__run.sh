#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305
G="$ROOT/target-drafts/material-consumers01/gates02"
source /workspace/scratch/a1d82674c6f8/plugins-cloud-20261028/toolchain/env.sh
export GOTOOLCHAIN=local GOPROXY=off GOSUMDB=off
export GOFLAGS='-mod=readonly -p=1 -buildvcs=false'
export GOMAXPROCS=2 CGO_ENABLED=1
[[ "$#" == 1 ]]
[[ "$(command -v go)" == /workspace/scratch/a1d82674c6f8/plugins-cloud-20261028/toolchain/go/bin/go ]]
[[ "$(git -C "$ROOT/release-light-media" rev-parse HEAD)" == 1006d11e0fa5b63c43b32d048330adf7ae3b33e7 ]]
case "$1" in
app-normal)
 label=material-s02-app-normal02; package=./internal/app
 roots=(TestOriginalLocalBackupLargeSourceFilesystem TestSharedLocalBackupMaterialLargeWorkerAndCold)
 extra=(--fixture ./cmd/owned-local-torrent-backup-fixture --fixture-env OWNED_LOCAL_TORRENT_BACKUP_WORKER)
 ;;
app-race)
 label=material-s02-app-race02; package=./internal/app
 roots=(TestSharedLocalBackupMaterialLargeWorkerAndCold)
 extra=(--fixture ./cmd/owned-local-torrent-backup-fixture --fixture-env OWNED_LOCAL_TORRENT_BACKUP_WORKER --race)
 ;;
sdk-legacy)
 label=material-s02-sdk-legacy02; package=./internal/plugins
 roots=(TestLocalTorrentBackupWireAndBoundary TestLocalTorrentBackupPagedBytesAndCleanup)
 extra=()
 ;;
*) exit 64;;
esac
pattern="^($(IFS='|'; echo "${roots[*]}"))$"
expects=();for root in "${roots[@]}";do expects+=(--expect "$root");done
# Only the App root starts the owned artifact tcp4 peer and real owned workers.
# No real downloader/source/network-forwarder or proxy/CA/TZ/LANG edits.
exec python3 "$G/gate.py" --root "$ROOT" --label "$label" --package "$package" \
 --overlay "$G/overlay.json" --binding "$G/overlay-inputs.json" \
 --extra-input "$G/run.sh" --extra-input "$G/preparation-seal.json" --run "$pattern" "${expects[@]}" "${extra[@]}"
