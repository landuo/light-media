from pathlib import Path
import hashlib,json,difflib,subprocess,datetime
R=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305');A=R/'release-light-media';D=R/'target-drafts/material-consumers01';P=D/'affected-worker-tests03'
old=A/'internal/app/plugin_shared_local_torrent_backup_worker_test.go'
s=old.read_text();(P/'preimage.go.txt').write_bytes(old.read_bytes())
s=s.replace('\t"encoding/json"\n','\t"encoding/json"\n\t"net"\n',1)
s=s.replace('\t\tHostCalls struct{ Total, Prepare, Read, Release int } `json:"host_calls"`','''\t\tHostCalls struct {
\t\t\tTotal, Prepare, Read, Release int
\t\t\tMaterialPrepare int `json:"material_prepare"`
\t\t} `json:"host_calls"`
\t\tGrant *struct {
\t\t\tContract, Capability, Direction, Kind, SHA256 string
\t\t\tTotal int64
\t\t\tChunkBytes int `json:"chunk_bytes"`
\t\t} `json:"material_grant"`''',1)
s=s.replace('server := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {','handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {',1)
s=s.replace('''\t}))
\tindex.Releases[0].Artifacts[0].URL''','''\t})
\t// Fix the owned address family before starting; a bind refusal is fatal.
\t// No IPv6 retry, proxy change, forwarding, CONNECT or external upstream.
\tlistener, err := net.Listen("tcp4", "127.0.0.1:0")
\tif err != nil {
\t\tt.Fatal(err)
\t}
\tserver := &httptest.Server{Listener: listener, Config: &http.Server{Handler: handler}}
\tindex.Releases[0].Artifacts[0].URL''',1)
s=s.replace('''\treturn result
}

func ownedLocalBackupWorkerBytes''','''\t// Current fixture negotiates material/v1: no legacy handle was allocated
\t// or released. Do not manufacture a released-handle security observation.
\t// Explicit unnegotiated SDK roots retain the legacy read/release checks.
\tif result.PriorReleasedHandleDenied != nil {
\t\tt.Fatal("material invocation unexpectedly reported a legacy released handle", result)
\t}
\tentries, err := os.ReadDir(filepath.Join(a.Dir, "temp", "plugin-material-spool"))
\tif err != nil && !os.IsNotExist(err) {
\t\tt.Fatal(err)
\t}
\tif len(entries) != 0 {
\t\tt.Fatal("completed invocation retained owner transport spools", len(entries))
\t}
\treturn result
}

func ownedLocalBackupWorkerBytes''',1)
s=s.replace('''\treads := (len(want) + plugins.TorrentMaterialChunkBytes - 1) / plugins.TorrentMaterialChunkBytes
\tif attempt.HostCalls.Prepare != 1 || attempt.HostCalls.Read != reads || attempt.HostCalls.Release != 1 || attempt.HostCalls.Total != reads+2 {
\t\tt.Fatalf("actual SDK page/cleanup count differs: %+v", attempt.HostCalls)
\t}''','''\tif attempt.HostCalls.Prepare != 1 || attempt.HostCalls.MaterialPrepare != 1 || attempt.HostCalls.Read != 0 || attempt.HostCalls.Release != 0 || attempt.HostCalls.Total != 1 {
\t\tt.Fatalf("actual material prepare versus ordinary callback count differs: %+v", attempt.HostCalls)
\t}
\tg := attempt.Grant
\tif g == nil || g.Contract != plugins.MaterialContract || g.Capability != plugins.LocalTorrentBackupCapability || g.Direction != string(plugins.MaterialToWorker) || g.Kind != "bytes" || g.Total != int64(len(want)) || g.SHA256 != hex.EncodeToString(digest[:]) || g.ChunkBytes < 1 || g.ChunkBytes > plugins.MaterialFrameBytes {
\t\tt.Fatalf("actual material grant summary differs: %+v", g)
\t}''',1)
s=s.replace('''attempt.HostCalls.Prepare != 1 || attempt.HostCalls.Read != 0 || attempt.HostCalls.Release != 0 || attempt.HostCalls.Total != 1 {''','''attempt.HostCalls.Prepare != 1 || attempt.HostCalls.MaterialPrepare != 1 || attempt.HostCalls.Read != 0 || attempt.HostCalls.Release != 0 || attempt.HostCalls.Total != 1 || attempt.Grant != nil {''',1)
s=s.replace(''' || after.PriorReleasedHandleDenied == nil || !*after.PriorReleasedHandleDenied''','',1)
p=P/'plugin_shared_local_torrent_backup_worker_test.go.txt';p.write_text(s)
subprocess.run(['/workspace/scratch/a1d82674c6f8/plugins-cloud-20261028/toolchain/go/bin/gofmt','-w',str(p)],check=True)
new=p.read_text()
# Root functions and their complete business/FS/cold/log bodies are byte-identical.
a=old.read_text().split('func TestSharedLocalTorrentBackupActualWorkerRecoveryAndScopes',1)[1]
b=new.split('func TestSharedLocalTorrentBackupActualWorkerRecoveryAndScopes',1)[1]
assert a==b,'root bodies changed'
(P/'preimage-to03.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.splitlines(True),fromfile='HEAD1006/internal/app/plugin_shared_local_torrent_backup_worker_test.go',tofile='candidate03/internal/app/plugin_shared_local_torrent_backup_worker_test.go')))
def row(p):b=Path(p).read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
(P/'CONTRACT.md').write_text('''# Affected existing installed-worker regression maintenance\n\nThe two existing roots do not pin an old artifact. `originalMarketOwnedIndex` reads the explicitly supplied `OWNED_LOCAL_TORRENT_BACKUP_WORKER` and invokes its real `--manifest`; an absent ENV fails rather than skipping. With the current candidate fixture/SDK they negotiate material/v1. The old common helper's legacy page/release counts and mandatory prior released handle are therefore invalid and would fail. This is a real affected-test maintenance requirement, not documentation exemption.\n\nOnly this existing test file changes: exact full SDK bytes/hash/small bytes, temporary flag, all root business/permission/config/skip/log/backup/temp/cold assertions and sequences remain. Both root function bodies are byte-identical. Shared helpers now require prepare_material=1, total ordinary HostCaller=1, read/release=0 and exact actual grant contract/capability/direction/kind/size/digest with bounded chunk size. Skip requires no grant. After every completed invocation the exact owner-spool directory is empty; the actual expired prior HostCaller must still be denied and warm identity/init/invocation remains checked. No legacy handle exists, so a purported released-handle result must be absent rather than fabricated. Two already-run explicitly unnegotiated SDK roots separately retain legacy read/release and cleanup coverage. No production protocol selector or new fixture is introduced.\n\nThe old artifact helper now binds explicit tcp4 before start, with rejection fatal and no fallback. It retains exactly two owned artifact GETs and all installation/SQLite assertions. Product21, current fixture02, new large tests and their actual results remain byte-identical. Old publication02 and test preimage remain immutable. This preparation has not run either maintained root; coordinator alone runs the exact two related roots after review.\n''')
manifest=dict(status='PREPARED_NOT_EXECUTED',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline='1006d11e0fa5b63c43b32d048330adf7ae3b33e7',root_bodies_byte_identical=True,roots=['TestSharedLocalTorrentBackupActualWorkerRecoveryAndScopes','TestSharedLocalTorrentBackupActualWorkerPagedAndCold'],preimage=row(old),files=[row(P/n) for n in ('prepare.py','preimage.go.txt',p.name,'preimage-to03.patch','CONTRACT.md')],fixture=row(D/'worker-tests02/main.go.txt'),new_large_test_unchanged=row(D/'worker-tests01/plugin_shared_local_torrent_backup_material_worker_test.go.txt'))
(P/'preparation.json').write_text(json.dumps(manifest,indent=2)+'\n')
(P/'preparation-seal.json').write_text(json.dumps({'manifest':row(P/'preparation.json'),'status':'PREPARED_NOT_EXECUTED'},indent=2)+'\n')
print(json.dumps(row(P/'preparation-seal.json')))
