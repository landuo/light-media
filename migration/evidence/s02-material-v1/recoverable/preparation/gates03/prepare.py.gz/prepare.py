from pathlib import Path
import hashlib,json,datetime,subprocess,ast
R=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305');A=R/'release-light-media';D=R/'target-drafts/material-consumers01';G=D/'gates03';P=D/'affected-worker-tests03'
HEAD='1006d11e0fa5b63c43b32d048330adf7ae3b33e7'
def row(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(r):assert row(r['path'])==r,r['path']
def js(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','-C',str(A),'rev-parse','HEAD'],text=True).strip()==HEAD
b=json.loads((D/'gates02/overlay-inputs.json').read_text())
for r in [b['active_original'],b['source_oracle'],b['source_original']]+b['additional_bound_files']:verify(r)
for r in b['replacements']:verify(r['backing'] or r['removed_preimage'])
original=A/'internal/app/plugin_shared_local_torrent_backup_worker_test.go';back=P/'plugin_shared_local_torrent_backup_worker_test.go.txt'
assert original.read_bytes()==(P/'preimage.go.txt').read_bytes()
assert str(original) not in [x['virtual_path'] for x in b['replacements']]
b['replacements'].append(dict(virtual_path=str(original),virtual_present_before=True,backing=row(back)))
extra={r['path']:r for r in b['additional_bound_files']}
for p in [original,*P.iterdir(),D/'gates02/overlay-inputs.json',D/'gates02/preparation-seal.json',G/'prepare.py']:
 if p.is_file():extra[str(p)]=row(p)
b['additional_bound_files']=list(extra.values())
b['layer']='Maintained two existing S02 installed-worker roots against the current negotiated material/v1 fixture; no new production source or case sequence'
b['affected_existing_roots']=json.loads((P/'preparation.json').read_text())['roots']
b['historical_notice']='gates01/02 wording about not mixing legacy assertions with current binary is superseded by this actual affected-test maintenance. Original results/publication02 remain immutable.'
js(G/'overlay-inputs.json',b)
js(G/'overlay.json',{'Replace':{r['virtual_path']:r['backing']['path'] if r['backing'] else '' for r in b['replacements']}})
(G/'gate.py').write_bytes((D/'gates02/gate.py').read_bytes());ast.parse((G/'gate.py').read_text())
old=(D/'gates02/run.sh').read_text()
start=old.index('case "$1" in');end=old.index('pattern=',start)
new=old[:start]+'''case "$1" in
app-maintained)
 label=material-s02-affected-worker03; package=./internal/app
 roots=(TestSharedLocalTorrentBackupActualWorkerRecoveryAndScopes TestSharedLocalTorrentBackupActualWorkerPagedAndCold)
 extra=(--fixture ./cmd/owned-local-torrent-backup-fixture --fixture-env OWNED_LOCAL_TORRENT_BACKUP_WORKER)
 ;;
*) exit 64;;
esac
'''+old[end:]
new=new.replace('material-consumers01/gates02','material-consumers01/gates03')
(G/'run.sh').write_text(new);subprocess.run(['bash','-n',str(G/'run.sh')],check=True)
(G/'COMMAND.txt').write_text('''Prepared only. Coordinator serial execution after independent preexec review.\n\nbash '''+str(G/'run.sh')+''' app-maintained\n\nExact two EXISTING root bodies are unchanged. Only shared fixture assertions now observe the actual negotiated protocol; owned artifact listener is explicit tcp4. This gate preserves the old normal2/legacy2/race1/CLI PASS evidence and product21; it runs no new large root, no source collector, no full historical suite, no real downloader or filesystem probes. Existing actual fixture source is unchanged; the same standard runner recompiles it from the frozen overlay and records its SHA. No race is requested because this delta adds no production concurrency: current consumer race1 remains credited.\n\nRunner is byte-identical to gates02: full declared Go closure and generated source, before/aftercompile/aftertest maps, tool/program/fixture hashes, exact pass/no-skip checks, real1GiBfloor. Vet is NOT_RUN as previously. Baseline1006 with Meta25 protection unchanged, 46 overlay mappings (one added existing test hunk). No new proxy/environment/route policy.\n''')
seal=dict(status='PREPARED_NOT_EXECUTED',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=HEAD,overlay_count=len(b['replacements']),test=row(P/'preparation-seal.json'),predecessor=row(D/'gates02/preparation-seal.json'),runner_exact_copy_of=row(D/'gates02/gate.py'),files=[row(G/n) for n in ('prepare.py','gate.py','run.sh','COMMAND.txt','overlay.json','overlay-inputs.json')])
js(G/'preparation-seal.json',seal)
print(json.dumps({'seal':row(G/'preparation-seal.json'),'binding':row(G/'overlay-inputs.json'),'test':row(back)},indent=2))
