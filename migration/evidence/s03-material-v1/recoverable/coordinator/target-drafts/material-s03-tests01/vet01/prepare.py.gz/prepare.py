#!/usr/bin/env python3
"""Static hash/mapping preparation only. Go commands are never run here."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
R=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305');A=R/'release-light-media';D=R/'target-drafts/material-s03-tests01';G=D/'vet01';OLD=R/'target-drafts/material-consumers01/vet02';N=R/'evidence/material-s03-app-normal03';PUB=D/'publication02'
BASE='0461a07298996e77cdce56dc9a5e2dc6306e55f2'
def row(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,d):
 assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n')
assert not (G/'preparation-seal.json').exists()
assert subprocess.check_output(['git','-C',str(A),'rev-parse','HEAD'],text=True).strip()==BASE
normal=json.loads((N/'result.json').read_text());assert normal['status']=='PASS' and normal['input_count']==6446
maps=[json.loads((N/name).read_text()) for name in ('inputs-before.json','inputs-after-compile.json','inputs-after-test.json')];assert maps[0]==maps[1]==maps[2]
manifest=json.loads((PUB/'publication-whitelist.json').read_text())
physical=[x for x in manifest['files'] if x['role'] in ('product','test','necessary_test','owned_fixture','original_source_raw')]
assert len(physical)==19 and sum(x['role']=='product' for x in physical)==11
expected={str(A/x['destination']):{k:x['source'][k] for k in ('sha256','bytes')} for x in physical}
# Only adopted paths change; old raw/immutable external backing paths remain
# provenance bound, but the vet overlay will never compile from those products.
inputs=maps[0].copy()
for p,r in expected.items():inputs[p]=r
for p,r in inputs.items():
 actual=row(p);assert all(actual[k]==r[k] for k in ('bytes','sha256')),'unexpected post-adoption drift '+p
old_binding=json.loads((D/'gates03/overlay-inputs.json').read_text());meta=old_binding['replacements'][:20]
assert len([x for x in meta if x['backing'] is None])==17
assert len([x for x in meta if x['backing'] is not None])==3
assert not set(expected)&{x['virtual_path'] for x in meta}
overlay={x['virtual_path']:x['backing']['path'] if x['backing'] else '' for x in meta}
dump(G/'meta-only-overlay.json',{'Replace':overlay})
for x in meta:
 r=x['backing'] or x['removed_preimage'];assert row(r['path'])==r
 if x['backing']:
  relative=str(Path(x['virtual_path']).relative_to(A));head=subprocess.check_output(['git','-C',str(A),'show',BASE+':'+relative]);assert hashlib.sha256(head).hexdigest()==r['sha256']
  inputs[r['path']]={k:r[k] for k in ('bytes','sha256')}
def add(p):
 r=row(p);v={k:r[k] for k in ('bytes','sha256')}
 if r['path'] in inputs:assert inputs[r['path']]==v
 inputs[r['path']]=v
build=normal['build_environment'];go=Path(build['GOROOT'])/'bin/go';tool=Path(build['GOROOT'])/'pkg/tool'/(build['GOOS']+'_'+build['GOARCH'])/'vet';assert tool.is_file();add(go);add(tool)
packages=['./internal/plugins','./internal/plugins/iyuuautoseed/native','./internal/app','./cmd/owned-downloader-command-fixture']
assert (A/'cmd/owned-downloader-command-fixture/main.go').is_file()
for p in [N/'result.json',N/'coordinator-tool-receipt.json',N/'inputs-before.json',N/'inputs-after-compile.json',N/'inputs-after-test.json',PUB/'publication-whitelist.json',PUB/'seal02.json',R/'audits/s03-material-complete-adoption01/adoption-receipt.json',OLD/'preparation-seal.json',OLD/'run_vet.py',G/'run_vet.py',G/'run.sh',G/'prepare.py',G/'meta-only-overlay.json']:
 add(p)
(G/'runner-delta.patch').write_text(''.join(difflib.unified_diff((OLD/'run_vet.py').read_text().splitlines(True),(G/'run_vet.py').read_text().splitlines(True),fromfile=str(OLD/'run_vet.py'),tofile=str(G/'run_vet.py'))));add(G/'runner-delta.patch')
(G/'COMMAND.txt').write_text('Coordinator-only after independent preexec; static affected vet, no test/service/source execution.\n\nbash '+str(G/'run.sh')+'\n\nExact 4 packages: '+', '.join(packages)+'. Only 3 HEAD Meta hook restorations and 17 hidden Meta Go paths are overlaid; all19 adopted product/support paths must be actual physical Go declarations. Original 6446 inputs supply provenance; current physical replacements plus runtime go-list declarations are frozen before/after vet. Go/vet executables bound; no implicit tool download, altered proxy/CA or ordinary execution.\n');add(G/'COMMAND.txt')
ast.parse((G/'run_vet.py').read_text());subprocess.run(['bash','-n',str(G/'run.sh')],check=True)
binding={'baseline':BASE,'go_executable':str(go),'vet_executable':row(tool),'command':['go','vet','-overlay='+str(G/'meta-only-overlay.json'),*packages],'go_list_command':['go','list','-overlay='+str(G/'meta-only-overlay.json'),'-mod=readonly','-buildvcs=false','-deps','-test','-json',*packages],'required_environment':{'GOTOOLCHAIN':'local','GOPROXY':'off','GOSUMDB':'off','CGO_ENABLED':'1','GOMAXPROCS':'2','GOFLAGS':'-mod=readonly -p=1 -buildvcs=false'},'inputs':[dict(path=k,**v) for k,v in sorted(inputs.items())],'meta_replacements':meta,'physical_publication_inputs':physical,'basis':'Actual normal03 full closure,19 exact adopted physical bytes,Meta-only20 exclusion; actual four-package declarations added before static vet and rehashed after'}
dump(G/'bindings.json',binding)
dump(G/'preparation-seal.json',{'status':'PREPARED_AFTER_EXACT_PHYSICAL_ADOPTION_NOT_EXECUTED','baseline':BASE,'physical_product_support_count':19,'meta_overlay_count':20,'files':[row(G/name) for name in ('bindings.json','meta-only-overlay.json','run.sh','run_vet.py','prepare.py','runner-delta.patch','COMMAND.txt')],'inputs':len(inputs),'source_tests_services_run':False})
print(json.dumps(row(G/'preparation-seal.json'),indent=2))
