"""Affected adopted-physical-package static vet; no source/test/service run."""
import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261031T1305');HERE=ROOT/'target-drafts/material-s03-tests01/vet01';ACTIVE=ROOT/'release-light-media';E=ROOT/'evidence/material-s03-vet01'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def item(p):
 p=Path(p);return {'sha256':sha(p),'bytes':p.stat().st_size}
def snapshot(paths):return {str(p):item(p) for p in sorted(paths)}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
binding=json.loads((HERE/'bindings.json').read_text());prepared=json.loads((HERE/'preparation-seal.json').read_text())
assert shutil.which('go')==binding['go_executable']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ACTIVE,text=True).strip()==binding['baseline']
for key,value in binding['required_environment'].items():assert os.environ.get(key)==value,key
for row in prepared['files']+binding['inputs']:
 assert item(row['path'])=={k:row[k] for k in ('sha256','bytes')},'input drift '+row['path']
overlay=json.loads((HERE/'meta-only-overlay.json').read_text())['Replace'];assert len(overlay)==20
assert not any(str(ACTIVE/x['destination']) in overlay for x in binding['physical_publication_inputs']),'physical product/support must not be shadowed'
for r in binding['meta_replacements']:
 assert str(Path(r['virtual_path'])) in overlay and Path(r['virtual_path']).exists()==r['virtual_present_before']
 if r['backing'] is None:assert overlay[r['virtual_path']]==''
 else:assert overlay[r['virtual_path']]==r['backing']['path']
E.mkdir(mode=0o700)
record={'status':'RUNNING','kind':'adopted_physical_affected_go_vet_only','started':now(),'baseline':binding['baseline'],'commands':[],'source_or_tests_or_services_run':False,'physical_product_count':11,'physical_support_count':8,'meta_only_overlay_count':20,'binding_sha256':sha(HERE/'bindings.json'),'proxy_CA_environment_unchanged':True}
def save():(E/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command):
 sample={'phase':label,'scratch_free':shutil.disk_usage(ROOT).free,'tmp_free':shutil.disk_usage('/tmp').free};record.setdefault('resource_samples',[]).append(sample);assert min(sample['scratch_free'],sample['tmp_free'])>=1<<30
 record['commands'].append({'label':label,'argv':command});save()
 with (E/(label+'.stdout')).open('xb') as out,(E/(label+'.stderr')).open('xb') as err:result=subprocess.run(command,cwd=ACTIVE,stdout=out,stderr=err)
 (E/(label+'.exit')).write_text(str(result.returncode)+'\n');record['commands'][-1]['exit']=result.returncode;save()
 return result.returncode
paths={Path(x['path']) for x in binding['inputs']}|{HERE/'bindings.json',HERE/'preparation-seal.json',HERE/'run.sh',HERE/'meta-only-overlay.json',Path(__file__).resolve()}
try:
 initial=snapshot(paths);(E/'inputs-before-list.json').write_text(json.dumps(initial,indent=2)+'\n');save()
 assert run('go-list',binding['go_list_command'])==0,'go list failed'
 assert snapshot(paths)==initial,'input drift during declared-closure inspection'
 raw=(E/'go-list.stdout').read_text();decoder=json.JSONDecoder();offset=0;declarations=[]
 while offset<len(raw):
  while offset<len(raw) and raw[offset].isspace():offset+=1
  if offset==len(raw):break
  package,offset=decoder.raw_decode(raw,offset)
  if not package.get('Dir'):continue
  directory=Path(package['Dir'])
  for key in ('GoFiles','CgoFiles','TestGoFiles','XTestGoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SwigFiles','SwigCXXFiles','SysoFiles','EmbedFiles','TestEmbedFiles','XTestEmbedFiles'):
   for value in package.get(key,[]):
    virtual=(directory/value).resolve();backing=overlay.get(str(virtual),str(virtual));assert backing,'Go declared hidden Meta input '+str(virtual)
    effective=Path(backing);assert effective.is_file(),'missing actual declared input '+str(effective)
    paths.add(effective);declarations.append({'package':package.get('ImportPath'),'kind':key,'virtual_path':str(virtual),'backing_path':str(effective)})
 for row in binding['physical_publication_inputs']:
  virtual=str(ACTIVE/row['destination']);assert any(x['virtual_path']==virtual and x['backing_path']==virtual for x in declarations),'adopted source not physically declared '+virtual
 (E/'virtual-compile-inputs.json').write_text(json.dumps(declarations,indent=2)+'\n')
 before=snapshot(paths);(E/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');record['input_count']=len(before)
 generated={};cache=Path(os.environ['GOCACHE']).resolve()
 for path in paths:
  if path.is_relative_to(cache):
   dest=E/'generated-source'/(before[str(path)]['sha256']+'.go');dest.parent.mkdir(exist_ok=True);dest.write_bytes(path.read_bytes());generated[str(path)]=str(dest.relative_to(E))
 (E/'generated-source-map.json').write_text(json.dumps(generated,indent=2)+'\n');save()
 result=run('vet',binding['command']);record['exit']=result
 after=snapshot(paths);(E/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');record['input_drift']=[p for p in before if before[p]!=after[p]]
 assert not record['input_drift'],'vet inputs drifted'
 assert result==0,'go vet failed'
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error_class=type(error).__name__,error=str(error));raise
finally:record['finished']=now();save();print(json.dumps(record))
