# Parent15 / Parent38 final evidence composition

## Decision

**Accept local functional evidence closure for each exact candidate separately.** Both previously open native UI gates are now satisfied. This is not a combined current-HEAD acceptance, clean-lifecycle PASS, source adoption, commit or publication approval. The ledger is unchanged.

Reviewer did not author product changes or execute the UI. Reviewer did prepare the parent38 launch/peer helper; helper authoring is therefore disclosed rather than claimed independently reviewed here. Existing separately accepted product/build/fixture evidence is composed, not rerun.

## Parent15

Captured real installation and one clone submission, followed by reload, show exact name/description including whitespace, quotes, backslash and literal markup; version/icon match trimmed inputs. This reviewer independently compared all four metadata values. All four old caps were crossed in the captured scenario. Card markup was not interpreted (zero b elements) and the unsafe icon rendered the local fallback. Parent/clone worker SHA, manifest plugin ID/version/entry remain identical. This is public UI/metadata evidence, not a new packet-level proof about every possible browser request.

The 141-file frontend/server build is the previously sealed aef41924… program at 0a56… with three clone products; no S08. Compose with ledger-accepted App a2808b19…, UI roots 172025b6…, ordinary dual-host CLI 840c2fbb… and historical parent scope. No second optional-empty-fields clone is required absent an affected uncovered inheritance claim.

## Parent38

Actual accessibility/text observations show due_collection_budget, running while retaining clock error, completion retaining the error, second manual run/fresh reopen retaining error, then native form resave clearing the fault and showing future waiting. Full reload still shows waiting and future time. This closes the specific new clock-error browser gate. Compose with accepted Calendar19/combining16/annex8/nullkwargs4, App normal/race and CLI03 independent seal 43f80e63… (46 control/44 public bodies/9 callbacks/2 artifacts and dual-host cold), without pretending these were rerun.

The d6d92f35… server and 2ebce903… form worker are bound to local S08 tree 3e1081bc… and 17 recovered products, not the new clone candidate. There are three actual repair HTTP204 responses: two manual, one during calendar resave. The third being calendar catch-up is only an inference. HTTP204 establishes transport completion, not plugin business success: the fixture is list-fail. The observed browser stopping/waiting state, not an invented business-success assertion, supplies the gate.

## Lifecycle and release boundary

Both application generations have STOP, actual terminal Wait and exit_code 1; both peers ended without errors. The safe instance also previously exited nonzero before either plugin was installed. Thus shutdown failure is not evidence that the just-observed clone fields or clock-state transitions failed, and does not reopen those finite UI gates or erase inherited cold evidence. It does prevent a clean-lifecycle PASS and remains an open host-integration/release issue until its cause and impact are assessed. No causal exoneration of every changed file is claimed. Coordinator reports context deadline; private stderr was not reread in this review.

Same-data retained inventory is three plugins; nothing is deleted. There is no current single executable carrying both candidates and the final delivery HEAD. Before unconditional delivery closure: compose exact 20 products against delivery preimages, regenerate new-tree carriers/dist as needed, check actual changed dependencies, perform directed integration validation, and explicitly disposition shutdown failure. No blanket replay of already accepted original matrices is implied.

## Exact products

### Parent 15
- internal/app/plugin_instances.go — 49aa8e57d9db062d10a086829152cf0e117b4e1c0e58a16f641058dd45ae2713
- web/src/features/plugin-clone.ts — 3b8d68779b73ff5d632481f3b22d90c53ec615b2e4b4106393c4e752d37b43fe
- web/src/components/PluginCloneDialog.vue — 9988a9059379b8453960e0d4615f5d6244295cb74a4b4ad3c3e1b63acf148efd

### Parent 38
- internal/plugins/schedule/builtin_constructor.go — d32db93d60c44e3de1ec74bad0c53b30a86fe2080ee81044fe3a3e195cb6d6ca
- internal/plugins/schedule/builtin_cron_projection.go — 6b002abd4be8da86296fddfb4fd945bf6986cb7348d6b516f449f80ba602046c
- internal/plugins/schedule/builtin_descriptor.go — 54bcb7797da5a1f25183c7db66faf9d455e6f8677f139720c01ccb170dc21972
- internal/plugins/schedule/builtin_evaluator.go — 73d157372588e206954488133d5aada8ceb807df18ffd0b8448d666c9efa04ee
- internal/plugins/schedule/builtin_leaves.go — c587b6c4ddb88bb9cbdc16f5115bce370a7c134824a81811613213d8aa0a07a6
- internal/plugins/schedule/builtin_session.go — 66b09ea542d2a5ae430ebac0a77a56a333cc248aa1edc2ff535d119d2cb4c7e3
- internal/plugins/schedule/calendar_interval.go — 558cc6c1c131abbeaa77f46886acb393878e6d6f12626e82a9c05b32db45c0b3
- internal/app/plugin_original_builtin_clock.go — 20c4c306ce06d04956408d315a7acaef1b96823684b9f8e7d61d98d4525ceb0a
- internal/app/plugin_original_builtin_definition.go — 313896deb6d241e9ad3039e16ca5e89a1e9cc765570a54cacef2b081eea5f371
- internal/app/plugin_original_direct_dispatch.go — 38d3366e1942f8c0d134583781ad31de5b0df2e43963e952313b193dc45faa0c
- internal/app/plugin_original_service_options.go — 57aadac433429306c7ff318129c6f43b3fcbcc2dfea35ddd71b6d1c6c9f58ead
- internal/app/plugin_original_service_progress.go — d9437f6c5477c37f893303064af977baf9d6b67cf298f7621a979a31bc80aa55
- internal/app/plugin_original_services.go — 7ff7dc74bfd728ef0939ffcad0256d28894d726d903489799ec70f5ce346756f
- internal/app/plugin_original_storage_reads.go — 21c472663dcf80e42adb3fad95f403be5bc83622341bef79a2e91fddb8c7c39f
- internal/plugins/schedule/trigger.go — 0d84900692b94c060d42e85f651f7a0f900a8250d4b756e0b44309c6588e4e18
- internal/plugins/schedule/builtin_date_constructor.go — c2000274cab5b4d6d02efc6564ad602d97d1ca93e3f45da9cced3ea44ac871eb
- internal/app/plugin_original_builtin_date_args.go — 7a28aaba1eb950b2b246846cc40ea991b94222db25c1ed290ae489c9120808d1

Full backing paths, exact hashes, build seal checks, inherited ledger records and newly read evidence hashes are in FINAL-REVIEW.json. All current product bytes and all selected build-seal file/program bindings matched. No services or tests were run.
