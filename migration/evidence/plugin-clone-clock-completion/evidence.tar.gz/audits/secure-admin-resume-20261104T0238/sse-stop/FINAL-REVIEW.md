# SSE generation shutdown: independent final review

## Decision

ACCEPT the minimal generation-request context fix, directed tests, actual build, and same-data safe browser stop, within the explicit boundaries below. This reviewer did not author or execute the new product/test/runner/safe-stop driver. No source, ledger, index or Git ref was changed by this review.

## Product and provenance

The sole product change is cmd/server/self_service.go: the actual runSelfServiceChild uses a factory preserving its server parameters and returning the existing generation ctx from BaseContext. The source preimage equals accepted local S08 tree 3e1081bc. Parent38's 39 overlay mappings remain unchanged; candidate product plus new test make 41 mappings. No parent15 new product composition is implied. Existing cancel → Shutdown(2s) → HTTP Close → App.Close ordering, Store lifetime and joined failure reporting remain unchanged.

The actual server is runtime/sse-generation-shutdown-server01, 78,191,364 bytes, SHA fcba69dc6870554fc742a11b0af1f359705c7f0b21f6905b121fae7549524ba6. Its test/build receipts are bound to exact before/after inputs. Five captured groups have 6495 negative, 6495 normal, 6504 race, 6516 App, and 4197 build inputs. All before/after maps match, 6548 unique current files hash-match, and actual unoverlaid repository source declarations were independently checked against the accepted local tree.

## Actual directed evidence

- Old detached request-context negative control failed with the expected shutdown context deadline after approximately 2 seconds and detected App.Close before the handler returned. This is retained expected-failure evidence, not relabeled PASS.
- New real TCP tests passed normal and race: authenticated live SSE on parent-stop and generation-only restart cancellation, clean EOF, parent remaining alive for restart; existing 401/403 gates retained.
- Ordinary HTTP request test holds an admitted handler after cancellation, proves Store still usable, then releases and confirms drain before App.Close. Owned goroutines have bounded failure cleanup joins.
- Existing SSE authentication/prefix/disconnect, session revocation/App stop and Fetch Metadata boundaries passed. These are finite selected roots, not a replay of all plugin or site business.
- Actual build completed exit0; all positive command stderr empty and captured inputs unchanged. No real supervisor-process restart was performed by these tests.

## Browser and stop result

The existing account/data was reused without new credentials. The authenticated settings page remained open in safe mode. Owned STOP/SIGTERM produced original Wait exit0, generation close_reason stop, wait_success true and a zero-byte stderr. Receipt timestamps differ by 0.012834 seconds between stop request and completed Wait. This is a clean observed safe-mode stop.

Live browser SSE was NOT verified. Developer Tools was denied by organization policy and the restriction was respected; no alternate route bypassed it. The evidence must therefore be described as safe stopping with an authenticated page open, not browser-proven active-SSE cancellation. Real active SSE causal evidence is the separate real-TCP positive/negative test pair. New tab closure is coordinator-reported cleanup, not a separate test claim.

## Preserved failures and limits

Original setup/safe/normal failures are not overwritten. Bound safe-resume03, normal-resume04 and parent38 normal-resume05 receipts still show their actual nonzero exits; both old peers retain completed terminal receipts. The earlier setup02 failure also remains separately in its original path. These reports do not establish the specific request that caused each historic timeout. The minimal fix and controlled counterexample provide a strong verified mechanism, not retroactive certainty about uninstrumented browser connections.

The newly observed anomaly is addressed within this bounded request-lifecycle scope. This is not normal-mode runtime/business acceptance for the new binary, real process self-restart acceptance, parent15/38 combined final-HEAD acceptance or publication. Those claims require their own evidence; old accepted plugin UI evidence remains frozen and inherited. No broad matrix rerun is needed merely to accept this finite fix.

## Repository integrity

Current physical bound files, HEAD 0a56e77e3a61b7f2dc14b5f4ce3f168a22d2a590, index hash and porcelain status match the preparation snapshot. Ledger hash matches the prior independent review. Existing dirty work was preserved, not claimed absent. Full source/preimage/test/product hashes, 5 capture bindings, raw command receipts, retained old receipts and scope exclusions are in FINAL-REVIEW.json.

Additional readback: INTEGRATION-NOTE.md and delivery-bindings.json match the product/test/patch/execution receipts above. Verbatim browser-authenticated-tool-text.json shows the authenticated settings and logout control, with no credential values; it does not establish live SSE. These three artifacts are included in the final JSON evidence bindings.
