# Minimal generation HTTP shutdown fix

## Result

The original detached request context was reproduced in a real authenticated TCP SSE test: shutdown reached the unchanged two-second deadline. The one-file product fix makes the actual server use its generation context as BaseContext. The new positive tests, race tests, original shutdown/protocol gates, and existing SSE authentication boundaries all pass. The ordinary server built from the reviewed accepted-S08-plus-38 composition with this fix has SHA256 fcba69dc6870554fc742a11b0af1f359705c7f0b21f6905b121fae7549524ba6.

A real cloud browser reused the existing session and kept authenticated Settings open. The exact new server, launched with -safe on the existing owned instance, then exited through the original supervisor Wait with code 0, close_reason stop, wait_success true, and empty stderr. It took approximately 0.013 seconds from the controlled stop request to terminal result. The new tab was closed after the service had stopped.

## Scope and limitations

- The browser organization policy forbids Developer Tools. That restriction was respected. A live SSE request was not separately observed in the browser, so this is authenticated-browser safe-mode shutdown evidence, not a claim of directly observed browser SSE drain. Real live SSE drain is demonstrated by the TCP tests.
- Generation-only restart cancellation is covered at the HTTP/app test seam. A new actual subprocess restart cycle was not run.
- Parent15 and parent38 business browser acceptance was completed separately before this fix; it was not rerun. This candidate includes the accepted local S08 and 38 composition, not all parent15 products. It is not evidence for one final delivered combined HEAD.
- The three historical browser deadline failures and the controlled negative test remain intact. The historical receipts alone do not establish the exact request that caused their timeout.
- No physical repository product source, normal Git index, refs, ledger, existing account or credentials, Mac, NAS, or external site settings were modified by this fix phase. Original private data/logs remain private and are not deliverables.

## Integration

Product candidate: target-drafts/sse-generation-shutdown01/candidate/cmd/server/self_service.go.
New regression test: target-drafts/sse-generation-shutdown01/candidate/cmd/server/generation_http_test.go.
Patch: target-drafts/sse-generation-shutdown01/product.patch.

Apply the product patch to its accepted-S08 preimage, not blindly over the old physical HEAD. The preimage is tied to tree 3e1081bcbb7dfb6231372f6333a3427e303b13b5. Preserve the current media-server assembly and generation lifecycle behavior. Final integration must bind the actual delivered commit and run only the required affected final-composition gates.

Final static seal is preparation-seal03.json; earlier 01/02 seals are superseded preparation-only records retained for traceability. Execution evidence lives in evidence/sse-generation-shutdown01, evidence/sse-generation-shutdown-build01, and evidence/sse-generation-browser-safe-resume06. Delivery file hashes are in delivery-bindings.json. Final independent review is adjacent as FINAL-REVIEW.md/json once completed.
