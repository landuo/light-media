# Final 15 / 38 composition boundary review

## Decision

Static adoption is safe for the exact 20 accepted products plus the SSE product/test on c553f6987875f39871a7de43b4f65115c25511c0 (tree 3e1081bcbb7dfb6231372f6333a3427e303b13b5). This is not execution or release acceptance. No tests/services, source writes, ledger, index or refs were changed by this review. Only this new audit directory was written.

All 20 accepted candidate hashes match. All 20 destinations are unchanged between 0a56 and c553. The 6 existing 38 destinations match their historical baseline hashes exactly; the remaining 11 destinations are absent. Three clone products have no overlap with 38. See product-preimages.json.

The SSE product 23f79fd4c5e5ae45d799cb5f5b20328b4591339a25c098eba206eac3a3549015 reverses mechanically to the exact delivery self_service.go preimage 623027de633978816002d382444e8a28ba243bb306891a904113ddd48ff3d998. The new generation_http_test.go cef17a978bc70d5aaef456831b488e11706960170ea4dac3bac6815c5c779796 has no existing HEAD destination. Actual server assembly and lifecycle ordering are retained.

## Clone completeness and regression-test maintenance

Adopt the complete 49aa8e57 backend file, not successor01.patch alone. Full diff against c553 includes literal name preservation, Python-whitespace icon inheritance, folder membership source shapes, cache-before-SQL publication, actual typed SQLite failure classification, and the separated post-install folder phase. The recorded boundary proof and independent preexec review establish that the later literal-field successor did not replace these accepted combined functions. The SFC 9988a905 equals the accepted combined SFC; safePluginIcon and identity helpers remain unchanged. This composes earlier credit rather than reexecuting it.

Delivery web/tests/plugin-clone.test.mjs still rejects invalid display version and stored unsafe icon (root at line 332). It must be updated to the already accepted literal successor, or the delivered test suite contradicts the approved new contract. Candidate file SHA 756f2a84f3a770d39dadb59f032df301de5d8814f405839f8fd658f9ca6392b6 is already available. Preserve unrelated roots and compare its preimage before adoption.

## Minimum new final-composition gates

1. Build the actual clean delivery composition and actual frontend assets. Bind exact inputs/output and later final commit tree. Do not overlay 0a56 runtime/http/modules carriers onto S08. If clean worktree builds directly, old carriers are unnecessary.
2. Existing targeted clone literal App normal/race root TestCloneDisplayLiteralApprovalActualSDK; optional-field/icon-resource/suffix-transport/literal-transport UI roots where the source/test assembly changes. This is finite revalidation of the combined target, not rerunning old name/folder/source matrices.
3. Existing 38 App roots TestOriginalBuiltinClockBudgetPolicy, TestOriginalBuiltinActualWorkerCompositionPresenceAndCold, TestOriginalBuiltinActualWorkerFaultsManualAndResave, with the authentic existing calendar fixture helper. These exercise new clock dispatch and clone/storage lifecycle interaction. The pure source Calendar19/combining16/annex8/nullkwargs4 matrices are inherited, not regenerated.
4. SSE positive normal/race TestGenerationHTTP.* plus TestServerGenerationCloseOrderAndFailureReceipt, TestSelfServiceProtocolAndOriginalWaitDecision, TestSelfServiceStatusReaderBoundedAndClosed. Retain the sealed old negative control; no need to repeat it if candidate and seam are unchanged. Existing App SSE authentication/prefix/disconnect, session revocation/App stop, Fetch Metadata roots bound actual final composition are suitable finite protection.
5. S08 relevant narrow seam is TestOriginalMediaServerAssemblyNativeInputsAndAuthority (App parent cancellation, private authority and close lifecycle). The full vendor SDK/cold matrix is not newly implicated simply by adding clone/clock candidates.
6. At least one actual ordinary normal-mode combined server lifecycle: loaded 15 and 38 candidates, clone/card metadata readback and scheduler/manual/progress readback, then owned stop with actual terminal Wait exit0 and generation status. Reuse existing approved data/fixtures if suitable. A second actual browser full matrix is not needed merely to recertify the already accepted exact UI candidates; frontend byte changes beyond the known composition need their own affected UI check. Safe-mode exit0 alone cannot close normal plugin/runtime composition. If claiming actual process restart, run a real supervisor restart cycle; TCP generation-only cancellation must not be represented as subprocess restart.

## Tests and missing helper recovery

Available archive: materialized/parent38-upstream-recovery01/host-terminal-s13-cli-pending-s01-tls-20261101T1049.tar.gz.
- target-drafts/trigger-combining-target01/host04/tests02/plugin_original_builtin_policy_test.go.txt: 7a561dcd6bc4449acf272b880dbaba6766f6e050e776f621e2f803a74c7639cf.
- target-drafts/trigger-combining-target01/host04/tests02/plugin_original_builtin_worker_test.go.txt: 2aefe4a14f421b3826957cef602bc6b967b752fb372950d111a4adbe5f3e8398.

Their required calendar helper is not in that archive. Scanning current materialized tar members did not locate the following prerequisite source files. Exact historical execution input maps permit validating a later recovery:
- target-drafts/calendar-interval01/app-tests02/plugin_original_calendar_interval_test.go.txt: d8140695dc5f9b384e3b32b13d8b23c006fdc5622da003abc2f7cef721a2efa3, 19509 bytes.
- target-drafts/clone-name-literal01/formatted-candidate02/internal/app/plugin_clone_name_literal_test.go: b7fbc17438a4c760f370e2038e108b5612b6384d79782e4e3640a0855fc66c04, 9329 bytes.
- target-drafts/clone15-combined01/cli01/fixture01/formatted-candidate01/cmd/owned-module-override/main.go: e8527791c44a94d38eb18241801afb78b47c1a6dcda4422d9950b94649dfae36, 22626 bytes. Existing accepted worker binary may be reused with truthful identity; it is not a newly built worker.
- Optional old folder-test compilation helper source: clone15-combined01/source/internal/app/plugin_clone_folder_failure_test.go: 75eb55cfa195ec32f209d5b28a557d830bde1a6cffcc7ac95ce80601eed96014, 13883 bytes.
- Ordinary metadata fixture if including that root: clone15-combined01/source/internal/app/testdata/clone-metadata-ordinary-source02.json: c4eae28ce4f68308d87e7f652799e21eb89638b39becf0205f543f7d0d67e7e1, 63812 bytes.

Do not reconstruct missing historical helpers and call them byte-identical. Restore from earlier backup, or explicitly review and validate a new finite helper instead. Missing helper recovery is an execution-preparation gap, not evidence that already accepted historic results are invalid.

## Whole-item release gates

Old browser UI gates are closed separately. Remaining gates are exact final product/test/dist composition, the finite directed combined-build/runtime checks above, normal lifecycle anomaly disposition, independent final evidence/commit-tree binding, public-safe evidence packaging and ledger update, then authorized plugins-refactor publication. No main merge or deployment is in scope. Preserve all historic exit1 and negative receipts. The SSE controlled counterexample explains a verified mechanism but does not identify the exact request behind every historical browser timeout. Do not expose private data/logs/credentials as evidence.
