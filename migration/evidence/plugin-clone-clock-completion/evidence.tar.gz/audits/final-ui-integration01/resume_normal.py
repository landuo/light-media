#!/usr/bin/env python3
"""Resume exact owned normal instance; no secret reads, credential request or bootstrap."""
from pathlib import Path
import datetime, hashlib, json, os, queue, signal, sqlite3, subprocess, threading, time
B=Path('/workspace/scratch/a1d82674c6f8/plugin-platform-recovery-20261102T1545')
D=B/'audits/secure-admin-resume-20261104T0238'
E=B/'evidence/final-ui-integration-normal01'
P=B/'test-instances/clone15-browser-secure-setup02/private'
S=B/'target-drafts/s08-git-delivery-worktree01/work/final-ui-integration01/server'
EXPECTED='81f3288fce4dbc8b2a01bb1bfabe8d3ea10b7684ef3f529bc5e0f1769d7ccbd5'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    assert hashlib.sha256(S.read_bytes()).hexdigest()==EXPECTED
    old=json.loads((B/'evidence/sse-generation-browser-safe-resume06/result.json').read_text())
    assert old['stop_reason']=='owned_STOP_file'
    assert 'exit_code' in old, 'prior held Wait must be terminal'
    prerequisites=D/'safe-ui-prerequisites.json'
    assert hashlib.sha256(prerequisites.read_bytes()).hexdigest()=='2a9fe66f6ddb9359492ef206a9ce6a921e970be94ecbea5454a79b691a346e8d'
    assert any(x['event']=='service_generation_exited' for x in old['events'])
    assert old['exit_code']==0 and old['status']=='OWNED_SAFE_SERVICE_STOPPED'
    tests=json.loads((B/'evidence/final-ui-integration-go01/result.json').read_text())
    assert tests['status']=='PASS' and tests['programs']['server']['sha256']==EXPECTED
    con=sqlite3.connect((P/'data/light-media.db').as_uri()+'?mode=ro',uri=True)
    count=con.execute('SELECT COUNT(*) FROM admin').fetchone()[0]
    inventory=con.execute('SELECT instance_id, plugin_id, version, installed FROM plugin_installations ORDER BY instance_id').fetchall(); con.close()
    assert len(inventory)==3 and all(x[3] for x in inventory), 'expected retained three-fixture inventory'
    assert count==1, 'existing administrator required; never initialize a new account'
    assert 'PLUGIN_MARKET' not in os.environ and not os.environ.get('LIGHT_MEDIA_MEDIA_ROOTS')
    raw=os.environ.get('LIGHT_MEDIA_SAFE_MODE',os.environ.get('MOVIEPILOT_SAFE_MODE'))
    assert raw is None or raw.lower() in ('0','false','f','no','n','off'), 'effective safe mode must be false; do not change environment'
    env=os.environ.copy()
    E.mkdir(exist_ok=False)
    L=P/'final-ui-integration01'; L.mkdir(mode=0o700,exist_ok=False)
    r={'status':'STARTING','started':now(),'baseline':'c553f6987875f39871a7de43b4f65115c25511c0','inventory_before':inventory,'scope':'combined normal runtime readback and clean stop; inherited business matrices not replayed','server_sha256':EXPECTED,'same_private_data':True,'endpoint':'http://127.0.0.1:39123','safe_mode':False,'bootstrap_used':False,'credential_fields_read':False,'admin_count_before':count,'new_credential_request':False,'launch_surface':'CUA native Terminal','events':[]}
    def save(): (E/'result.json').write_text(json.dumps(r,indent=2)+'\n')
    child=None; reader=None; q=queue.Queue(); save()
    try:
        with (L/'server.stdout').open('xb') as out,(L/'server.stderr').open('xb') as err:
            child=subprocess.Popen([str(S),'-data-dir',str(P/'data'),'-listen','127.0.0.1:39123'],cwd=B/'target-drafts/s08-git-delivery-worktree01',stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=err,env=env)
            r['supervisor_pid']=child.pid;save()
            def collect():
                for line in iter(child.stdout.readline,b''):
                    out.write(line);out.flush()
                    try: value=json.loads(line)
                    except (ValueError,UnicodeError): continue
                    if isinstance(value,dict) and value.get('event') in ('service_generation_started','service_generation_ready','service_generation_exited'):q.put(value)
                q.put(None)
            reader=threading.Thread(target=collect);reader.start()
            deadline=time.monotonic()+45
            while True:
                assert child.poll() is None,'owned supervisor exited before ready'
                value=q.get(timeout=max(.01,deadline-time.monotonic()))
                assert value is not None,'owned stdout closed'
                assert value['supervisor_pid']==child.pid
                r['events'].append(value);save()
                if value['event']=='service_generation_ready':break
            r.update(status='READY_EXISTING_ADMIN_NORMAL_MODE',ready_at=now());save();print(json.dumps(r),flush=True)
            deadline=time.monotonic()+1800
            while time.monotonic()<deadline and not (E/'STOP').exists():
                assert child.poll() is None,'owned supervisor prematurely exited'
                time.sleep(.2)
            r['stop_reason']='owned_STOP_file' if (E/'STOP').exists() else 'bounded_browser_window_elapsed'
            r['stop_requested_at']=now();save()
            child.send_signal(signal.SIGTERM)
            # No force kill or PID signalling. Keep the original subprocess Wait.
            code=child.wait()
            reader.join();reader=None
            while not q.empty():
                value=q.get()
                if value is not None:
                    assert value['supervisor_pid']==child.pid
                    r['events'].append(value)
            r.update(status='OWNED_NORMAL_SERVICE_STOPPED' if code==0 else 'OWNED_NORMAL_SERVICE_EXITED_NONZERO',exit_code=code,ended=now(),environment_unchanged=os.environ==env)
            r['stderr_bytes']=(L/'server.stderr').stat().st_size
            con=sqlite3.connect((P/'data/light-media.db').as_uri()+'?mode=ro',uri=True)
            r['inventory_after']=con.execute('SELECT instance_id, plugin_id, version, installed FROM plugin_installations ORDER BY instance_id').fetchall(); con.close()
            r['inventory_unchanged']=r['inventory_after']==inventory
            save();print(json.dumps(r),flush=True)
    except BaseException as exc:
        r.update(status='FAILED',error_type=type(exc).__name__);save();raise
    finally:
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGTERM);code=child.wait()
            r.update(final_wait_exit_code=code,final_wait_at=now());save()
        if reader is not None:reader.join()
if __name__=='__main__':main()
