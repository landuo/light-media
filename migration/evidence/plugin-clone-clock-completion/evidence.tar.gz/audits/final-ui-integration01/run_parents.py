from pathlib import Path
import datetime,hashlib,json,os,subprocess
B=Path(__file__).resolve().parents[2];A=B/'target-drafts/s08-git-delivery-worktree01';E=B/'evidence/final-ui-integration-parents01';D=Path(__file__).resolve().parent;P=A/'work/final-ui-integration01'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap(paths):return {str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(paths)}
E.mkdir(mode=0o700);assert P.is_dir()
env=os.environ.copy();env.update(GOMAXPROCS='2',CGO_ENABLED='1',GOPROXY='off',GOSUMDB='off',OWNED_MODULE_OVERRIDE_BINARY=str(P/'clone-worker'),OWNED_INPUT_FIXTURE_BINARY=str(P/'input-worker'))
r={'status':'RUNNING','started':now(),'base':'c553f6987875f39871a7de43b4f65115c25511c0','cwd':str(A),'commands':[],'kind':'final physical composition no overlay; finite current-host seams only','programs':{}}
def save():(E/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,c):
 v={'label':label,'argv':c,'started':now()};r['commands'].append(v);save()
 with (E/(label+'.stdout')).open('xb')as out,(E/(label+'.stderr')).open('xb')as err:p=subprocess.run(c,cwd=A,env=env,stdout=out,stderr=err)
 v.update(exit_code=p.returncode,ended=now());save();assert p.returncode==0,label
 return (E/(label+'.stdout')).read_text()
paths={D/'run_parents.py',A/'go.mod',A/'go.sum'}
def capture(label,packages,tests=False,race=False):
 raw=run(label,['go','list','-mod=readonly','-buildvcs=false','-deps','-json',*(['-test']if tests else []),*(['-race']if race else []),*packages]);dec=json.JSONDecoder();i=0;decl=[]
 while i<len(raw):
  while i<len(raw)and raw[i].isspace():i+=1
  if i==len(raw):break
  p,i=dec.raw_decode(raw,i);assert not p.get('Error')and not p.get('DepsErrors'),p
  m=p.get('Module')or{}
  for f in [m.get('GoMod'),(m.get('Replace')or{}).get('GoMod')]:
   if f:paths.add(Path(f))
  if not p.get('Dir'):continue
  for kind in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','FFiles','SFiles','SwigFiles','SwigCXXFiles','SysoFiles','EmbedFiles',*(['TestGoFiles','XTestGoFiles','TestEmbedFiles','XTestEmbedFiles']if tests else[])]:
   for f in p.get(kind,[]):
    path=Path(p['Dir'])/f;assert path.is_file(),path;paths.add(path);decl.append({'path':str(path),'package':p.get('ImportPath'),'kind':kind})
 (E/(label+'-declarations.json')).write_text(json.dumps(decl,indent=2)+'\n')
try:
 goenv=json.loads(run('go-env',['go','env','-json','GOROOT','GOVERSION','GOOS','GOARCH','CGO_ENABLED','GOTOOLCHAIN','GOPROXY','GOSUMDB','GOCACHE']))
 assert goenv['GOTOOLCHAIN']=='local'and goenv['GOPROXY']=='off'and goenv['GOSUMDB']=='off'
 gr=Path(goenv['GOROOT']);paths.add(gr/'bin/go');paths.update(p for p in(gr/'pkg/tool'/(goenv['GOOS']+'_'+goenv['GOARCH'])).iterdir()if p.is_file())
 capture('build-inputs',['./cmd/owned-module-override'])
 capture('test-inputs',['./internal/app'],True)
 capture('race-inputs',['./internal/app'],True,True)
 before=snap(paths);(E/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');r['input_count']=len(before);save()
 cache=Path(goenv['GOCACHE'])
 for p in paths:
  if p.is_relative_to(cache):
   dest=E/('generated-'+before[str(p)]['sha256']+'.go')
   if not dest.exists():dest.write_bytes(p.read_bytes())
 paths.add(P/'input-worker');before=snap(paths);(E/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');r['input_count']=len(before)
 run('build-clone-worker',['go','build','-mod=readonly','-buildvcs=false','-p=1','-ldflags=-X main.fixtureProcessAPI=1','-o',str(P/'clone-worker'),'./cmd/owned-module-override']);r['programs']['clone-worker']=dict(snap([P/'clone-worker'])[str(P/'clone-worker')],path=str(P/'clone-worker'));save()
 app='^(TestCloneDisplayLiteralApprovalActualSDK|TestOriginalBuiltinClockBudgetPolicy|TestOriginalBuiltinActualWorkerCompositionPresenceAndCold|TestOriginalBuiltinActualWorkerFaultsManualAndResave|TestOriginalMediaServerAssemblyNativeInputsAndAuthority)$'
 for race in [False,True]:
  run('parents'+('-race'if race else '-normal'),['go','test','-mod=readonly','-buildvcs=false','-p=1',*(['-race']if race else[]),'-count=1','-timeout=180s','-json','-run='+app,'./internal/app'])
 after=snap(paths);(E/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert after==before,'resolved input drift'
 r['status']='PASS';r['input_drift']=[]
except BaseException as ex:r.update(status='FAILED',error=str(ex));raise
finally:r['ended']=now();save();print(json.dumps(r),flush=True)
