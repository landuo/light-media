from pathlib import Path
import datetime,hashlib,json,os,subprocess
B=Path(__file__).resolve().parents[2];A=B/'target-drafts/s08-git-delivery-worktree01';E=B/'evidence/final-ui-integration-frontend01';N=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'); M=(A/'web/node_modules').resolve()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap(paths):return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
E.mkdir(mode=0o700)
paths={N,*[p for p in M.rglob('*') if p.is_file()],*[p for p in (A/'web').rglob('*') if p.is_file() and '/node_modules/' not in str(p) and '/dist/' not in str(p)]}
paths.update(p for p in (A/'internal/plugins').rglob('*') if p.is_file())
before=snap(paths);(E/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
r={'status':'RUNNING','started':now(),'input_count':len(before),'commands':[],'kind':'same delivery worktree exact pinned dependency reuse; no browser gate replay','build_preservation':'Vite --emptyOutDir false retains old tracked hash assets; generated index references fresh assets; no deletion'}
def save():(E/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 c=[str(N),*args];v={'label':label,'argv':c,'started':now()};r['commands'].append(v);save()
 with (E/(label+'.stdout')).open('xb')as out,(E/(label+'.stderr')).open('xb')as err:p=subprocess.run(c,cwd=A/'web',stdout=out,stderr=err)
 v.update(exit_code=p.returncode,ended=now());save();assert p.returncode==0,label
try:
 run('icons',['scripts/build-icons.mjs']);run('utilities',['scripts/build-plugin-utilities.mjs'])
 run('types',[str(M/'vue-tsc/bin/vue-tsc.js'),'--noEmit'])
 run('clone-ui',['--experimental-transform-types','--disable-warning=ExperimentalWarning','--test','tests/plugin-clone.test.mjs'])
 run('build',[str(M/'vite/bin/vite.js'),'build','--emptyOutDir','false'])
 after=snap(paths);(E/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
 r['input_changes']=[p for p in before if before[p]!=after[p]]
 assert not r['input_changes'],r['input_changes']
 dist=snap(p for p in (A/'web/dist').rglob('*') if p.is_file());(E/'dist.json').write_text(json.dumps(dist,indent=2)+'\n');r['dist_count']=len(dist);r['status']='PASS'
except BaseException as ex:r.update(status='FAILED',error=str(ex));raise
finally:r['ended']=now();save();print(json.dumps(r),flush=True)
