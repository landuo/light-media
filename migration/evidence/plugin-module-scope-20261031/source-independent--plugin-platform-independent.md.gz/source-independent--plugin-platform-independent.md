# 插件平台独立源发现（仅盘点）

固定源：`/Users/accidia/projects/MoviePilot`，提交 `8a83efeacd3e26b82be495e17d50146e31c96a60`。所有源内容来自 `git ls-tree` / `git show` 固定对象；没有启动、导入或执行源应用，没有读取生产配置/凭据，没有查看目标已有实现结论或修改权威账本。

用户已把范围纠正为「插件模块」。下表为插件平台可观察职责与插件调用宿主的边界；不把 `app/modules` 的31个内置模块列为必须全迁移。此前内置模块发现仅作依赖附录。

## 数量与证据边界

- 独立识别20组源职责：19组普通平台职责保留，官方授权门禁1组按用户明确决定排除；另有28个插件管理API路由处理器。计数是源发现分组，不是迁移或测试通过数量。
- 固定提交的 `app/plugins` 仅有 `app/plugins/__init__.py`，没有具体第三方插件实现。因此不能从本源树证明实际业务插件实现；这属于取证边界。当前范围无业务插件开发，后续只用验收插件核对平台，不以此要求移植旧插件。
- JSON保存逐符号签名/行号、路由、普通/AI/工作流消费者分类；本轮没有运行等价验证。

## 普通插件平台职责

| ID | 职责 | 精确源证据 | 必须核对的可观察语义 |
|---|---|---|---|
| PP01 | 插件身份、已安装/本地/运行态与顺序 | `app/core/plugin.py:72-119` | UserInstalledPlugins 清单→选择性导入→plugin_order 排序→Class/instance 分离；init_plugin 后依 get_state 启停事件。 |
| PP02 | 停止、重载与失败后的模块清理 | `app/core/plugin.py:156-265` | 停事件、close/stop_service、清运行态/类/导入缓存；重新加载广播 PluginReload。补充619-688。 |
| PP03 | 插件配置与表单默认值 | `app/plugins/__init__.py:239-256` | plugin.{PluginID} 持久配置；同步/异步保存；默认字段与已保存字段合并；保存→init_plugin→重注册服务/命令/API。 |
| PP04 | 插件运行数据、数据目录和重置 | `app/plugins/__init__.py:258-326` | 按插件隔离文件目录与KV数据；数据保存/读取/删除及异步契约；重置先PluginDataReset事件，再停止、删除配置数据、重载。 |
| PP05 | 市场/本地仓库、版本与兼容信息 | `app/core/plugin.py:1332-1849` | 多市场和本地仓库候选、最高版本去重、元数据/状态/has_page、列表过滤与排序；官方认证等级门禁按用户决定排除。 |
| PP06 | 安装/更新、Release与恢复 | `app/helper/plugin.py:620-995` | 仓库文件列表、精确Release zip或本地来源；兼容版本检查、下载失败/依赖失败补偿、持久备份；异步对应2689-2949。Python安装机制仅作源语义证据，后续对照已有Go产物候选；本轮不设计或实现。 |
| PP07 | 安装统计、评分与更新说明 | `app/api/endpoints/plugin.py:295-557` | 列表不必批量访问网络，更新历史/Release按需拉取；安装统计、批量/单插件评分与评分写入。 |
| PP08 | 插件分组文件夹 | `app/api/endpoints/plugin.py:843-930` | 读取/保存完整分组；建组、删组、修改组内插件；克隆加入原组、卸载移出组。 |
| PP09 | 插件分身及隔离身份 | `app/core/plugin.py:1905-2235` | 独立ID、复制初始配置且enable/enabled默认关闭、改写Python类和前端联邦标识/资源；安装与卸载语义有分身区别。Go需保留隔离行为。 |
| PP10 | 插件远程命令 | `app/plugins/__init__.py:75-86` | cmd/event/desc/category/data 注册；仅启用插件产生命令；宿主Command以pid关联并发送事件，支持命令注册拦截。 |
| PP11 | 插件定时服务 | `app/plugins/__init__.py:128-139` | id/name/trigger/func/kwargs/func_kwargs；启用插件聚合；宿主按pid隔离job、更新先删除旧job、卸载删除job。 |
| PP12 | 插件自定义API与鉴权 | `app/api/endpoints/plugin.py:114-233` | get_api 声明→插件ID命名空间→v1/v2路由；apikey或bear及显式allow_anonymous；更新移除旧路由并重建OpenAPI。 |
| PP13 | 表单/详情页、Vue联邦与静态资源 | `app/api/endpoints/plugin.py:649-839` | Vuetify JSON与Vue两模式；form/page/remotes；remoteEntry.js；静态文件资源鉴权、目录边界、流式与MIME；普通页面不因AI排除。 |
| PP14 | 单/多仪表盘与旧签名兼容 | `app/core/plugin.py:1191-1271` | dashboard meta/key；旧0参、user_agent和key签名；cols/attrs/elements三元数据；无/非法返回及错误状态。 |
| PP15 | Vue插件侧栏导航 | `app/core/plugin.py:1133-1189` | 仅启用Vue插件；nav_key验证、section/permission归一化、顺序排序；基类未声明get_sidebar_nav也可动态实现。 |
| PP16 | 插件登录认证入口 | `app/core/plugin.py:1092-1131` | 启用插件声明认证provider，附type/plugin_id、默认组件及联邦remote；auth API与匿名远程登录静态文件依赖。 |
| PP17 | get_module宿主覆盖 | `app/chain/__init__.py:225-517` | 启用插件按plugin_order形成方法映射；插件优先，None/全None tuple继续、list合并、其他值(含False/0/空dict)阻止系统；同步/异步、线程池、异常与限流语义。 |
| PP18 | 事件、通用方法调用与主动宿主调用 | `app/plugins/__init__.py:40-50` | 基类注入chain/systemconfig/plugindata/systemmessage/eventmanager；动态方法调用1286-1318；插件事件回调按类名解析。实际宿主边界按验收插件/明确平台契约核对，不能扩张成31模块或业务插件全迁移。 |
| PP19 | 开发热重载与本地源码同步 | `app/core/plugin.py:283-616` | DEV/PLUGIN_AUTO_RELOAD/PLUGIN_LOCAL_REPO_PATHS变更；文件watch、本地plugins/plugins.v2来源区别、已安装插件同步、Vue构建产物变化。 |
| PP20 | 官方插件授权等级/RSA门禁：用户明确排除 | `app/core/plugin.py:1852-1903` | 不迁移官方SitesHelper等级/RSA门禁，且不构成阻塞；普通应用登录、API/资源鉴权和插件认证provider继续保留。 |

## 最容易漏掉的装配/行为

1. `app/core/plugin.py:72-119` 根据已安装列表导入并初始化，`get_state()`决定事件启停；不是只实例化启用插件。`get_plugin_modules`/commands/services/dashboard meta检查启用状态，但`get_plugin_apis`并不检查`get_state`（873-903）。
2. `app/chain/__init__.py:225-232,298-370,470-517`：只把None或全None tuple视为空。False、0、空dict和空字符串均是可终止系统回落的插件结果；list继续聚合，包括空list。插件覆盖顺序来自plugin_order与运行注册顺序；重载后的实际顺序也需核对。进入系统模块后，`check_signature`还可将前一结果作为单参数继续处理（372-468），不能只实现list合并。同步/异步和错误传播不能丢失。
3. `app/api/endpoints/plugin.py:223-233,976-989`：保存配置后重新生效插件、更新定时服务、命令和动态API。`app/scheduler.py:1338-1390`按pid命名job并先移除旧服务；排除工作流不得删整份Scheduler。
4. `app/plugins/__init__.py:40-50`与`app/core/plugin.py:1286-1318`允许插件主动调用处理链、数据、系统配置、消息、事件及动态插件方法；具体必要宿主依赖只能从实际插件源码反向提取。
5. 重置顺序是补偿事件→停止→删配置/数据→重载（API742-761）；普通卸载保留配置/数据，分身卸载额外删除配置、数据和目录（993-1030）；克隆默认双enable字段关闭并隔离ID（core1905-2002）。

## AI/工作流：按符号拆，不按混合文件删

| 文件 | 排除/拆分的符号 | 普通部分仍在范围 |
|---|---|---|
| `app/plugins/__init__.py:202-230` | `get_actions`；`get_agent_tools` | `get_module`、命令、API、表单/详情、服务、仪表盘、认证入口、数据/消息均为普通插件接口 |
| `app/core/plugin.py:58-61,141-154,958-1049` | 工作流`get_plugin_actions`；AI工具注册/复制/版本/缓存；生命周期中的对应缓存失效调用 | 插件生命周期、普通扩展聚合、市场/安装、权限、Vue、分身等 |
| `app/agent/tools/factory.py:273`、`app/agent/tools/impl/*plugin*.py` | 智能体调用/查询插件的工具 | 不应反向排除它们调用的普通PluginManager接口 |
| `app/api/endpoints/workflow.py:73`、`app/workflow/actions/invoke_plugin.py:56` | 工作流获取/执行插件actions | 命令、普通定时服务和get_module覆盖不等于workflow |
| `app/scheduler.py` | 工作流调度段 | `update_plugin_job:1338`、init/remove插件job与正常服务调度保留 |
| `app/chain/__init__.py:1949-1962` | `edit_message`内WebAgent专用分支 | 普通渠道通知/命令/处理状态继续按具体插件需要界定 |

## 范围决定与证据限制

- 当前只迁移插件平台，不开发/重写实际业务插件。固定树无业务插件属于证据限制；后续用验收插件验证get_module、主动宿主调用、事件、数据及定时服务契约，不把旧23插件开发带入当前范围。
- 全Go/Linux本地/单用户继续保留。Python动态导入、pip/requirements/wheels和AST改写分身属于源运行机制；后续对照已有Go产物/克隆实现候选的可观察行为。本轮不要求重新设计，也不执行实现。
- 用户明确“不需要认证”指官方SitesHelper等级/RSA插件门禁（core:1852-1903）：排除，不构成阻塞。普通站点索引/账户是不同用途，仍需按保留平台/验收契约核实必要性；固定树该类源码缺失不等于全部相关功能都必须迁移。
- UI分发：Vue remoteEntry与Vuetify JSON后端契约可定位；具体宿主前端组件、编译版本和插件前端资产需另绑定。普通登录provider、资源token、API鉴权在单用户约束下仍有用途。
- 远程市场/Release、评分统计、Linux本地存储等按平台合同核对；官方插件授权专用密钥已排除。不自动扩成迁移所有内置下载器/媒体服务器/通知通道。

## 取证文件

| 文件 | 用途 |
|---|---|
| `plugin-platform-independent.json` | 当前范围：平台职责、精确符号/路由、消费者、排除符号、未决依赖 |
| `modules-source-inventory.json` | 附录：31个可注册内置模块、137文件；不是必须迁移清单 |
| `modules-contracts-entrypoints.json` | 附录：内置模块方法与chain/API静态索引，包含尚未裁剪的宿主参考 |
| `ordinary-dependency-boundary-references.json` | 附录：Redis/PostgreSQL/消息协议普通依赖定位 |

验证状态：只读静态源发现。未执行旧服务、新实现、生产插件、安装、网络市场请求或等价测试；不声明迁移完成。
