# 插件模块独立入口发现（本轮主范围）

固定后端 8a83efeacd3e26b82be495e17d50146e31c96a60；前端 2829e3b08214348f05ff2f5beae644882eccad58。

仅静态发现；未运行/修改源、未读取目标实现结论、未开始迁移/部署或写权威账本。宽业务发现仅为附录。

## 插件功能组

- PLUGIN-SRC-01 注册、加载、生命周期、同步与热重载：UserInstalledPlugins 选择性导入运行目录中的插件包，按 plugin_order 加载；认证条件决定是否实例化；实例化→init_plugin(config)→按 get_state 启停事件处理；保存配置再次生效；stop 先禁用事件，调用 close/stop_service，清理实例、Class 和所有子模块缓存；失败导入也清理缓存；DEV/PLUGIN_AUTO_RELOAD 监控运行与本地仓库源码，已安装本地插件同步后热重载并发送 PluginReload；启动插件→注册 API，后台 sync/缺失依赖安装后重建插件、API、调度与命令；关闭时备份并停止。
  证据：app/core/plugin.py:72；app/plugins/__init__.py:53；src/components/cards/PluginCard.vue:149。
- PLUGIN-SRC-02 仓库、市场、Release、安装升级和回滚：GitHub 与本地插件仓库；package.json/package.<version>.json 版本回退、仓库顺序/去重/最高版本选择；系统版本范围兼容、插件 auth_level/特殊公钥门槛、仅已解析的 Release tag 和同名 ZIP 资产可安装；仓库级分页 Release 缓存、在途请求合并、强刷与旧响应隔离；文件列表与 Release 两种下载路径；安装备份→准备内容→安装依赖→刷新持久备份；失败还原旧插件；本地同步保留来源协议；依赖合并/缺失检查、uv/pip/索引/代理/直连降级、wheels 与 cache、安装统计；市场仓库 Wiki 同步。
  证据：app/helper/plugin.py:252；src/components/dialog/PluginMarketSettingDialog.vue:112。
- PLUGIN-SRC-03 已安装/市场目录、状态、更新说明、评分统计：已安装和市场两页，按名称/启用/更新、作者/标签/仓库过滤，排序与追加展示；本地安装、运行态、页面能力、版本、来源、兼容提示、更新说明和可选 Release 版本；插件安装统计、批量/单项评分查询和评分提交，中心不可用时的回退口径；按需获取更新详情，避免加载整个市场触发所有远程请求。
  证据：app/api/endpoints/plugin.py:343；src/views/plugin/PluginCardListView.vue:789。
- PLUGIN-SRC-04 配置表单、默认值、保存、生效与重置：get_form returns vuetify schema or Vue mode and model defaults; stored values merge over defaults；JSON component schema rendering supports model/v-model/show/v-show/arguments/slots and model expressions；Vue Config component receives model/API; save updates config, re-initializes plugin, re-registers service/commands/API；reset emits PluginDataReset compensation before stop, force-deletes config/data then reloads；异常/未加载插件返回错误，不能以空对象或 UI 卡片充作真实表单功能。
  证据：app/api/endpoints/plugin.py:648；app/plugins/__init__.py:112；src/components/dialog/PluginConfigDialog.vue:86。
- PLUGIN-SRC-05 插件配置、DB 键值、文件目录和资源生命周期：_PluginBase injects PluginDataOper/SystemConfigOper/MessageHelper/EventManager and PluginChian；config defaults plugin_id to actual class name; per-plugin config namespace；save/get/del DB JSON data by plugin_id + key; sync and async get/save; all-data reads return rows；get_data_path creates PLUGIN_DATA_PATH/<id>; plugin close and stop_service manage own resources；normal uninstall and clone uninstall differ in config/data/files deletion。
  证据：app/plugins/__init__.py:40。
- PLUGIN-SRC-06 数据页、动态 API、静态文件和联邦组件：get_page/render_mode yields Vuetify page schema or Vue remote Page; recursive page events call GET/POST and refresh；plugin APIs dynamically registered at v1 and v2 /plugin/<id>/..., removed/rebuilt on reload/uninstall; OpenAPI invalidated；auth defaults apikey; bear uses login token; allow_anonymous explicitly skips auth; dependencies preserved；static assets enforce contained plugin path, MIME for JS/MJS/CSS, streaming; normal resources use resource cookie；Vue remotes resolve remoteEntry.js and expose Config/Page/Dashboard/AppPage/AuthPage; Auth remote static exception is narrowly declared。
  证据：app/api/endpoints/plugin.py:114；app/plugins/__init__.py:89；src/components/dialog/PluginDataDialog.vue:79。
- PLUGIN-SRC-07 仪表板元信息、旧/新签名与刷新：enabled plugins can provide legacy single dashboard or get_dashboard_meta multiple keys；get_dashboard accepts legacy parameter counts or key/user_agent; exactly 3 tuple/list elements required；cols layout, attrs refresh/border/title/subtitle and recursive elements; Vuetify or Vue Dashboard；dashboard selection/order user config, scheduled auto refresh and cleanup。
  证据：app/api/endpoints/plugin.py:704；app/plugins/__init__.py:141；src/components/misc/DashboardElement.vue:1。
- PLUGIN-SRC-08 侧栏多入口、完整应用页与最近插件：enabled Vue plugins get_sidebar_nav with nav_key/title/icon/section/permission/order; validates and stable sorts；route /plugin-app/:pluginId/:navKey? loads AppPage or AppPage{Pascal} with generic fallback；remote full-page receives api/nav-key/plugin-id; desktop sidebars and app center share entries；PluginOrder, folder and mixed sorting; recent plugins and quick access。
  证据：app/core/plugin.py:1133；src/router/index.ts:171。
- PLUGIN-SRC-09 文件夹、混合排序与分身：folder create/rename/configure/delete, plugin membership, drag/drop, main/folder/mixed sorting；supports legacy list and new object folder formats; config includes order/icon and independent plugin order；clone copies code/assets, renames class/config prefix/name/desc/version/icon, adds is_clone and rewrites federation files；clone id suffix lowercased, copies config then force-disables enable/enabled, reloads and inherits original folder；clone uninstall removes clone config/data/package dir; ordinary uninstall removes installed flag/API/services/folder references and runtime instance。
  证据：app/api/endpoints/plugin.py:842；src/views/plugin/PluginCardListView.vue:520。
- PLUGIN-SRC-10 普通事件、链式拦截和模块替换：plugins register normal EventType/ChainEventType listeners with priority/cancel/backoff; state disables listeners；broadcast and chain-interception dispatch resolve current plugin instances, allow sync/async handlers；PluginDataReset runs while plugin active; PluginReload refreshes services; MessageAction supports target-only plugin input；get_module mapping overrides ordinary host module calls; scalar result short-circuits, lists merge before system modules；ordinary naming/transfer/resource/discover/recommend/auth/subscription/storage hooks remain after dedicated AI/workflow hook removal。
  证据：app/core/event.py:176；app/plugins/__init__.py:49。
- PLUGIN-SRC-11 插件定时服务、普通命令和通知：get_service cron/interval/date triggers register <plugin_id>_<service_id>; func_kwargs separate from trigger kwargs；reload removes/replaces plugin jobs, standalone removes one/all jobs; running/progress/error status managed by ordinary Scheduler；get_command enabled plugin cmd/event/data becomes Command registry, registered to channels; execution emits plugin event；post_message builds Notification with default #/plugins link and uses ordinary channel/template/queue/history；plugin MessageHelper notices and pending plugin-input text/cancel/expiry handling are ordinary capabilities。
  证据：app/core/plugin.py:844；app/plugins/__init__.py:75；src/views/dashboard/AnalyticsScheduler.vue:1。
- PLUGIN-SRC-12 登录认证插件与一次性票据：enabled plugin get_auth_providers aggregated; Vue AuthPage remote metadata with defaults；public provider list and POST exchange; plugin creates short-lived one-time ticket for local account；consume removes ticket before TTL verification, max store size and expiry cleanup；pre-login loading permits only plugin-declared authentication remote resources; remaining static files require resource token。
  证据：app/core/plugin.py:1092；app/plugins/__init__.py:177；src/components/dialog/UserAuthDialog.vue:1。
- PLUGIN-SRC-13 插件日志、进度和运维支持：logger inspects callsite/plugin package, uses plugin-specific log file plus shared rotation/async buffering；log dialog wraps LoggingView SSE, popup stream and plugin-named archive download；plugin installation/config/deletion use generic progress/confirm/shared dialog infrastructure；module shutdown drains logging after other services。
  证据：app/log.py:345；app/helper/progress.py:9；src/components/dialog/PluginLogDialog.vue:39。
- PLUGIN-SRC-14 插件调用宿主的普通能力入口：_PluginBase.chain is PluginChian(ChainBase); generic plugin gets host settings/SystemConfig/data/event/message objects；ChainBase exposes media identify/detail/images/search, resource/subtitle/search/filter/download/client actions, transfer/file operations, existing-media check, categories, notifications/commands/cache；plugins may directly import app.chain.<domain>, helper, db/model, utils, schemas beyond base (not a sealed SDK)；host run_module and async_run_module themselves invoke plugin get_module before system implementation, so recursive behavior and scalar/list empty rules affect both directions；only actual installed plugin source/import closure can determine the minimal required ordinary adapters; all built-in modules are not automatically the current plugin scope。
  证据：app/chain/__init__.py:470；app/plugins/__init__.py:14。

## 关键拆分与盲区

`_PluginBase.get_actions`/`PluginManager.get_plugin_actions` 为工作流专属；`get_agent_tools` 及缓存/Agent 初始化专属。普通 get_module、get_api、get_service、get_command、get_dashboard、get_auth_providers、动态 get_sidebar_nav 不应随整文件排除。

插件→宿主由 PluginChian(ChainBase) 与直接 import 共同组成；从基类只能找到能力表面，无法代替实际已安装插件依赖闭包。

28 个插件管理 API 外，还需要 auth providers/exchange、system settings/wiki、日志 SSE/下载、user/config/PluginOrder、dashboard 组件与 sidebar/appcenter 等通用宿主支持。

官方 SitesHelper 等级与 RSA 已明确排除，不作为阻塞；普通登录/API/static 资源认证与 auth-provider 保留。真实插件包/分身/DB/数据目录/Release/依赖/联邦构建产物仍需各自固定来源。本轮无运行或验收声明。

## 对账补项

通用渲染、日志、AppCenter/Login/Auth、Dialog/Progress、Grid/InfiniteScroll、导航/API/cache 依赖及普通通知桥接详见 plugin-index-reconciliation.json。所有必要路径均在主索引中，但多项仍只标通用 support 且无插件 feature 绑定。未发现这些必要普通路径被整文件标 excluded。

普通通知：_PluginBase.post_message:328 → ChainBase.post_message:1631（模板/历史/NoticeMessage）→ MessageQueueManager.send_message:710 → _send:746 → run_module(post_message):470 → 既有普通发送器；不要求因此重写全部通知渠道。

## 更正记录：官方站点认证 UI

此前将 `src/components/dialog/UserAuthDialog.vue` 误列为普通插件登录 provider 依赖。固定源 `loadLastAuthParams:65` 读取 UserSiteAuthParams，`loadAuthSites:80` 与 `checkUser:94` 调用 GET/POST site/auth，因此改列明确排除的官方站点认证 UI。原误归类保留在两份 JSON 的 correction_history，不删除历史观察。

普通插件登录 provider 绑定 `src/pages/login.vue:208/249`、`app/api/endpoints/auth.py:42/54` 和 `app/core/auth.py:17`。当前必要前端支持为 31 项；`permission.ts` 仅做单用户可见性适配，不迁多用户权限体系。
