from pathlib import Path
import subprocess,json,time,hashlib
v=Path(__file__).resolve().parent;s=v.parent/'source'
files=[{'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(s.rglob('*')) if p.is_file()]
(v/'final-input.json').write_text(json.dumps(files,indent=2))
patterns=[('cancel-proof-normal','^TestPluginAutoBackup(CanceledRecoveryRequiresNativeEvidence|AuthenticatedAbandonImmediateResetAndProofRollback|SnapshotCutCancelsOnlyOwnRunAndPreservesUnknown|AuthenticatedAbandonKeepsUnknownEvidenceAndUnlocksNewRun|CancellationBeforeIntentDoesNotInventUnknown|CancellationAfterApplyBeforeReceiptRemainsUnknown|LifecycleWaitsOnlyInstanceGate)$'),('final-app-normal','^Test(PluginAutoBackup|AutoBackupActualServerNativeClonePrivateArchiveIsolation$|PluginNativeRetryClassificationKeepsLiveAttemptUnreplayable$|PluginNativeRetryRejectsChangedScopeAndSnapshots$|PluginNativeRetryColdProofRechecksBeforeClaim$|PluginNativeSubscribeInitRollbackCanRetryExactColdRun$|IYUUStartedAdmissionSurvivesColdBeforeHostEntry$)')]
for name,pattern in patterns:
 cmd=[str(v/'clean-go.sh'),'test','-p','1','-json','./internal/app','-run',pattern,'-skip','OwnedWebDAV','-count=1','-timeout','8m']
 (v/(name+'-plan.json')).write_text(json.dumps({'cmd':cmd},indent=2))
 start=time.time()
 with (v/(name+'.jsonl')).open('wb') as out,(v/(name+'.stderr')).open('wb') as err:p=subprocess.run(cmd,stdout=out,stderr=err)
 (v/(name+'.exit')).write_text(str(p.returncode)+'\n')
 changed=[f['path'] for f in files if hashlib.sha256((s/f['path']).read_bytes()).hexdigest()!=f['sha256']]
 (v/(name+'-result.json')).write_text(json.dumps({'exit':p.returncode,'seconds':time.time()-start,'source_changes':changed},indent=2));print(name,p.returncode,changed,flush=True)
 if p.returncode or changed:break
