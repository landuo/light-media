from pathlib import Path
import json,hashlib
v=Path(__file__).resolve().parent
out={}
for name in ['core-normal','app-normal','clone-red','focused-normal','cancellation-normal','cancel-proof-normal','final-app-normal','final-core-race','final-app-race']:
 p=v/(name+'.jsonl');e=v/(name+'.exit')
 if not p.exists()or not e.exists():continue
 events=[json.loads(l) for l in p.read_text().splitlines() if l.strip()];tests={a:sorted(x['Test']for x in events if x['Action']==a and'Test'in x)for a in ['pass','fail','skip']}
 out[name]={'exit':int(e.read_text()),'roots':{a:[t for t in names if '/'not in t]for a,names in tests.items()},'nodes':tests,'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((v/(name+'.stderr')).read_bytes()).hexdigest()}
(v/'execution-summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print({name:{'exit':r['exit'],'roots':{k:len(x)for k,x in r['roots'].items()},'nodes':{k:len(x)for k,x in r['nodes'].items()}}for name,r in out.items()})
