from pathlib import Path
import subprocess,json,time,hashlib
v=Path(__file__).resolve().parent;s=v.parent/'source';files=[]
for p in sorted(s.rglob('*')):
 if p.is_file():files.append({'path':str(p.relative_to(s)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(v/'focused-input.json').write_text(json.dumps(files,indent=2))
pattern='^Test(PluginAutoBackup(OwnerRootRejectsMissingReplacedAndRolledBackEvidence|UnknownClassificationRejectsForgedDiagnostics|NativeClonePrivateArchiveIsolation|NativeCloneExplicitDestinationIsNotRewritten|LocalArchiveAuthenticatedNotice|LifecycleWaitsOnlyInstanceGate)|AutoBackupActualServerNativeClonePrivateArchiveIsolation)$'
cmd=[str(v/'clean-go.sh'),'test','-p','1','-json','./internal/app','-run',pattern,'-count=1','-timeout','8m']
(v/'focused-plan.json').write_text(json.dumps({'cmd':cmd,'candidate_files':len(files),'baseline':'2f4ab1e5333501d890c2c803d11cbe0d32487329'},indent=2))
with (v/'focused-normal.jsonl').open('wb') as out,(v/'focused-normal.stderr').open('wb') as err:
 start=time.time();p=subprocess.run(cmd,stdout=out,stderr=err)
(v/'focused-normal.exit').write_text(str(p.returncode)+'\n')
changed=[f['path'] for f in files if hashlib.sha256((s/f['path']).read_bytes()).hexdigest()!=f['sha256']]
(v/'focused-result.json').write_text(json.dumps({'exit':p.returncode,'seconds':time.time()-start,'source_changes':changed},indent=2));print(p.returncode,changed,flush=True)
