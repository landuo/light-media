#!/bin/bash
set -eu
root=/workspace/scratch/a1d82674c6f8
owned="$root/light-media/work/auto-backup-20261023"
cd "$owned/source"
mkdir -p "$owned/env/home" "$owned/env/tmp"
exec env -i PATH="$root/light-media-toolchain/go/bin:/usr/bin:/bin" HOME="$owned/env/home" TMPDIR="$owned/env/tmp" GOPATH="$root/light-media-toolchain/gopath" GOCACHE="$root/light-media-toolchain/cache" GOPROXY=off GOSUMDB=off GOTOOLCHAIN=local GOENV=off CGO_ENABLED="${ISOLATED_CGO_ENABLED:-1}" LANG=C.UTF-8 TZ=UTC go "$@"
