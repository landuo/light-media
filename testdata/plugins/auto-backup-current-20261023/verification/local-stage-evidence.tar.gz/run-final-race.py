from pathlib import Path
import subprocess,json,time,hashlib
v=Path(__file__).resolve().parent;s=v.parent/'source'
files=json.loads((v/'final-input.json').read_text())
assert not [f['path'] for f in files if hashlib.sha256((s/f['path']).read_bytes()).hexdigest()!=f['sha256']]
pattern=json.loads((v/'final-app-normal-plan.json').read_text())['cmd'];pattern=pattern[pattern.index('-run')+1]
jobs=[('final-core-race','./internal/plugins/autobackup','Test(InstalledArchive|NativeArchive|ActualCoreNative|InstalledBusiness|FormalAutoBackup|ActualSDK|OriginalForm|SourceAPI|DateScheduler|SourceCron)','5m'),('final-app-race','./internal/app',pattern,'14m')]
for name,package,pattern,timeout in jobs:
 cmd=[str(v/'clean-go.sh'),'test','-p','1','-race','-json',package,'-run',pattern,'-skip','OwnedWebDAV','-count=1','-timeout',timeout]
 (v/(name+'-plan.json')).write_text(json.dumps({'cmd':cmd},indent=2))
 start=time.time()
 with (v/(name+'.jsonl')).open('wb') as out,(v/(name+'.stderr')).open('wb') as err:p=subprocess.run(cmd,stdout=out,stderr=err)
 (v/(name+'.exit')).write_text(str(p.returncode)+'\n')
 changed=[f['path'] for f in files if hashlib.sha256((s/f['path']).read_bytes()).hexdigest()!=f['sha256']]
 (v/(name+'-result.json')).write_text(json.dumps({'exit':p.returncode,'seconds':time.time()-start,'source_changes':changed},indent=2));print(name,p.returncode,changed,flush=True)
 if p.returncode or changed:break
