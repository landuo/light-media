from pathlib import Path
import hashlib,json,os,signal,subprocess
base=Path(__file__).resolve().parent
root=base/'ui-fixture-stage.host2'
root.mkdir(exist_ok=False)
for name in ('home','tmp'):(root/name).mkdir()
(root/'.owner').write_text('owned-autobackup-synthetic-fixture-20261023\n')
worker=base/'server';fixture=base/'fixture.test'
expected=json.loads((base/'build-summary.json').read_text())
for file,key in [(worker,'worker_sha256'),(fixture,'fixture_sha256')]:
 if hashlib.sha256(file.read_bytes()).hexdigest()!=expected[key]:raise RuntimeError('build input changed '+key)
env={'PATH':'/usr/bin:/bin','HOME':str(root/'home'),'TMPDIR':str(root/'tmp'),'LANG':'C.UTF-8','TZ':'UTC','GOMAXPROCS':'2','AUTOBACKUP_CURRENT_BROWSER_STAGE':str(root),'AUTOBACKUP_CURRENT_BROWSER_WORKER':str(worker),'AUTOBACKUP_CURRENT_BROWSER_WORKER_SHA256':expected['worker_sha256']}
with (root/'stdout').open('wb') as out,(root/'stderr').open('wb') as err:
 p=subprocess.Popen([str(fixture),'-test.run=^TestAutoBackupCurrentBrowserFixture$','-test.timeout=22m','-test.v'],cwd=str(base.parent.parent/'source/internal/app'),env=env,stdout=out,stderr=err,start_new_session=True)
 def stop(*_):(root/'stop').touch()
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:code=p.wait(timeout=1330)
 except subprocess.TimeoutExpired:
  p.terminate()
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();code=p.wait()
 (root/'exit.json').write_text(json.dumps({'exit':code,'owned_child_reaped':True})+'\n')
 print('owned AutoBackup browser fixture finished:',code,flush=True)
