from pathlib import Path
import json,urllib.request,http.cookiejar,urllib.parse
p=Path(__file__).resolve().parent/'ui-fixture-stage.host2';assert (p/'.owner').read_text().strip()=='owned-autobackup-synthetic-fixture-20261023'
u=json.loads((p/'ready.json').read_text())['url'];parsed=urllib.parse.urlparse(u);assert parsed.hostname=='127.0.0.1' and parsed.scheme=='http'
jar=http.cookiejar.CookieJar();op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar),urllib.request.ProxyHandler({}))
# Public synthetic fixture constants, no user account or saved credential.
r=urllib.request.Request(u+'/api/auth/login',data=json.dumps({'username':'admin','password':'a-strong-test-password'}).encode(),headers={'Content-Type':'application/json','Origin':u});op.open(r).close()
r=op.open(u+'/api/plugins/AutoBackupuitest/form');raw=r.read();obj=json.loads(raw);(p/'actual-clone-form.json').write_bytes(raw);print('owned actual form captured',r.status,len(raw))
