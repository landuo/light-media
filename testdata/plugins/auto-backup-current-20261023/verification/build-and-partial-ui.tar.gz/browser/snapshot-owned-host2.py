from pathlib import Path
import json,sqlite3,hashlib,sys
stage=Path(__file__).resolve().parent/'ui-fixture-stage.host2'
assert (stage/'.owner').read_text().strip()=='owned-autobackup-synthetic-fixture-20261023'
data=Path(json.loads((stage/'ready.json').read_text())['data_dir']).resolve();assert data.parent==stage
files=list(data.glob('*.db'));assert len(files)==1,files
con=sqlite3.connect(files[0].as_uri()+'?mode=ro',uri=True);con.execute('BEGIN')
tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND (name IN ('plugin_installations','plugin_values','plugin_runs','plugin_deferred_operations') OR name LIKE 'plugin_auto_backup_%' OR name LIKE 'plugin_run_attempt%') ORDER BY name")]
def scrub(v):return {'blob_sha256':hashlib.sha256(v).hexdigest(),'bytes':len(v)} if isinstance(v,bytes) else v
out={'synthetic_only':True,'tables':{},'archives':{}}
for table in tables:
 rows=con.execute('SELECT * FROM "'+table+'"');cols=[c[0] for c in rows.description];values=[dict(zip(cols,[scrub(v) for v in row])) for row in rows];out['tables'][table]=sorted(values,key=lambda r:json.dumps(r,sort_keys=True))
con.rollback();con.close()
for p in sorted(data.glob('plugin-private/**/*.zip')):out['archives'][str(p.relative_to(data))]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
name=sys.argv[1];assert name.replace('-','').isalnum();(stage/(name+'.json')).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(name, len(out['archives']), {t:len(v) for t,v in out['tables'].items()})
