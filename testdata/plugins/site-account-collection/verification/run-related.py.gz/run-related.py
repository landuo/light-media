import pathlib,subprocess,re,json
s=pathlib.Path(__file__).resolve().parent
pattern='^Test(Managed|LegacyUnkeyed|SiteAccount|SiteStatistics|SiteStatistic|PluginSiteStatistic|SourceAccount|SiteDataRefresh|SiteRefreshEvent|PluginMergeSiteSwitch|PluginHTTP|PluginCustomAPI|PriorityRuleDownloadSort)';out=[]
for name,b in [('normal','app.test'),('race','app-race.test')]:
 p=subprocess.run([str(s/b),'-test.run='+pattern,'-test.v','-test.timeout=600s'],cwd=s/'app/internal/app',capture_output=True,timeout=615)
 log=p.stdout+p.stderr;(s/('related-'+name+'.log')).write_bytes(log);v={'kind':name,'exit':p.returncode,'top_pass':len(re.findall(rb'^--- PASS: Test',log,re.M)),'inclusive_pass':len(re.findall(rb'^\s*--- PASS:',log,re.M)),'failures':[x.decode() for x in re.findall(rb'^--- FAIL: (\S+)',log,re.M)]};out.append(v);(s/'related-status.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(v),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
