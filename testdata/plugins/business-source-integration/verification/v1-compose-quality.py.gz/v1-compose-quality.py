import pathlib,json,hashlib,subprocess,collections
r=pathlib.Path(__file__).resolve().parent;repo=r.parent.parent;src=repo/'work/_best_version_port';app=r/'app'
leaves=[
'revision4-source-facts/reference/source-facts-leaf.json',
'revision5-actual-batch/reference/pending-schedule-leaf.json',
'revision5b-actual-batch/reference/actual-batch-checkpoint1.json',
'revision6-extra-scope/reference/cold-known-checkpoint1.json',
'revision7-known-receipts/reference/cancel-known-checkpoint1.json',
'revision8-extra-and-import/reference/late-import-checkpoint1.json',
'revision9-extra-pack/reference/extra-pack-checkpoint1.json',
'revision10-multiseason/reference/multiseason-checkpoint1.json',
'revision11-selected-multiseason/reference/selected-multiseason-checkpoint1.json',
'revision12-full-completion/reference/full-mode-checkpoint1.json',
'revision13-directory-overwrite/reference/quality-overwrite-checkpoint1.json',
'revision13-directory-overwrite/reference/part-coexistence-regression/test-leaf1.json',
'revision14-directory-source/reference/directory-selection-leaf1.json',
'revision14b-directory-host/reference/extensions-provider-leaf1.json',
'revision14c-auto-exdev/reference/auto-exdev-leaf1.json',
'revision14d-directory-host/reference/directory-host-leaf1.json',
'revision14e-transfer-extension-role/reference/extension-host-leaf1.json',
'revision14f-parser-browser-extensions/reference/parser-browser-host-leaf1.json',
'revision14g-parser-membership/reference/parser-membership-leaf1.json']
log=r/'quality-composition.json'
records=json.loads(log.read_text()) if log.exists() else []
done={x['leaf'] for x in records}
sha=lambda b:hashlib.sha256(b).hexdigest()
for leaf in leaves:
 if leaf in done:continue
 mp=src/leaf;d=json.loads(mp.read_text());rows=d.get('files',d.get('paths',d.get('focused')));assert isinstance(rows,list),leaf
 report=dict(leaf=leaf,manifest_sha256=sha(mp.read_bytes()),rows=[])
 for row in rows:
  path=row['path'];dst=app/path;before_sha=row.get('before_sha256',row.get('before'));after_sha=row.get('after_sha256',row.get('after'))
  if isinstance(before_sha,str) and len(before_sha)!=64:before_sha=row.get('before_sha256')
  if isinstance(after_sha,str) and len(after_sha)!=64:after_sha=row.get('after_sha256')
  ap=row.get('frozen',row.get('after_file',row.get('after')));assert ap and pathlib.Path(ap).is_file(),(leaf,path,'after',ap)
  a=pathlib.Path(ap).read_bytes();assert sha(a)==after_sha,(leaf,path,'after_sha')
  o=dst.read_bytes() if dst.is_file() else b'';oh=sha(o) if dst.is_file() else None
  if oh==after_sha:report['rows'].append(dict(path=path,state='equal'));continue
  if before_sha is None:b=b''
  else:
   bp=row.get('before_file',row.get('before_root',row.get('before')))
   if not bp or len(str(bp))==64:
    br=d.get('base',d.get('before_root'));assert isinstance(br,str),(leaf,path,'before root');bp=str(pathlib.Path(br)/path)
   if pathlib.Path(bp).is_dir():bp=str(pathlib.Path(bp)/path)
   assert pathlib.Path(bp).is_file(),(leaf,path,'before',bp)
   b=pathlib.Path(bp).read_bytes();assert sha(b)==before_sha,(leaf,path,'before_sha',bp,sha(b),before_sha)
  dst.parent.mkdir(parents=True,exist_ok=True)
  if oh==before_sha:dst.write_bytes(a);state='exact';blocks=0
  else:
   p=r/'merge-inputs'/mp.parent.parent.name/path;p.parent.mkdir(parents=True,exist_ok=True)
   for suf,value in [('.ours',o),('.base',b),('.theirs',a)]:pathlib.Path(str(p)+suf).write_bytes(value)
   result=subprocess.run(['git','merge-file','-p',str(p)+'.ours',str(p)+'.base',str(p)+'.theirs'],capture_output=True);assert result.returncode in range(128),result.stderr.decode();dst.write_bytes(result.stdout);blocks=result.returncode;state='conflict' if blocks else 'three_way_clean'
  report['rows'].append(dict(path=path,state=state,before_sha256=before_sha,source_after_sha256=after_sha,ours_before_sha256=oh,conflict_blocks=blocks))
 records.append(report);log.write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(dict(leaf=leaf,states=dict(collections.Counter(x['state'] for x in report['rows'])),conflicts=[x['path'] for x in report['rows'] if x['state']=='conflict'])),flush=True)
 if any(x['state']=='conflict' for x in report['rows']):break
