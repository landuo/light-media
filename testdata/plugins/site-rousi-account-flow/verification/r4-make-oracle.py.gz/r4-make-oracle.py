"""Installed complete NexusPHP/HHan parser methods, isolated synthetic HTTP."""
import ast,sys,json,hashlib,copy,re,io,contextlib
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
from urllib import parse
from urllib.parse import urlsplit,urljoin,parse_qsl,urlencode,urlunsplit
from abc import ABCMeta,abstractmethod
from enum import Enum
from typing import Optional,Any,Union,Dict,List,Tuple
from pydantic import BaseModel,Field,ConfigDict
from pyquery import PyQuery
from lxml import etree
import dateparser as original_dateparser
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('side_effect_denied')
 if event=='open' and ((isinstance(args[1],str) and any(c in args[1] for c in 'wax+')) or (isinstance(args[2],int) and args[2]&(1|2|64|512))):raise RuntimeError('write_denied')
sys.addaudithook(audit)
class Quiet:
 def __getattr__(self,n):return lambda *a,**k:None
class FixedDatetime(datetime):
 @classmethod
 def now(cls,*args,**kwargs):return cls(2026,10,21,12,34,56)
sources={};ns=dict(globals());ns.update(logger=Quiet(),Session=object,datetime=FixedDatetime,settings=SimpleNamespace(SITE_MESSAGE=False,PROXY=None,ENCODING_DETECTION_PERFORMANCE_MODE=True,ENCODING_DETECTION_MIN_CONFIDENCE=0.5),dateparser=SimpleNamespace(parse=lambda text:original_dateparser.parse(text,settings={'RELATIVE_BASE':datetime(2026,10,21,12,34,56)})))
def tree(path):
 raw=(Path('/app')/path).read_bytes();sources[path]=hashlib.sha256(raw).hexdigest();return ast.parse(raw)
def execute(nodes):
 m=ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[]));exec(compile(m,'<installed-owned-nexus-oracle>','exec'),ns)
def loadclass(path,name,methods=None):
 n=next(n for n in tree(path).body if isinstance(n,ast.ClassDef) and n.name==name)
 if methods is not None:n.body=[n for n in n.body if isinstance(n,ast.FunctionDef) and n.name in methods];n.bases=[];n.keywords=[]
 execute([n]);return ns[name]
st=tree('app/utils/string.py');execute([next(n for n in st.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_special_domains' for t in n.targets))])
loadclass('app/utils/string.py','StringUtils',['get_url_domain','get_url_netloc','num_filesize','str_int','str_float','unify_datetime_str','is_valid_html_element'])
cf=tree('app/helper/cloudflare.py');execute([n for n in cf.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['CHALLENGE_TITLES','CHALLENGE_SELECTORS'] for t in n.targets) or isinstance(n,ast.FunctionDef) and n.name=='under_challenge'])
loadclass('app/utils/site.py','SiteUtils')
loadclass('app/schemas/site.py','SiteUserData')
base='app/modules/indexer/parser/__init__.py';execute([next(n for n in tree(base).body if isinstance(n,ast.ClassDef) and n.name=='SiteSchema')]);loadclass(base,'SiteParserBase')
rousi=loadclass('app/modules/indexer/parser/rousi.py','RousiSiteUserInfo')
module=loadclass('app/modules/indexer/__init__.py','IndexerModule',['refresh_userdata'])
trace=[];positions={};responses={};unexpected=[]
class Response:
 def __init__(self,v):self.status_code=v['status'];self.text=v['body']
 def json(self):return json.loads(self.text)
 def __bool__(self):return self.status_code<400
class RequestUtils:
 def __init__(self,**kwargs):self.options=kwargs
 def _call(self,method,url,kwargs):
  u=urlsplit(url);q=parse_qsl(u.query,keep_blank_values=True)+[(k,str(v)) for k,v in (kwargs.get('params') or {}).items()];key=u.path+('?' + urlencode(sorted(q)) if q else '');index=positions.get(key,0);positions[key]=index+1
  trace.append(dict(method=method,url=url,params={k:str(v) for k,v in (kwargs.get('params') or {}).items()},headers=copy.deepcopy(self.options.get('headers') or {}),timeout=self.options['timeout']))
  items=responses.get(key,[])
  if index>=len(items):unexpected.append(key);raise RuntimeError('owned_reply_exhausted')
  return Response(items[index])
 def post_res(self,url,**kwargs):return self._call('POST',url,kwargs)
 def get_res(self,url,**kwargs):return self._call('GET',url,kwargs)
ns['RequestUtils']=RequestUtils
def reply(value,status=200,raw=False):return dict(status=status,body=value if raw else json.dumps(value,ensure_ascii=False))
profile={'code':0,'data':{'id':7,'username':'owned','level_text':'Lv.5','registered_at':'2024-01-02T03:04:05Z','uploaded':1024,'downloaded':512,'ratio':2.675,'karma':12.5,'seeding_leeching_data':{'seeding_count':2,'seeding_size':4096,'leeching_count':1,'leeching_size':2048}}}
profilekey='/api/v1/profile?include_fields%5Buser%5D=seeding_leeching_data';msg='/api/messages?page=0&page_size=100&unread_only=true';cases=[]
def case(name,p=None,read=False,token='synthetic-message-token',apikey='synthetic-apikey',extra=None):
 responses.clear();positions.clear();trace.clear();unexpected.clear();responses[profilekey]=[p or reply(profile)];responses.update(extra or {});inputs=copy.deepcopy(responses);ns['settings'].SITE_MESSAGE=read;m=module();m._site_schemas=[rousi];data=None;error=None;captured=io.StringIO()
 with contextlib.redirect_stdout(captured):
  try:data=m.refresh_userdata(dict(name='owned',url='https://owned.example/',schema='RousiPro',apikey=apikey,token=token,ua='synthetic-UA',cookie='must-not-send=1'))
  except Exception as e:error=type(e).__name__
 assert not unexpected,(name,unexpected)
 cases.append(dict(name=name,read_messages=read,token=token,apikey=apikey,replies=inputs,requests=copy.deepcopy(trace),data=data.model_dump() if data is not None else None,error_type=error))
case('profile-all-fields-and-python-round')
case('role-fallback-and-missing-stat-fields',p=reply({'code':False,'data':{'id':'007','username':'owned','level_text':'','role_text':'User','registered_at':'not_a_date'}}))
case('HTTP500-profile-body',p=reply(profile,500))
case('HTTP403-profile-body',p=reply(profile,403))
case('HTTP503-default-DTO',p=reply(profile,503))
case('invalid-json-default-DTO',p=reply('{',raw=True))
case('API-error-DTO',p=reply({'code':3,'message':'owned error'}))
case('missing-code-error-default',p=reply({}))
case('string-zero-code-is-error',p=reply({'code':'0'}))
case('null-root-throws',p=reply(None))
case('list-root-throws',p=reply([1]))
case('empty-data-default-DTO',p=reply({'code':0,'data':{}}))
case('null-seeding-data-throws',p=reply({'code':0,'data':{'id':7,'seeding_leeching_data':None}}))
case('bad-int-throws',p=reply({'code':0,'data':{'uploaded':'bad'}}))
case('boolean-and-truncated-floats',p=reply({'code':0,'data':{'id':True,'uploaded':1.9,'downloaded':True,'ratio':True,'karma':'3.25','seeding_leeching_data':{'seeding_count':'2','leeching_count':-1}}}))
case('validation-late-after-read-all',p=reply({'code':0,'data':{'username':7}}),read=True,extra={msg:[reply({'code':0,'data':{'messages':[],'total_pages':1}})],'/api/messages/read-all':[reply({})]})
case('no-credentials-no-requests',apikey='',token='')
case('token-only-profile-has-empty-apikey',apikey='',read=True,extra={msg:[reply({'code':0,'data':{'messages':[],'total_pages':0}})],'/api/messages/read-all':[reply({})]})
case('messages-disabled-no-read')
case('messages-token-missing-skip',read=True,token='')
case('zero-messages-still-read-all',read=True,extra={msg:[reply({'code':0,'data':{'messages':[],'total_pages':1}})],'/api/messages/read-all':[reply({},500)]})
case('HTTP500-messages-still-read-all',read=True,extra={msg:[reply({},500)],'/api/messages/read-all':[reply({})]})
case('API-error-messages-still-read-all',read=True,extra={msg:[reply({'code':1})],'/api/messages/read-all':[reply({})]})
case('paginated-duplicates-and-null-fields',read=True,token='Bearer synthetic-message-token',extra={msg:[reply({'code':0,'data':{'messages':[{'title':'a','created_at':'2026-10-21T01:02:03Z','content':'body'},{}],'total_pages':2}})],'/api/messages?page=1&page_size=100&unread_only=true':[reply({'code':0,'data':{'messages':[{'title':'a','content':'body'}]}})],'/api/messages/read-all':[reply({})]})
case('invalid-message-json-throws-before-mark',read=True,extra={msg:[reply('{',raw=True)]})
case('null-message-data-throws-before-mark',read=True,extra={msg:[reply({'code':0,'data':None})]})
case('invalid-message-row-throws-before-mark',read=True,extra={msg:[reply({'code':0,'data':{'messages':[7]}})]})
case('profile-error-still-reads-messages',p=reply({'code':1,'message':'owned'}),read=True,extra={msg:[reply({'code':0,'data':{'messages':[]}})],'/api/messages/read-all':[reply({})]})
case('fractional-userid-validates-after-mark',p=reply({'code':0,'data':{'id':7.1,'username':'owned'}}),read=True,extra={msg:[reply({'code':0,'data':{'messages':[]}})],'/api/messages/read-all':[reply({})]})
case('fractional-message-pages',read=True,extra={msg:[reply({'code':0,'data':{'messages':[],'total_pages':1.5}})],'/api/messages?page=1&page_size=100&unread_only=true':[reply({'code':0,'data':{'messages':[]}})],'/api/messages/read-all':[reply({})]})
case('string-message-pages-throws',read=True,extra={msg:[reply({'code':0,'data':{'messages':[],'total_pages':'2'}})]})
print(json.dumps(dict(scope='installed complete Rousi/BaseParser/Indexer DTO, mocked HTTP only; no real credentials, sites or message writes',clock='2026-10-21T12:34:56+08:00',source_dateparser_version=original_dateparser.__version__,source_sha256=sources,cases=cases),ensure_ascii=False,separators=(',',':')))
