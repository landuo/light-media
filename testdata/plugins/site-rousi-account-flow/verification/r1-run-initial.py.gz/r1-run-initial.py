import pathlib,subprocess,json
s=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/Users/accidia/projects/light-media');results=[]
for name,cmd in [('sites',['go','test','./internal/sites','-count=1','-v']),('app',['go','test','./internal/app','-run','^Test(ManagedRousi|ManagedSite|SiteImport|SiteExport|SiteStatisticRousi)','-count=1','-v'])]:
 with (s/(name+'-initial.log')).open('wb') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'exit':r.returncode});(s/'initial-status.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
