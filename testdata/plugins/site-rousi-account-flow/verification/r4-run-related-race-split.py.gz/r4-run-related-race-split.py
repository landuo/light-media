import pathlib,subprocess,re,json,concurrent.futures,hashlib
s=pathlib.Path(__file__).resolve().parent;v=json.loads((s/'related-race-groups.json').read_text());assert hashlib.sha256((s/'app-race.test').read_bytes()).hexdigest()==v['same_binary_sha256']
def run(item):
 name,names=item;pattern='^('+('|'.join(names))+')$'
 p=subprocess.run([str(s/'app-race.test'),'-test.run='+pattern,'-test.v','-test.timeout=600s'],cwd=s/'app/internal/app',capture_output=True,timeout=615);log=p.stdout+p.stderr;(s/('related-race-split-'+name+'.log')).write_bytes(log);r={'group':name,'exit':p.returncode,'selected':names,'top_pass':len(re.findall(rb'^--- PASS:',log,re.M)),'inclusive_pass':len(re.findall(rb'^\s*--- PASS:',log,re.M)),'failures':[x.decode() for x in re.findall(rb'^\s*--- FAIL: (\S+)',log,re.M)],'sha256':hashlib.sha256(log).hexdigest()};print(json.dumps(r),flush=True);return r
out=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for f in concurrent.futures.as_completed([pool.submit(run,x) for x in v['groups'].items()]):
  out.append(f.result());(s/'related-race-split-status.json').write_text(json.dumps(out,indent=2)+'\n')
assert all(r['exit']==0 and r['top_pass']==len(r['selected']) for r in out)
assert sorted(n for r in out for n in r['selected'])==sorted(v['names'])
print(json.dumps({'all_groups_passed':True,'top_pass':sum(r['top_pass'] for r in out),'inclusive_pass':sum(r['inclusive_pass'] for r in out),'source_changes':False}),flush=True)
