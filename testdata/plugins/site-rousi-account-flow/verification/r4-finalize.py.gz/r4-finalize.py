import pathlib,json,hashlib,re,subprocess,gzip,base64,urllib.parse
root=pathlib.Path('/Users/accidia/projects/light-media');s=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((s/n).read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
statuses={n:read(n) for n in ['sites-status.json','related-status.json','actual-status.json','build-normal-status.json','build-race-status.json','build-linux-status.json']}
for n,v in statuses.items():
 assert v,n
 if n=='related-status.json':assert len(v)==2 and v[0]['exit']==0 and v[1]['exit']==2
 else:assert all(x['exit']==0 for x in v),n
 if n in ['sites-status.json','actual-status.json']:assert len(v)==2
splits=read('related-race-split-status.json');groups=read('related-race-groups.json')
assert len(splits)==4 and all(x['exit']==0 and x['top_pass']==len(x['selected']) for x in splits)
assert sorted(n for x in splits for n in x['selected'])==sorted(groups['names']) and len(groups['names'])==63
assert sha(s/'app-race.test')==groups['same_binary_sha256']
statuses['related-race-exact-disjoint-groups']=splits
nas=read('nas-verification.json');assert nas['state']=='passed_owned_linux_business' and nas['owned_container_removed'] and nas['owned_runtime_directory_removed'] and nas['original_and_production_containers_unchanged'] and nas['execution']['exit_code']==0 and not nas['execution']['oom_killed']
cleanup=read('nas-independent-cleanup.json');assert all(cleanup.values())
checks={}
for name in ['sites-normal','sites-race','related-normal','related-race-split-nexus','related-race-split-mteam','related-race-split-rousi','related-race-split-remaining','actual-normal','actual-race','nas-selected']:
 b=(s/(name+'.log')).read_bytes();v={k:len(re.findall(p,b,re.M)) for k,p in [('top_pass',rb'^--- PASS:'),('inclusive_pass',rb'^\s*--- PASS:'),('fail',rb'^\s*--- FAIL:'),('skip',rb'^\s*--- SKIP:')]};v['sha256']=hashlib.sha256(b).hexdigest();assert not v['fail'] and not v['skip'];checks[name]=v
assert checks['sites-normal']['top_pass']==48 and checks['sites-race']['top_pass']==48 and checks['nas-selected']['inclusive_pass']==118
sources=read('SOURCE-INPUTS.json');assert all(sha(s/'app'/x['path'])==x['sha256'] for x in sources)
for name in ['COMPILATION-INPUTS.json']:
 for x in read(name):
  p=s/'app'/x['path'][5:] if x['path'].startswith('repo/') else pathlib.Path(x['path']);assert sha(p)==x['sha256'],x['path']
paths=set(p.decode() for p in subprocess.check_output(['git','ls-files','-mo','--exclude-standard','-z'],cwd=root).split(b'\0') if p)
focus=sorted(n for n in paths if (n.startswith(('internal/','web/')) or n in ['go.mod','go.sum','testdata/plugins/site-rousi-account-original-oracle.json']) and (root/n).is_file())
manifest={x['path']:x['sha256'] for x in sources};assert all(manifest[n]==sha(root/n) for n in focus)
web=[x for x in sources if x['path'].startswith('web/')];assert all((root/x['path']).read_bytes()==(s/'app'/x['path']).read_bytes() for x in web)
ui=s.parent/'r3';assert json.loads((ui/'ui-project-build-status.json').read_text())['exit']==0
assert json.loads((ui/'ui-status.json').read_text())[0]['exit']==0
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(root/'work/_site_statistic_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=35);assert r.returncode==0;v=json.loads(r.stdout);needles=set();secrets=set()
def walk(v,k=''):
 if isinstance(v,dict):
  for key,x in v.items():walk(x,key.lower())
 elif isinstance(v,list):
  for x in v:walk(x,k)
 elif isinstance(v,str):
  if v[:1] in ('{','['):
   try:walk(json.loads(v),k)
   except (ValueError,TypeError):pass
  if len(v)>=6 and any(x in k for x in ['password','cookie','token','apikey','api_key','passkey','authorization','secret']):secrets.add(v)
  for url in re.findall(r'https?://[^\s<>"\']+',v):
   for key,vals in urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).items():
    if any(x in key.lower() for x in ['passkey','token','auth','key']):secrets.update(x for x in vals if len(x)>=6)
walk(v)
for raw in v['account_rows']:
 needles.add(raw.encode());row=json.loads(raw)
 for key in ['username','userid']:
  value=row.get(key)
  if isinstance(value,str) and value:
   needles.update([('"'+key+'":'+json.dumps(value,ensure_ascii=False)).encode(),('"'+key+'": '+json.dumps(value,ensure_ascii=False)).encode()])
   if len(value)>=6:
    q=json.dumps(value,ensure_ascii=False);needles.update([q.encode(),json.dumps(q,ensure_ascii=False)[1:-1].encode()])
for value in secrets:needles.update(x.encode() for x in [value,urllib.parse.quote(value,safe=''),base64.b64encode(value.encode()).decode()])
files=sorted(p for directory in [s,s.parent/'r1',s.parent/'r2',s.parent/'r3'] for p in directory.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log','.txt','.stderr'])
docs=[root/'docs/plugin-site-rousi-account-flow.txt',root/'docs/plugin-installed-migration-baseline.md']
for p in files+docs+[root/n for n in focus]:assert not any(x in p.read_bytes() for x in needles),'private_material_no_archive_written'
drift={'frozen_source_files':len(sources),'main_compiler_inputs':len(read('COMPILATION-INPUTS.json')),'frozen_drift':0,'compiler_drift':0,'product_focus_drift':0,'complete_compiler_system_headers_linker_closure_claimed':False}
oracle=json.loads((root/'testdata/plugins/site-rousi-account-original-oracle.json').read_text());assert len(oracle['cases'])==31
report={'date':'2026-10-21','base_commit':'5e31c48','state':'Rousi_source_account_flow_and_native_adapter_verified_not_plugin_completion','actual_complete':7,'remaining':16,'production_version':'0.4.8','deployed':False,'python_runtime_added':False,'old_and_production_mutations':0,'real_business_calls':0,'real_handoffs':0,'source_oracle':{'cases':31,'sha256':sha(root/'testdata/plugins/site-rousi-account-original-oracle.json'),'source_sha256':oracle['source_sha256'],'scope':oracle['scope']},'checks':checks,'statuses':statuses,'nas':nas,'independent_cleanup':cleanup,'drift':drift,'source_manifest_sha256':sha(s/'SOURCE-INPUTS.json'),'compiler_manifest_sha256':sha(s/'COMPILATION-INPUTS.json'),'focus':[{'path':n,'sha256':sha(root/n)} for n in focus],'frontend':{'changed':True,'component_tests':25,'component_failures':0,'build_exit':0,'built_assets_in_frozen_Go_app':True,'visual_user_acceptance_claimed':False},'source_history_rows':len(v['account_rows']),'private_scan':{'passed':True,'files':len(files+docs+focus),'patterns':len(needles),'payload_saved':False},'combined_related_race_passed':False,'related_race_groups_union_matches_normal':True,'combined_timeout':{'exit':2,'seconds':600,'top_pass':19,'inclusive_pass':167,'assertion_failures':0,'race_reports':0,'current_test_elapsed_seconds':9,'running_test':'TestPluginSiteStatisticRealCollectionEventNoticeAndCrashReceipt'},'retained_rounds':['r4 combined related race hit aggregate 600s timeout after19top167inclusive passes; no assertion/race report. Same unchanged binary rerun in four exact disjoint groups; combined timeout preserved and not counted as a pass.','r1: initial 28 original wire/27 SDK cases passed; expanded to 31 including no credentials full SDK, fractional ID and pagination types; native numeric identity corrected before frozen final checks.','r2: initial capture selected only 15 changed files; no build/test in that incomplete app. New complete r3/r4 used.','r3 UI-only build failed ENOENT because the original build scripts require sibling internal/plugins; fresh complete ui-project copy built successfully; final r4 includes those exact compiled assets.'],'remaining':['All rare original dateparser/non-finite/large integer/unusual JSON cases are not universally proven.','Native search/download protocol is synthetic, not a real user site or full source TorrentInfo proof. Cross-origin material/CDN refused pending provenance.','Actual configured SitesHelper catalog/schema/alias context and integration.','SystemError/site message/statistic full producers/channels; source global setting import, final binding, execution handoff and remaining 16 plugins.']}
out=root/'docs/plugin-site-rousi-account-flow-verification.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');assert not any(x in out.read_bytes() for x in needles)
archive=root/'testdata/plugins/site-rousi-account-flow/verification';archive.mkdir(parents=True,exist_ok=False)
for p in files:(archive/(p.parent.name+'-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(archive/'index.json').write_text(json.dumps({'files':[{'path':p.name,'sha256':sha(p)} for p in sorted(archive.iterdir())]},indent=2)+'\n')
print(json.dumps({'proof_files':len(files),'focus_files':len(focus),'drift':drift,'private_scan_passed':True,'actual_complete':7,'goal_complete':False}))
