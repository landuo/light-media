import json,os,pathlib,socket,subprocess,tempfile,time,urllib.request
r=pathlib.Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='light-media-owned-form-') as t:
 d=pathlib.Path(t)/'data';p=subprocess.run([str(r/'owned-ui-seed-tool'),str(d)],capture_output=True,timeout=20);assert p.returncode==0,'owned_seed_failed'
 s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();url='http://127.0.0.1:'+str(port)
 with open(r/'owned-ui-server.log','wb') as log:
  p=subprocess.Popen([str(r/'light-media-native-owned'),'--data-dir',str(d),'--listen','127.0.0.1:'+str(port)],stdout=log,stderr=log,env={k:v for k,v in os.environ.items() if not k.startswith('LIGHT_MEDIA_')})
  try:
   for _ in range(30):
    assert p.poll() is None,'owned_server_exited'
    try:
     with urllib.request.urlopen(url+'/healthz',timeout=.3) as response:
      assert json.load(response)['data']['version']=='0.4.8';break
    except OSError:time.sleep(.1)
   else:raise RuntimeError('owned_server_not_ready')
   print(json.dumps(dict(state='owned_ui_ready',url=url,pid=p.pid,core_media_enabled=False,plugin_media_enabled=True,selected=['fnos'])),flush=True)
   assert input().strip()=='stop'
  finally:
   p.terminate();p.wait(timeout=20);assert p.returncode==0
assert not d.exists();(r/'owned-ui-cleanup.json').write_text(json.dumps(dict(state='cleaned',server_exit=0,owned_data_removed=True,network_business_calls=0))+'\n');print('owned_ui_cleaned',flush=True)
