import base64,hashlib,json,os,pathlib,re,subprocess,urllib.parse
repo=pathlib.Path('/Users/accidia/projects/light-media');stage=pathlib.Path(__file__).resolve().parent
source=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(repo/'work/_seed_rescue_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=30)
if source.returncode:raise RuntimeError('readonly_capture_failed_'+str(source.returncode))
selected=json.loads(source.stdout);secrets=set()
for d in selected['downloaders']:
 if d.get('password'):secrets.add(d['password'])
def walk(v,key=''):
 if isinstance(v,dict):
  for k,child in v.items():walk(child,k.lower())
 elif isinstance(v,list):
  for child in v:walk(child,key)
 elif isinstance(v,str):
  if key in ['token','password','cookie','apikey','passkey','rsskey'] and len(v)>=6:secrets.add(v)
  if v.startswith(('https://','http://')):
   for k,values in urllib.parse.parse_qs(urllib.parse.urlsplit(v).query).items():
    if any(part in k.lower() for part in ['passkey','token','key','auth']):secrets.update(x for x in values if len(x)>=6)
walk(json.loads(selected['config']))
for v in selected['data'].values():walk(json.loads(v))
variants=set()
for v in secrets:variants.update([v,urllib.parse.quote(v,safe=''),base64.b64encode(v.encode()).decode()])
report={'scope':'actual source into owned AES stores; independent namespace, CLI, actual Go SDK/RSS/qB and lost-ACK cold recovery; all business connections are owned loopback','private_payload_saved':False,'runs':[]}
for kind,binary in [('normal','app.test'),('race','app-race.test')]:
 env=dict(os.environ,LIGHT_MEDIA_REVIEWED_SEED='owned-selected-stdin',LIGHT_MEDIA_REVIEWED_SEED_CLI=str(stage/('seed-migrate-race' if kind=='race' else 'seed-migrate')))
 p=subprocess.run([str(stage/binary),'-test.run=^TestReviewedSeedSelectedStdin$','-test.v','-test.timeout=600s'],input=source.stdout,capture_output=True,env=env,timeout=610)
 log=p.stdout+p.stderr
 if any(v.encode() in log for v in variants if v):
  report['log_private_material_detected']=True;(stage/'seed-selected-verification.json').write_text(json.dumps(report,indent=2)+'\n');raise RuntimeError('private_material_detected_no_log_saved')
 (stage/('seed-'+kind+'-selected.log')).write_bytes(log)
 report['runs'].append({'kind':kind,'exit':p.returncode,'passed':bool(re.search(rb'^--- PASS: TestReviewedSeedSelectedStdin \(',p.stdout,re.M)) and p.returncode==0,'log_sha256':hashlib.sha256(log).hexdigest(),'source_secret_scan_passed':True})
 (stage/'seed-selected-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['runs'][-1]),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
