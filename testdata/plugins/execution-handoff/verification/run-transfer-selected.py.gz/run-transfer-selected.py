import base64,hashlib,json,os,pathlib,re,subprocess,urllib.parse
repo=pathlib.Path('/Users/accidia/projects/light-media');stage=pathlib.Path(__file__).resolve().parent
source=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(repo/'work/_torrent_transfer_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=30)
if source.returncode:raise RuntimeError('readonly_capture_failed_'+str(source.returncode))
profiles=json.loads(source.stdout);secrets={d['password'] for profile in profiles for d in profile['downloaders'] if d.get('password')}
variants=set()
for v in secrets:variants.update([v,urllib.parse.quote(v,safe=''),base64.b64encode(v.encode()).decode()])
report={'scope':'actual source into owned AES stores; two original transfer instances, independent references and history, offline CLI, actual Go SDK/qB/TR owned transfer and lost-ACK cold protection','private_payload_saved':False,'runs':[]}
for kind,binary in [('normal','app.test'),('race','app-race.test')]:
 env=dict(os.environ,LIGHT_MEDIA_HANDOFF_CLI=str(stage/('handoff-race' if kind=='race' else 'handoff')),LIGHT_MEDIA_REVIEWED_TRANSFER='owned-selected-stdin',LIGHT_MEDIA_REVIEWED_TRANSFER_CLI=str(stage/('transfer-migrate-race' if kind=='race' else 'transfer-migrate')))
 p=subprocess.run([str(stage/binary),'-test.run=^TestReviewedTransferSelectedStdin$','-test.v','-test.timeout=600s'],input=source.stdout,capture_output=True,env=env,timeout=610)
 log=p.stdout+p.stderr
 if any(v.encode() in log for v in variants if v):
  report['log_private_material_detected']=True;(stage/'selected-verification.json').write_text(json.dumps(report,indent=2)+'\n');raise RuntimeError('private_material_detected_no_log_saved')
 (stage/(kind+'-selected.log')).write_bytes(log)
 report['runs'].append({'kind':kind,'exit':p.returncode,'passed':bool(re.search(rb'^--- PASS: TestReviewedTransferSelectedStdin \(',p.stdout,re.M)) and p.returncode==0,'log_sha256':hashlib.sha256(log).hexdigest(),'source_secret_scan_passed':True})
 (stage/'selected-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['runs'][-1]),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
