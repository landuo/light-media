import hashlib,json,pathlib,re,subprocess,time
stage=pathlib.Path(__file__).resolve().parent
pattern=r"^Test(PluginSourceHandoff|Transfer|PluginStore.*Import|SeedRescue|PluginSiteSwitch)"
listing=subprocess.run([str(stage/'app-race.test'),'-test.list='+pattern],capture_output=True,check=True,timeout=30).stdout.decode().splitlines()
normal=(stage/'test.log').read_text()
rows=re.findall(r'^--- (PASS|FAIL|SKIP): (\S+) \(([0-9.]+)s\)',normal,re.M)
assert set(listing)=={x[1] for x in rows}
groups=[[],[],[]];weight=[0.,0.,0.]
for state,name,duration in sorted(rows,key=lambda x:float(x[2]),reverse=True):
 i=weight.index(min(weight));groups[i].append(name);weight[i]+=float(duration)
assert len(set(n for g in groups for n in g))==len(listing)==sum(map(len,groups))
report={'reason':'aggregate package600s timeout after65 completed top tests; partition same frozen race binary and identical73-name union without dropping cases or extending limits','selection':pattern,'expected_names':listing,'groups':[]}
(stage/'related-partitions.json').write_text(json.dumps(report,indent=2)+'\n')
for i,names in enumerate(groups):
 start=time.monotonic();selection='^('+'|'.join(re.escape(n) for n in names)+')$'
 try:
  p=subprocess.run([str(stage/'app-race.test'),'-test.run='+selection,'-test.v','-test.timeout=600s'],capture_output=True,timeout=615)
  data=p.stdout+p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as e:
  data=(e.stdout or b'')+(e.stderr or b'');code=124
 file='related-race-part-'+str(i+1)+'.log';(stage/file).write_bytes(data)
 states=re.findall(rb'^--- (PASS|FAIL|SKIP): (\S+) \(',data,re.M)
 got={name.decode():state.decode() for state,name in states}
 valid=code==0 and data.rstrip().endswith(b'PASS') and set(got)==set(names) and 'FAIL' not in got.values()
 result={'part':i+1,'names':names,'exit':code,'passed':valid,'top_passed':sum(x=='PASS' for x in got.values()),'top_skipped':[n for n,s in got.items() if s=='SKIP'],'including_subtests_passed':len(re.findall(rb'^\s*--- PASS:',data,re.M)),'log':file,'sha256':hashlib.sha256(data).hexdigest(),'elapsed_seconds':round(time.monotonic()-start,2)}
 report['groups'].append(result);(stage/'related-partitions.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='names'}),flush=True)
 if not valid:raise SystemExit(1)
report['passed']=True;report['top_passed']=sum(x['top_passed'] for x in report['groups']);report['including_subtests_passed']=sum(x['including_subtests_passed'] for x in report['groups']);(stage/'related-partitions.json').write_text(json.dumps(report,indent=2)+'\n')
