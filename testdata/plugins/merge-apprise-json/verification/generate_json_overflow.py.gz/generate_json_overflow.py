"""Offline source overflow and emoji oracle. No notification is sent."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,gzip,hashlib,logging,socket,re
BASE=Path('/Users/accidia/projects/light-media/work/_merge_message_native_port')
APP=Path(__file__).resolve().parent/'app'
sys.path[:0]=[str(BASE/'oracle-deps'),str(APP/'testdata/plugins/merge-message-notify-1.20.1/input/_merge_message_notify_port/reference/dependencies/apprise')]
import requests,apprise
from apprise.emojis import EMOJI_MAP
logging.disable(logging.CRITICAL)
def deny(*a,**k):raise AssertionError('offline source attempted network')
socket.create_connection=deny;socket.socket.connect=deny;socket.getaddrinfo=deny
out=APP/'internal/plugins/mergemessagenotify/apprise/testdata'
data=(json.dumps(list(EMOJI_MAP.items()),ensure_ascii=False,indent=2)+'\n').encode();(out/'emoji-patterns.json').write_bytes(data)
contents=[
 ('x'*249,'x'*32768),('x'*251,'x'*32769),('中😀 '*100,'中😀'*32770),
 ('x'*249,'part\n'*9000),('x'*260,'part '*9000),('x'*260,'part.\v'*8000),
 ('','x'*65537),('title','\n\v\f'+'x'*32767+'  tail   '),
 ('title','a'*32765+'&amp;'+'a'*100),
 ('title','a'*32765+'[test](url)'+'a'*100),
 ('title','a'*32765+'![test](url)'+'a'*100),
 ('title','a'*32766+'\v\f'*100),
]
cases=[]
for fmt in ['text','html','markdown']:
 for overflow in ['upstream','truncate','split']:
  for title,body in contents:
   for status in [200,400]:
    calls=[]
    def request(method,url,**kw):
     calls.append(dict(method=method,url=url,data=kw.get('data'),headers=kw.get('headers'),params=kw.get('params'),auth=kw.get('auth'),verify=kw.get('verify'),timeout=kw.get('timeout')))
     r=requests.Response();r.status_code=status;r._content=b'{}';return r
    requests.request=request
    u='json://owned.invalid/notify?format='+fmt+'&overflow='+overflow
    a=apprise.Apprise();added=a.add(u)
    try:result=a.notify(title=title,body=body);error=None
    except Exception as e:result=None;error=type(e).__name__
    cases.append(dict(url=u,title=title,body=body,added=added,result=result,error=error,calls=calls,status=status))
for body in [':smile:',':SMILE:',':laughing:',':satisfied:',':not_an_emoji:',':smile: :heart:',':+1:',':-1:',':women_holding_hands:',':grinning:',':flag_jp:',':japan:']:
 for title in ['title',':smile:']:
  calls=[]
  def request(method,url,**kw):
   calls.append(dict(method=method,url=url,data=kw.get('data'),headers=kw.get('headers'),params=kw.get('params'),auth=kw.get('auth'),verify=kw.get('verify'),timeout=kw.get('timeout')))
   r=requests.Response();r.status_code=200;r._content=b'{}';return r
  requests.request=request
  u='json://owned.invalid/notify?emojis=yes';a=apprise.Apprise();added=a.add(u)
  try:result=a.notify(title=title,body=body);error=None
  except Exception as e:result=None;error=type(e).__name__
  cases.append(dict(url=u,title=title,body=body,added=added,result=result,error=error,calls=calls,status=200))
raw=('\n'.join(json.dumps(c,ensure_ascii=False,sort_keys=True)for c in cases)+'\n').encode()
p=out/'json-overflow.jsonl.gz'
with p.open('wb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='')as z:z.write(raw)
print(json.dumps(dict(cases=len(cases),emoji_patterns=len(EMOJI_MAP),source_errors=sum(c['error']is not None for c in cases),sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
