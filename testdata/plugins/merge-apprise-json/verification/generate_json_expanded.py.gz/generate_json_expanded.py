"""Synthetic Apprise 1.9.9 cases; transports and DNS are never permitted."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,gzip,hashlib,logging,socket
BASE=Path('/Users/accidia/projects/light-media/work/_merge_message_native_port')
APP=Path(__file__).resolve().parent/'app'
sys.path[:0]=[str(BASE/'oracle-deps'),str(APP/'testdata/plugins/merge-message-notify-1.20.1/input/_merge_message_notify_port/reference/dependencies/apprise')]
import requests,apprise
logging.disable(logging.CRITICAL)
def deny(*a,**k):raise AssertionError('offline source attempted network')
socket.create_connection=deny
socket.socket.connect=deny
socket.socket.connect_ex=deny
socket.getaddrinfo=deny
urls=['json://owned.invalid','jsons://owned.invalid/notify']
for query in [
 'METHOD=get','method=DELETE;verify=invalid','method=PUT&method=PATCH',
 '+X-Test=a+b&-tag=a+b&:extra=a+b',
 '%2BX%252DTest=a%2520b&%3Aextra=a%2526b','+X=a;+X=b&-x=one;-x=two',
 ':extra=first&:extra=last',':message=title',':title=message',':message=message',
 ':extra=x&:message=extra',':message=body&:body=value',':title=&:version=&:type=',
 'user=admin&pass=test','user=admin&password=first&pass=last',
 'user=admin&user=next','port=9999','port=abc','port=0','port=-1',
 'CTO=2&RTO=3','cto=0&rto=-2','cto=1e2&rto=2.5','cto=bad&rto=bad',
 'verify=invalid','verify=','VERIFY=enable','verify=0&verify=1',
 'overflow=TRUNCATE','overflow=invalid','format=HTML','format=markdown',
 'emojis=no','emojis=yes','emojis=invalid',
 '+User-Agent=custom&+Content-Type=application/synthetic',
 '+X=one%20&-x=%20two%20&:extra=%20three%20',
 '%20method%20=HEAD','method=%2550OST','method=%20POST%20',
 '+X%2BTest=one&:a%2Bb=two','+X%ZZ=one&:a=%ZZ',
]:urls.append('json://owned.invalid/notify?'+query)
for host in ['owned.invalid.','owned_service','-owned.invalid','owned-.invalid','1','a','127.0.0.1','999.0.0.1','[::1]','[::1]:1234','[ABCD::1]', 'owned.invalid:0','owned.invalid:99999','owned.invalid:abc']:
 urls.append('json://'+host+'/notify')
for path in ['/a%20b','/a%2520b','//a///b//','/a/../b','/a/./b','/中文/😀','/a+b','/a:b;d','/a%2Fb','/a#frag','/a%ZZ']:
 urls.append('json://owned.invalid'+path)
for auth in ['user','user:pass','user%2520name:pass%2520word','user:p:a:s:s',':pass','orig']:
 for query in ['', '?user=override','?user=override&pass=other']:
  urls.append('json://'+auth+'@owned.invalid/a'+query)
contents=[(' 标题\t','正文\n second <&> \x1f'),('', 'body'),('title',''),(None,'body'),(False,'body'),(0,'body'),([], 'body'),({},'body'),('title',False),('title',0),('title',[]),('title',{})]
cases=[]
for u in urls:
 for title,body in contents:
  calls=[]
  def request(method,url,**kw):
   calls.append(dict(method=method,url=url,data=kw.get('data'),headers=kw.get('headers'),params=kw.get('params'),auth=kw.get('auth'),verify=kw.get('verify'),timeout=kw.get('timeout')))
   r=requests.Response();r.status_code=200;r._content=b'{}';return r
  requests.request=request
  a=apprise.Apprise()
  added=a.add(u)
  try:result=a.notify(title=title,body=body);error=None
  except Exception as e:result=None;error=type(e).__name__
  cases.append(dict(url=u,title=title,body=body,added=added,result=result,error=error,calls=calls))
raw=('\n'.join(json.dumps(c,ensure_ascii=False,sort_keys=True) for c in cases)+'\n').encode()
for attach in [None,'',False,True,0,7,[],{}, {'x':'y'},[None,False,7,{}]]:
 calls=[]
 def request(method,url,**kw):
  calls.append(dict(method=method,url=url,data=kw.get('data'),headers=kw.get('headers'),params=kw.get('params'),auth=kw.get('auth'),verify=kw.get('verify'),timeout=kw.get('timeout')))
  r=requests.Response();r.status_code=200;r._content=b'{}';return r
 requests.request=request
 a=apprise.Apprise();u='json://owned.invalid/notify';added=a.add(u)
 try:result=a.notify(title='title',body='body',attach=attach);error=None
 except Exception as e:result=None;error=type(e).__name__
 cases.append(dict(url=u,title='title',body='body',attach=attach,added=added,result=result,error=error,calls=calls))
raw=('\n'.join(json.dumps(c,ensure_ascii=False,sort_keys=True) for c in cases)+'\n').encode()
dest=APP/'internal/plugins/mergemessagenotify/apprise/testdata/json-expanded.jsonl.gz'
with dest.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:z.write(raw)
print(json.dumps(dict(cases=len(cases),urls=len(urls),errors=sum(c['error'] is not None for c in cases),sha256=hashlib.sha256(dest.read_bytes()).hexdigest())))
