"""Offline pinned Apprise source capture. All transport is denied or recorded."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,gzip,hashlib,logging,socket
BASE=Path('/Users/accidia/projects/light-media/work/_merge_message_native_port')
APP=Path(__file__).resolve().parent/'app'
sys.path[:0]=[str(BASE/'oracle-deps'),str(APP/'testdata/plugins/merge-message-notify-1.20.1/input/_merge_message_notify_port/reference/dependencies/apprise')]
import requests,apprise
import apprise.plugins
logging.disable(logging.CRITICAL)
def deny(*args,**kwargs):
    raise AssertionError('offline oracle attempted real network')
socket.create_connection=deny
socket.socket.connect=deny
socket.socket.connect_ex=deny
socket.getaddrinfo=deny

catalog=[]
for name in sorted(apprise.plugins.N_MGR.schemas()):
    cls=apprise.plugins.N_MGR[name]
    catalog.append(dict(schema=name,classname=cls.__name__,service=str(cls.service_name),enabled=cls.enabled,protocol=cls.protocol,secure_protocol=cls.secure_protocol,title_maxlen=cls.title_maxlen,body_maxlen=cls.body_maxlen,format=cls.notify_format.value,attachment=cls.attachment_support))

cases=[]
urls=[
 'json://owned.invalid','jsons://owned.invalid/notify',
 'json://user:pass@owned.invalid:8080/a%20b?method=put',
 'json://owned.invalid/path?+X-Test=hello&-tag=a&:message=body&:extra=one',
 'json://owned.invalid/path?method=PATCH&verify=no&cto=2&rto=3',
 'json://owned.invalid/path?method=INVALID',
 'not-a-url','unknown-service://owned.invalid',
 'json://owned.invalid/a?format=text','json://owned.invalid/a?format=html',
 'json://owned.invalid/a?overflow=truncate',
 'json://owned.invalid/a?%3Atitle=&%3Amessage=body',
 'json://[::1]:8080/a','JSON://OWNED.invalid/a',
]
for u in urls:
 for status in [200,204,299,300,400]:
    calls=[]
    def request(method,url,**kw):
        data=kw.get('data')
        try: payload=json.loads(data)
        except (TypeError,ValueError): payload=data
        calls.append(dict(method=method,url=url,payload=payload,headers=kw.get('headers'),params=kw.get('params'),auth=kw.get('auth'),verify=kw.get('verify'),timeout=kw.get('timeout')))
        r=requests.Response();r.status_code=status;r._content=b'{}';r.encoding='utf8';return r
    requests.request=request
    requests.sessions.Session.request=request
    a=apprise.Apprise()
    added=a.add(u)
    result=a.notify(title='  合成标题<&>  ',body='正文\n第二行  ')
    cases.append(dict(url=u,status=status,added=added,result=result,calls=calls))

output=APP/'internal/plugins/mergemessagenotify/apprise/testdata'
output.mkdir(parents=True,exist_ok=True)
for name,data in [('catalog.json',catalog),('json-native-cases.json',cases)]:
 raw=(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2,default=lambda o:dict(descriptor=type(o).__name__))+'\n').encode()
 (output/name).write_bytes(raw)
 print(json.dumps(dict(name=name,count=len(data),sha256=hashlib.sha256(raw).hexdigest())))
