"""Owned loopback HTTP oracle from pinned source; no external destinations."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,gzip,hashlib,logging,threading,socket,os,base64
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
BASE=Path('/Users/accidia/projects/light-media/work/_merge_message_native_port')
APP=Path(__file__).resolve().parent/'app'
sys.path[:0]=[str(BASE/'oracle-deps'),str(APP/'testdata/plugins/merge-message-notify-1.20.1/input/_merge_message_notify_port/reference/dependencies/apprise')]
import requests,apprise
logging.disable(logging.CRITICAL)
# Project exact read-only NAS metadata onto the owned source environment.
requests.utils.DEFAULT_ACCEPT_ENCODING='gzip, deflate, br'
for k in list(os.environ):
 if k.lower().endswith('_proxy'):del os.environ[k]
os.environ['NO_PROXY']='127.0.0.1'
calls=[]
class Handler(BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*a):pass
 def handle_request(self):
  body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  headers={k.lower():base64.b64encode(v.encode('latin1')).decode('ascii') for k,v in self.headers.items() if k.lower() not in ['host','content-length']}
  calls.append(dict(method=self.command,path=self.path,headers=headers,body=body.decode('utf8')))
  if self.path.startswith('/redirect/'):
   status=int(self.path.split('/')[2].split('?')[0]);self.send_response(status);self.send_header('Location','/final');self.send_header('Set-Cookie','owned=yes; Path=/')
  else:self.send_response(204)
  self.send_header('Content-Length','0');self.end_headers()
 do_GET=do_POST=do_PUT=do_PATCH=do_DELETE=do_HEAD=do_OPTIONS=do_UPDATE=handle_request
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
port=server.server_port
original_connect=socket.socket.connect
def guarded_connect(sock,address):
 if address!=('127.0.0.1',port):raise AssertionError('oracle attempted non-owned connection')
 return original_connect(sock,address)
socket.socket.connect=guarded_connect
cases=[]
queries=['method='+m for m in ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','UPDATE']]
queries += ['+X-Test=a+b&-z=first&-a=second&:message=body','+User-Agent=one&+user-agent=two','+Content-Type=owned/test','user=admin','user=admin&pass=','user=admin&pass=p%C3%A4ss','user=admin&pass=%E4%B8%AD%E6%96%87','+X-Accent=caf%C3%A9','+X-NonLatin=%E4%B8%AD%E6%96%87','+X-Test=line%0Abreak','cto=0','rto=-1']
try:
 for query in queries:
  calls.clear();u='json://127.0.0.1:'+str(port)+'/notify?'+query
  a=apprise.Apprise();added=a.add(u);result=a.notify(title='标题',body='正文')
  cases.append(dict(path='/notify',query=query,added=added,result=result,calls=list(calls)))
 for status in [301,302,303,307,308]:
  for method in ['GET','POST','PUT','PATCH','DELETE','HEAD']:
   calls.clear();path='/redirect/'+str(status);query='method='+method+'&user=owned&pass=synthetic'
   a=apprise.Apprise();added=a.add('json://127.0.0.1:'+str(port)+path+'?'+query);result=a.notify(title='标题',body='正文')
   cases.append(dict(path=path,query=query,added=added,result=result,calls=list(calls)))
finally:
 server.shutdown();server.server_close();thread.join()
raw=('\n'.join(json.dumps(c,ensure_ascii=False,sort_keys=True)for c in cases)+'\n').encode();p=APP/'internal/plugins/mergemessagenotify/apprise/testdata/http-wire.jsonl.gz'
with p.open('wb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='')as z:z.write(raw)
print(json.dumps(dict(cases=len(cases),requests=sum(len(c['calls'])for c in cases),external_requests=0,nas_metadata_projection=['Accept-Encoding'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
