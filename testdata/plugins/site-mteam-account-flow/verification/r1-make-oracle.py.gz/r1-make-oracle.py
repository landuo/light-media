"""Installed full parser and Indexer DTO, with in-memory HTTP responses only."""
import ast,sys,json,hashlib,copy,re
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
from urllib import parse
from urllib.parse import urlsplit,urljoin
from abc import ABCMeta,abstractmethod
from enum import Enum
from typing import Optional,Any,Union,Dict,List,Tuple
from pydantic import BaseModel,Field,ConfigDict
from pyquery import PyQuery
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('side_effect_denied')
 if event=='open' and ((isinstance(args[1],str) and any(c in args[1] for c in 'wax+')) or (isinstance(args[2],int) and args[2]&(1|2|64|512))):raise RuntimeError('write_denied')
sys.addaudithook(audit)
class Quiet:
 def __getattr__(self,n):return lambda *a,**k:None
class FixedDatetime(datetime):
 @classmethod
 def now(cls,*args,**kwargs):return cls(2026,10,21,12,34,56)
sources={};ns=dict(globals());ns.update(logger=Quiet(),Session=object,datetime=FixedDatetime,settings=SimpleNamespace(SITE_MESSAGE=False,PROXY=None,ENCODING_DETECTION_PERFORMANCE_MODE=True,ENCODING_DETECTION_MIN_CONFIDENCE=0.5))
def tree(path):
 raw=(Path('/app')/path).read_bytes();sources[path]=hashlib.sha256(raw).hexdigest();return ast.parse(raw)
def execute(nodes):
 module=ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[]));exec(compile(module,'<installed-owned-mteam-oracle>','exec'),ns)
def loadclass(path,name,methods=None):
 n=next(n for n in tree(path).body if isinstance(n,ast.ClassDef) and n.name==name)
 if methods is not None:n.body=[n for n in n.body if isinstance(n,ast.FunctionDef) and n.name in methods];n.bases=[];n.keywords=[]
 execute([n]);return ns[name]
st=tree('app/utils/string.py');execute([next(n for n in st.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_special_domains' for t in n.targets))])
loadclass('app/utils/string.py','StringUtils',['get_url_domain','get_url_netloc'])
cf=tree('app/helper/cloudflare.py');execute([n for n in cf.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['CHALLENGE_TITLES','CHALLENGE_SELECTORS'] for t in n.targets) or isinstance(n,ast.FunctionDef) and n.name=='under_challenge'])
loadclass('app/schemas/site.py','SiteUserData')
basepath='app/modules/indexer/parser/__init__.py';execute([next(n for n in tree(basepath).body if isinstance(n,ast.ClassDef) and n.name=='SiteSchema')]);loadclass(basepath,'SiteParserBase')
parser=loadclass('app/modules/indexer/parser/mtorrent.py','MTorrentSiteUserInfo')
module=loadclass('app/modules/indexer/__init__.py','IndexerModule',['refresh_userdata'])
trace=[];positions={};responses={};unexpected=[]
class Response:
 def __init__(self,v):self.status_code=v['status'];self.text=v['body']
 def json(self):return json.loads(self.text)
class RequestUtils:
 def __init__(self,**kwargs):self.options=kwargs
 @staticmethod
 def get_decoded_html_content(response,*args):return response.text
 def _call(self,method,url,kwargs):
  endpoint=urlsplit(url).path;index=positions.get(endpoint,0);positions[endpoint]=index+1
  kind='json' if 'json' in kwargs else 'form' if 'data' in kwargs else 'none'
  body=copy.deepcopy(kwargs.get('json') if kind=='json' else {k:[str(v)] for k,v in (kwargs.get('data') or {}).items() if v is not None} if kind=='form' else None)
  trace.append(dict(method=method,url=url,headers=self.options.get('headers') or {},body_kind=kind,body=body,timeout=self.options['timeout']))
  items=responses.get(endpoint,[])
  if index>=len(items):unexpected.append(endpoint);raise RuntimeError('owned_reply_exhausted')
  return Response(items[index])
 def post_res(self,url,**kwargs):return self._call('POST',url,kwargs)
 def get_res(self,url,**kwargs):return self._call('GET',url,kwargs)
ns['RequestUtils']=RequestUtils
def reply(data,status=200,raw=False):return dict(status=status,body=data if raw else json.dumps(data,ensure_ascii=False,separators=(',',':')))
def success(data):return {'code':'0','data':data}
def torrent(size=100,source=2,**extra):return dict(torrent=dict(size=size,source=source,**extra))
profile=success(dict(id=7,username=' owned ',role='18',memberStatus=dict(createdDate='2024-01-02 03:04:05'),memberCount=dict(uploaded='12_345',downloaded='200',shareRate='61.725',bonus='17.5')))
cases=[]
def case(name,prof=None,lists=None,peers=None,messages=None,marks=None,read=False):
 responses.clear();positions.clear();trace.clear();unexpected.clear()
 responses.update({'/api/member/profile':[prof if prof is not None else reply(profile)],'/api/member/getUserTorrentList':lists if lists is not None else [reply(success(dict(total=0,data=[])))],'/api/tracker/myPeerStatus':peers if peers is not None else [reply(success(dict(seeder=0,leecher=99)))],'/api/msg/search':messages if messages is not None else [reply(success(dict(data=[])))],'/api/msg/markRead':marks or []})
 inputs=copy.deepcopy(responses);ns['settings'].SITE_MESSAGE=read
 m=module();m._site_schemas=[parser];data=None;error=None
 try:data=m.refresh_userdata(dict(name='owned',url='https://api.m-team.cc',schema='MTorrent',apikey='synthetic-owned-api-key',ua='synthetic-configured-UA'))
 except Exception as e:error=type(e).__name__
 assert not unexpected,(name,unexpected)
 cases.append(dict(name=name,read_messages=read,replies=inputs,requests=copy.deepcopy(trace),data=data.model_dump() if data is not None else None,error_type=error))
case('two-pages-peer-driven',lists=[reply(success(dict(total=1,data=[torrent(),torrent(200,3)]))),reply(success(dict(total=999,data=[torrent(300,4),torrent(400,5),torrent(500,6)])))],peers=[reply(success(dict(seeder=5))),reply(success(dict(seeder=5)))])
case('messages-before-seeding',read=True,messages=[reply(success(dict(data=[dict(id=10,unread=True,title=' heading ',createdDate=' date ',context=' body '),dict(id=11,unread=False,title='old',createdDate='date',context='body'),dict(id=None,unread='0',title=1,createdDate={'date':'owned'},context=['body']),dict(id=12,unread=True,title='',createdDate='date',context='body')])))] ,marks=[reply({'code':'0'}),reply('ignored',503,True)])
case('profile-unavailable-continues-GET',prof=reply('unavailable',503,True),lists=[reply(success(dict(data=[torrent()])))])
case('profile-invalid-json-aborts',prof=reply('{',raw=True))
case('profile-business-error-continues-GET',prof=reply({'code':'1'}))
case('profile-null-continues-GET',prof=reply(None))
case('list-invalid-JSON-stops',lists=[reply('{',raw=True)])
case('later-list-invalid-JSON-keeps-source-partial',lists=[reply(success(dict(data=[torrent()]))),reply('{',raw=True)],peers=[reply(success(dict(seeder=3)))])
case('invalid-rows-skipped',lists=[reply(success(dict(data=[None,1,{},dict(torrent=None),torrent('12','2'),dict(torrent={})])))],peers=[reply(success(dict(seeder=2)))])
case('invalid-size-aborts',lists=[reply(success(dict(data=[torrent('not-an-int')])))] )
case('invalid-peer-is-caught',lists=[reply(success(dict(data=[torrent()])))],peers=[reply('{',raw=True)])
case('peer-code-ignored',lists=[reply(success(dict(data=[torrent()])))],peers=[reply({'code':'1','data':{'seeder':1}})])
case('message-invalid-json-aborts-before-list',read=True,messages=[reply('{',raw=True)])
bad=copy.deepcopy(profile);bad['data']['username']=42
case('schema-validation-after-seeding',prof=reply(bad),lists=[reply(success(dict(data=[torrent()])))])
bad=copy.deepcopy(profile);bad['data']['memberCount']['uploaded']='1.5'
case('invalid-upload-aborts-before-messages',prof=reply(bad),read=True)
bad=copy.deepcopy(profile);bad['data']['id']=True
case('boolean-ID-wire-vs-DTO',prof=reply(bad))
bad=copy.deepcopy(profile);bad['data']['role']=[]
case('empty-role-default',prof=reply(bad))
case('challenge-profile-continues-GET',prof=reply('<title>Just a moment...</title>',raw=True))
case('empty-message-dictionary-is-iterable',read=True,messages=[reply(success(dict(data={})))])
case('nonempty-message-dictionary-throws',read=True,messages=[reply(success(dict(data={'bad':'row'})))])
bad=copy.deepcopy(profile);bad['data']['id']=7.5
case('fractional-ID-schema-fails-after-requests',prof=reply(bad))
bad=copy.deepcopy(profile);bad['data']['id']=2**80
case('large-integer-ID-preserved',prof=reply(bad))
bad=copy.deepcopy(profile);bad['data']['memberCount']['bonus']='1_0'
case('underscore-bonus-schema',prof=reply(bad))
print(json.dumps(dict(scope='installed complete SiteParserBase/MTorrent parse and Indexer DTO methods; all HTTP is an in-memory mock, no real business or app module import',source_sha256=sources,cases=cases),ensure_ascii=False,separators=(',',':')))
