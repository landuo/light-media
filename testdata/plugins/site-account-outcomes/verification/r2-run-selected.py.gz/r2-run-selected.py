import pathlib,subprocess,os,json,re,hashlib
root=pathlib.Path('/Users/accidia/projects/light-media');stage=pathlib.Path(__file__).resolve().parent
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(root/'work/_site_statistic_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=30)
assert r.returncode==0,'readonly_source_capture_failed'
v=json.loads(r.stdout);forbidden=[]
for raw in v['account_rows']:
 row=json.loads(raw)
 for k in ['username','userid']:
  value=row.get(k)
  if isinstance(value,str) and len(value)>=6:
   forbidden.extend([('"'+k+'":"'+value+'"').encode(),('"'+k+'": "'+value+'"').encode()])
 forbidden.append(raw.encode())
reports=[]
for kind,binary,cli,handoff in [('normal','app.test','statistic-migrate','handoff'),('race','app-race.test','statistic-migrate-race','handoff-race')]:
 result=subprocess.run([str(stage/binary),'-test.run=^TestReviewedStatisticSelectedStdin$','-test.v','-test.timeout=600s'],input=r.stdout,capture_output=True,env=dict(os.environ,LIGHT_MEDIA_REVIEWED_STATISTIC='owned-selected-stdin',LIGHT_MEDIA_STATISTIC_CLI=str(stage/cli),LIGHT_MEDIA_HANDOFF_CLI=str(stage/handoff)),timeout=615)
 log=result.stdout+result.stderr;assert not any(x in log for x in forbidden),'private_account_payload_in_test_log'
 (stage/('actual-'+kind+'.log')).write_bytes(log);report={'kind':kind,'exit':result.returncode,'terminal_pass':result.returncode==0 and bool(re.search(rb'^--- PASS: TestReviewedStatisticSelectedStdin \(',log,re.M)),'source_payload_saved':False,'account_rows':len(v['account_rows']),'log_sha256':hashlib.sha256(log).hexdigest(),'source_account_log_scan_passed':True};reports.append(report);(stage/'actual-status.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(report),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
