import pathlib,subprocess,json,hashlib,re,urllib.parse,base64,gzip
root=pathlib.Path('/Users/accidia/projects/light-media');s=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((s/n).read_text())
statuses={n:read(n) for n in ['sites-status.json','related-status.json','actual-status.json','build-normal-status.json','build-race-status.json','build-linux-status.json']}
for name,values in statuses.items():
 assert values and all(x['exit']==0 for x in values),name
 if name in ['sites-status.json','related-status.json','actual-status.json']:assert len(values)==2
nas=read('nas-verification.json');assert nas['state']=='passed_owned_linux_business' and nas['owned_container_removed'] and nas['owned_runtime_directory_removed'] and nas['original_and_production_containers_unchanged'];assert not nas['execution']['oom_killed'] and nas['execution']['exit_code']==0
cleanup=read('nas-independent-cleanup.json');assert all(cleanup.values())
checks={}
for name in ['sites-normal','sites-race','related-normal','related-race','actual-normal','actual-race','nas-selected']:
 b=(s/(name+'.log')).read_bytes();v={k:len(re.findall(pattern,b,re.M)) for k,pattern in [('top_pass',rb'^--- PASS:'),('inclusive_pass',rb'^\s*--- PASS:'),('fail',rb'^\s*--- FAIL:'),('skip',rb'^\s*--- SKIP:')]};v['sha256']=hashlib.sha256(b).hexdigest();assert not v['fail'] and not v['skip'];checks[name]=v
assert checks['nas-selected']['inclusive_pass']==31
sources=read('SOURCE-INPUTS.json');inputs=read('COMPILATION-INPUTS.json')
assert all(hashlib.sha256((s/'app'/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in sources)
for x in inputs:
 p=s/'app'/x['path'][5:] if x['path'].startswith('repo/') else pathlib.Path(x['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
paths=set(p.decode() for p in subprocess.check_output(['git','ls-files','-mo','--exclude-standard','-z'],cwd=root).split(b'\0') if p)
focus=sorted(n for n in paths if n.startswith('internal/') or n in ['testdata/plugins/site-account-outcomes-original-oracle.json','testdata/plugins/site-statistic-http-original-oracle.json'])
manifest={x['path']:x['sha256'] for x in sources};assert all(manifest[n]==hashlib.sha256((root/n).read_bytes()).hexdigest() for n in focus)
drift={'frozen_source_files':len(sources),'resolved_compilation_files':len(inputs),'frozen_drift':0,'compilation_drift':0,'main_product_focus_drift':0,'docs_written_after_checks':['docs/plugin-site-account-outcomes.txt','docs/plugin-site-account-outcomes-verification.json','docs/plugin-installed-migration-baseline.md'],'scope_limit':'does not claim complete compiler, system header or linker dependency closure'}
(s/'DRIFT-REVIEW.json').write_text(json.dumps(drift,indent=2)+'\n')
web=[x for x in sources if x['path'].startswith('web/')];assert all((root/x['path']).read_bytes()==(s/'app'/x['path']).read_bytes() for x in web)
files=sorted(p for d in [s,s.parent/'r1'] for p in d.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.stderr'])
docs=[root/'docs/plugin-site-account-outcomes.txt',root/'docs/plugin-installed-migration-baseline.md']
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(root/'work/_site_statistic_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=35);assert r.returncode==0,'readonly_final_source_scan_failed';v=json.loads(r.stdout);needles=set();secrets=set()
def walk(v,k=''):
 if isinstance(v,dict):
  for key,x in v.items():walk(x,key.lower())
 elif isinstance(v,list):
  for x in v:walk(x,k)
 elif isinstance(v,str):
  if v[:1] in ('{','['):
   try:walk(json.loads(v),k)
   except (ValueError,TypeError):pass
  if len(v)>=6 and any(x in k for x in ['password','cookie','token','apikey','api_key','passkey','authorization','secret']):secrets.add(v)
  for url in re.findall(r'https?://[^\s<>"\']+',v):
   for key,vals in urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).items():
    if any(x in key.lower() for x in ['passkey','token','auth','key']):secrets.update(x for x in vals if len(x)>=6)
walk(v)
for raw in v['account_rows']:
 needles.add(raw.encode());row=json.loads(raw)
 for key in ['username','userid']:
  value=row.get(key)
  if isinstance(value,str) and value:
   needles.update([('"'+key+'":'+json.dumps(value,ensure_ascii=False)).encode(),('"'+key+'": '+json.dumps(value,ensure_ascii=False)).encode()])
   if len(value)>=6:
    q=json.dumps(value,ensure_ascii=False);needles.update([q.encode(),json.dumps(q,ensure_ascii=False)[1:-1].encode()])
for value in secrets:needles.update(x.encode() for x in [value,urllib.parse.quote(value,safe=''),base64.b64encode(value.encode()).decode()])
for p in files+docs+[root/n for n in focus]:assert not any(x in p.read_bytes() for x in needles),'private_source_material_detected_no_archive_written'
oracle=json.loads((root/'testdata/plugins/site-account-outcomes-original-oracle.json').read_text())
report={'version':1,'date':'2026-10-21','base_commit':'7d7486578c1926120a05de04609fcb3f20856f19','state':'source_refresh_outcomes_and_event_semantics_verified_not_full_plugin_migration','actual_complete':7,'remaining':16,'production_version':'0.4.8','deployed':False,'original_mutations':0,'production_mutations':0,'real_execution_handoffs':0,'real_user_site_downloader_media_or_notification_business_calls':0,'python_runtime_dependency_added':False,'source_account_rows':len(v['account_rows']),'source_outcome_oracle':{'cases':len(oracle['cases']),'source_sha256':oracle['source_sha256'],'scope':oracle['scope'],'fixture_sha256':hashlib.sha256((root/'testdata/plugins/site-account-outcomes-original-oracle.json').read_bytes()).hexdigest()},'implementation':{'separate_source19_field_DTO_and_native_observations':True,'error_DTO_API_success_with_err_msg':True,'source_None_empty_failed_API':True,'error_DTO_emits_source_site_and_aggregate_refresh_facts':True,'native_job_and_connection_health_remain_separate':True,'source_constructor_zero_and_empty_lists_do_not_change_native_unknown':True,'nullable_API_timestamp_separate_database_refresh_time':True,'None_does_not_create_daily_history':True,'later_error_DTO_preserves_prior_same_day_row':True,'lost_ACK_encrypted_cold_recovery_does_not_refetch':True,'MTeam_numeric_or_string_user_id_and_roles17_18':True,'complete_MTeam_list_count_not_peer_count':True,'HTTP403_500_body_exception_only_in_source_account_context':True,'revoked_and_cancelled_requests_do_not_manufacture_error_DTO':True},'checks':checks,'statuses':statuses,'nas':nas,'independent_cleanup':cleanup,'inputs':drift,'source_manifest_sha256':hashlib.sha256((s/'SOURCE-INPUTS.json').read_bytes()).hexdigest(),'compilation_manifest_sha256':hashlib.sha256((s/'COMPILATION-INPUTS.json').read_bytes()).hexdigest(),'focus':[{'path':n,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in focus],'frontend':{'changed':False,'retested':False,'same_as_base_commit':True,'verified_file_count':len(web),'user_acceptance_claimed':False},'peak_RSS_measured':False,'secret_scan':{'passed':True,'source_account_rows':len(v['account_rows']),'patterns':len(needles),'files':len(files+docs+focus),'private_payload_saved':False},'failures_retained':[{'scope':'r1 exploration','cause':'sourceUserInteger initially reused an existing helper name; duplicate declaration fixed','accepted':False},{'scope':'r1 exploratory oracle','cause':'incomplete AST stub omitted request_mode/API key, producing invalid early outcomes; source constructor and 12 final cases corrected before freezing','accepted':False},{'scope':'r1 app focus','cause':'MTeam loopback origin correctly rejected and test event SQL referenced missing column; retained origin restriction, used owned synthetic transport and fixed test SQL','accepted':False},{'scope':'r2 setup','cause':'first orchestration helper used relative path from stage cwd; corrected absolute path, no frozen app edit','accepted':False}],'remaining':['Complete original parser request addresses/order, pagination and all special numeric/schema branches.','SystemError event and full site-message/statistic notification producers and channels.','Compiled SitesHelper alias runtime evidence.','Formal migration of source global message setting, final fresh source binding, execution handoff and production migration.','All remaining plugin business, platform and source-data migration obligations; no increase to completed 7/23.']}
out=root/'docs/plugin-site-account-outcomes-verification.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');assert not any(x in out.read_bytes() for x in needles)
archive=root/'testdata/plugins/site-account-outcomes/verification';archive.mkdir(parents=True,exist_ok=False)
for p in files:
 (archive/(p.parent.name+'-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(archive/'index.json').write_text(json.dumps({'files':[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(archive.iterdir())]},indent=2)+'\n')
print(json.dumps({'report':str(out),'proof_files':len(list(archive.iterdir())),'checks':checks,'secret_scan_passed':True,'actual_complete':7,'goal_complete':False}))
