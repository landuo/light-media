import pathlib,subprocess,re,json
s=pathlib.Path(__file__).resolve().parent;out=[]
for kind,b in [('normal','sites.test'),('race','sites-race.test')]:
 p=subprocess.run([str(s/b),'-test.v','-test.timeout=300s'],cwd=s/'app/internal/sites',capture_output=True,timeout=315);log=p.stdout+p.stderr;(s/('sites-'+kind+'.log')).write_bytes(log);v={'kind':kind,'exit':p.returncode,'top_pass':len(re.findall(rb'^--- PASS:',log,re.M)),'inclusive_pass':len(re.findall(rb'^\s*--- PASS:',log,re.M)),'failures':[x.decode() for x in re.findall(rb'^\s*--- FAIL: (\S+)',log,re.M)]};out.append(v);(s/'sites-status.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(v),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
