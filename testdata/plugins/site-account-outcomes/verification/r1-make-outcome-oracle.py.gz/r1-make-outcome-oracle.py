"""Read-only installed methods, synthetic parser responses and in-memory sinks."""
import ast,json,hashlib,sys,re,traceback,warnings
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
from urllib.parse import urljoin,urlsplit
from pydantic import BaseModel,Field,ConfigDict
from lxml import etree
warnings.filterwarnings('ignore')
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('side_effect_denied')
 if event=='open' and ((isinstance(args[1],str) and any(c in args[1] for c in 'wax+')) or (isinstance(args[2],int) and args[2]&(1|2|64|512))):raise RuntimeError('write_denied')
sys.addaudithook(audit)
class Quiet:
 def __getattr__(self,n):return lambda *a,**k:None
sources={};ns=dict(json=json,re=re,traceback=traceback,logger=Quiet(),datetime=datetime,urljoin=urljoin,urlsplit=urlsplit,etree=etree,BaseModel=BaseModel,Field=Field,ConfigDict=ConfigDict,settings=SimpleNamespace(SITE_MESSAGE=False,API_TOKEN='owned-key'))
def source(path):
 p=Path('/app')/path;b=p.read_bytes();sources[path]=hashlib.sha256(b).hexdigest();return ast.parse(b)
def execute(nodes):
 mod=ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[]));exec(compile(mod,'<installed-owned-outcome-oracle>','exec'),ns)
def cls(path,name,methods=None,bases=None):
 n=next(x for x in source(path).body if isinstance(x,ast.ClassDef) and x.name==name)
 if methods is not None:n.body=[x for x in n.body if isinstance(x,ast.FunctionDef) and x.name in methods]
 if bases is not None:n.bases=[ast.Name(id=x,ctx=ast.Load()) for x in bases];n.keywords=[]
 execute([n]);return ns[name]
ns.update(__import__('typing').__dict__)
ns['StringUtils']=SimpleNamespace(is_valid_html_element=lambda x:x is not None,get_url_domain=lambda s:urlsplit(s).netloc,str_int=lambda s:int(s))
SiteUtils=cls('app/utils/site.py','SiteUtils')
DTO=cls('app/schemas/site.py','SiteUserData')
base=cls('app/modules/indexer/parser/__init__.py','SiteParserBase',['__init__','parse','_parse_logged_in'],[])
base.request_mode='cookie';base.close=lambda self:None;base.clear=lambda self:None
ns['Session']=object;ns['SiteSchema']=SimpleNamespace(MTorrent=SimpleNamespace(value='mteam'))
mt=cls('app/modules/indexer/parser/mtorrent.py','MTorrentSiteUserInfo',['_parse_site_page','_parse_user_base_info'],['SiteParserBase'])
mt.MTeam_sysRoleList=next(ast.literal_eval(x.value) for x in next(x for x in source('app/modules/indexer/parser/mtorrent.py').body if isinstance(x,ast.ClassDef)).body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MTeam_sysRoleList' for t in x.targets))
mt.request_mode='apikey';mt.schema=SimpleNamespace(value='mteam')
mt._parse_user_detail_info=lambda *a:None;mt._parse_user_traffic_info=lambda *a:None;mt._parse_seeding_pages=lambda *a:None
base._parse_site_page=lambda self,x:None;base._parse_user_base_info=lambda self,x:None;base._parse_user_detail_info=lambda self,x:None;base._parse_user_traffic_info=lambda self,x:None;base._parse_seeding_pages=lambda self:None;base.schema=SimpleNamespace(value='nexus')
hh=cls('app/modules/indexer/parser/nexus_hhanclub.py','NexusHhanclubSiteUserInfo',['_parse_user_traffic_info'],['SiteParserBase'])
hh.schema=SimpleNamespace(value='hhanclub');hh._parse_user_base_info=lambda self,x:self._parse_user_traffic_info(x);hh._prepare_html_text=lambda self,x:x
module=cls('app/modules/indexer/__init__.py','IndexerModule',['refresh_userdata'],[])
module.get_priority=lambda self:1;module.get_name=lambda self:'owned'
chain=cls('app/chain/__init__.py','ChainBase',['run_module','__execute_system_modules'],[])
chain._ChainBase__execute_plugin_modules=lambda *a,**k:None
chain._ChainBase__is_valid_empty=lambda self,v:v is None
errors=[]
chain._ChainBase__handle_system_error=lambda *a,**k:errors.append(type(a[1]).__name__+':'+str(a[1]))
chain._ChainBase__handle_rate_limit_error=lambda *a,**k:errors.append('rate_exception')
ns['RateLimitExceededException']=type('OwnedRateLimit',(Exception,),{})
sitechain=cls('app/chain/site.py','SiteChain',['refresh_userdata','refresh_userdatas'],['ChainBase'])
sitechain._post_site_messages=lambda *a,**k:None
sitechain.post_message=lambda *a,**k:None
events=[];rows=[]
ns['eventmanager']=SimpleNamespace(send_event=lambda typ,data:events.append(data['site_id']))
ns['EventType']=SimpleNamespace(SiteRefreshed='site.refreshed')
ns['SiteOper']=lambda:SimpleNamespace(update_userdata=lambda **k:rows.append(k))
ns['global_vars']=SimpleNamespace(is_system_stopped=False)
ns['schemas']=SimpleNamespace(Response=lambda **k:k)
plugin=cls('app/plugins/sitestatistic/__init__.py','SiteStatistic',['refresh_by_domain'],[])
cases=[]
inputs=[('logged-out','nexus','<input type="password">'),('empty-page','nexus',''),('hh-missing-panel','hhanclub','<a href="logout.php">out</a>'),('module-throws','throws',''),('unsupported','unsupported',''),('mt-invalid-json','mteam','{'),('mt-null','mteam','null'),('mt-business-error','mteam','{"code":"1"}'),('mt-empty-data','mteam','{"code":"0","data":{}}'),('mt-null-data','mteam','{"code":"0","data":null}'),('mt-invalid-integer','mteam','{"code":"0","data":{"memberCount":{"uploaded":"no"}}}'),('mt-numeric-userid','mteam','{"code":"0","data":{"id":7,"username":"owned","role":"17"}}')]
for name,kind,body in inputs:
 errors.clear();events.clear();rows.clear()
 site=dict(id='owned',name='owned',domain='https://owned.example',url='https://owned.example',schema=kind,is_active=True,apikey='owned-key')
 base._get_page_content=lambda self,**k:body;mt._get_page_content=lambda self,**k:body
 class Throws(base):
  schema=SimpleNamespace(value='throws')
  def parse(self):raise ValueError('owned parse failure')
 inst=module();inst._site_schemas=[base,mt,hh,Throws]
 sc=sitechain();sc.modulemanager=SimpleNamespace(get_running_modules=lambda method:[inst])
 ns['SitesHelper']=lambda:SimpleNamespace(get_indexers=lambda:[site],get_indexer=lambda domain:site)
 result=sc.refresh_userdatas();dto=result.get('owned') if result else None
 # Plugin API invokes the same source chain a second time; capture separately.
 before=len(events);ns['SiteChain']=lambda:sc
 response=plugin.refresh_by_domain('owned.example','owned-key')
 api=response.get('data')
 for d in [api,dto.model_dump() if dto else None]:
  if d is not None:d['updated_day']='<day>'
 cases.append(dict(name=name,kind=kind,body=body,data=api,success=response['success'],events=events[:before],api_events=events[before:],module_errors=len(errors),database_rows=len(rows),api_time_is_none=api is None or api['updated_time'] is None))
 ns['SiteChain']=sitechain
print(json.dumps(dict(source_sha256=sources,scope='installed module/chain/API methods; network and persistence are isolated stubs, no live plugin execution',cases=cases),ensure_ascii=False,separators=(',',':')))
