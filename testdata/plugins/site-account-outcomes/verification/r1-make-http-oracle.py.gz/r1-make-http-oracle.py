"""Read-only ASGI reference. No original application module is imported."""
import ast,hashlib,json,warnings
from pathlib import Path
from types import SimpleNamespace
from typing import Annotated,Optional,Any,Union,Dict,List
from fastapi import FastAPI,Depends,Security,HTTPException,status
from fastapi.security import APIKeyHeader,APIKeyQuery
from fastapi.testclient import TestClient
from pydantic import BaseModel,Field,model_validator,ConfigDict
warnings.filterwarnings('ignore')
sources={
 'security':Path('/app/app/core/security.py'),
 'response':Path('/app/app/schemas/response.py'),
 'userdata':Path('/app/app/schemas/site.py'),
 'plugin':Path('/app/app/plugins/sitestatistic/__init__.py'),
}
trees={key:ast.parse(path.read_text()) for key,path in sources.items()}
token='synthetic-api-reference-key-2026'
ns=dict(Annotated=Annotated,Optional=Optional,Any=Any,Union=Union,Dict=Dict,List=List,
 BaseModel=BaseModel,Field=Field,model_validator=model_validator,ConfigDict=ConfigDict,
 Security=Security,HTTPException=HTTPException,status=status,settings=SimpleNamespace(API_TOKEN=token),
 api_key_header=APIKeyHeader(name='X-API-KEY',auto_error=False),
 api_key_query=APIKeyQuery(name='apikey',auto_error=False),
 LocaleHelper=SimpleNamespace(get_current_locale=lambda:'zh-CN',translate_text=lambda text,locale:text))
def execute(nodes):
 mod=ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]));exec(compile(mod,'<synthetic-source-reference>','exec'),ns)
for name in ('__get_api_key','__verify_key','verify_apikey'):
 execute([next(n for n in trees['security'].body if isinstance(n,ast.FunctionDef) and n.name==name)])
execute([next(n for n in trees['response'].body if isinstance(n,ast.ClassDef) and n.name=='Response')])
execute([next(n for n in trees['userdata'].body if isinstance(n,ast.ClassDef) and n.name=='SiteUserData')])
ns['schemas']=SimpleNamespace(Response=ns['Response'])
calls=[]
userdata=ns['SiteUserData'](domain='known.example',username='synthetic',userid='7',user_level='Power User',upload=2147483648,download=1073741824,ratio=2.0,seeding=0,seeding_size=0,updated_day='2026-10-16')
class Chain:
 def refresh_userdata(self,site):calls.append(site['domain']);return None if site['domain']=='failed.example' else userdata
ns['SiteChain']=Chain
ns['SitesHelper']=lambda:SimpleNamespace(get_indexer=lambda domain:{'domain':domain} if domain in ('known.example','failed.example') else None)
cls=next(n for n in trees['plugin'].body if isinstance(n,ast.ClassDef))
fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='refresh_by_domain');fn.decorator_list=[];execute([fn])
getapi=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='get_api');execute([getapi])
declarations=ns['get_api'](SimpleNamespace(refresh_by_domain=ns['refresh_by_domain']))
app=FastAPI(docs_url=None,openapi_url=None)
for version in ('v1','v2'):
 for declaration in declarations:
  app.add_api_route('/api/'+version+'/plugin/SiteStatistic'+declaration['path'],declaration['endpoint'],methods=declaration['methods'],dependencies=[Depends(ns['verify_apikey'])])
cases=[]
def case(name,query='',headers=None,method='GET',endpoint='/refresh_by_domain',body=None,version='v1'):
 before=len(calls)
 with TestClient(app) as client:
  response=client.request(method,'/api/'+version+'/plugin/SiteStatistic'+endpoint+query,headers=headers or {},content=body)
 cases.append(dict(name=name,query=query,headers=headers or {},method=method,endpoint=endpoint,body=body,version=version,status=response.status_code,allow=response.headers.get('allow'),result=response.json() if response.content else None,collections=len(calls)-before))
good=token;bad='synthetic-wrong-key'
case('no-credentials','?domain=known.example')
case('no-parameters')
case('valid-query','?domain=known.example&apikey='+good)
case('valid-query-v2','?domain=known.example&apikey='+good,version='v2')
case('header-only-missing-query-key','?domain=known.example',{'X-API-KEY':good})
case('header-valid-query-key-wrong','?domain=known.example&apikey='+bad,{'X-API-KEY':good})
case('header-valid-query-key-empty','?domain=known.example&apikey=',{'X-API-KEY':good})
case('wrong-header-wins-valid-query','?domain=known.example&apikey='+good,{'X-API-KEY':bad})
case('empty-header-falls-back','?domain=known.example&apikey='+good,{'X-API-KEY':''})
case('missing-domain','?apikey='+good)
case('empty-domain','?domain=&apikey='+good)
case('unknown-domain','?domain=unknown.example&apikey='+good)
case('failed-domain','?domain=failed.example&apikey='+good)
case('duplicate-domain-last','?domain=unknown.example&domain=known.example&apikey='+good)
case('duplicate-domain-last-unknown','?domain=known.example&domain=unknown.example&apikey='+good)
case('duplicate-query-key-last-valid','?domain=known.example&apikey='+bad+'&apikey='+good)
case('duplicate-query-key-last-wrong','?domain=known.example&apikey='+good+'&apikey='+bad)
case('cookie-is-not-api-key','?domain=known.example',{'Cookie':'lm_session=synthetic-cookie'})
case('bearer-is-not-api-key','?domain=known.example',{'Authorization':'Bearer '+good})
case('token-alias-is-not-api-key','?domain=known.example&token='+good)
case('ignored-get-body','?domain=known.example&apikey='+good,body='not-json')
case('post-not-registered','?domain=known.example&apikey='+good,method='POST')
case('head-not-registered','?domain=known.example&apikey='+good,method='HEAD')
case('unknown-path','?domain=known.example&apikey='+good,endpoint='/unknown')
print(json.dumps(dict(source_sha256={key:hashlib.sha256(path.read_bytes()).hexdigest() for key,path in sources.items()},cases=cases),ensure_ascii=False,separators=(',',':')))
