import hashlib,json,pathlib,sqlite3,sys
counts=dict(writes=0,network=0,process=0)
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo'):raise RuntimeError('network_denied')
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('process_denied')
 if event=='open' and (isinstance(args[1],str) and any(c in args[1] for c in 'wax+') or isinstance(args[2],int) and args[2]&(1|2|64|512)):raise RuntimeError('write_denied')
sys.addaudithook(audit)
sha=lambda b:hashlib.sha256(b).hexdigest()

profiles=[]
with sqlite3.connect('file:/config/user.db?mode=ro',uri=True) as db:
 db.execute('pragma query_only=ON');db.execute('begin')
 installed=json.loads(db.execute('select value from systemconfig where key=?',('UserInstalledPlugins',)).fetchone()[0])
 services=json.loads(db.execute('select value from systemconfig where key=?',('Downloaders',)).fetchone()[0])
 for name,expected in [('TorrentTransfer','e5f513a57cf42ee8778744ba30cf669f93a5a3e6c7589ca0b2e3b9c483651bd5'),('TorrentTransfermusic','4d271e68aa3fc994c1d50cd850d4b1e5699c9f7900eaa106082b9f13efe4c5bb')]:
  assert installed.count(name)==1
  code=pathlib.Path('/app/app/plugins/'+name.lower()+'/__init__.py').read_bytes();assert sha(code)==expected
  assert not pathlib.Path('/config/plugins',name).exists()
  config=db.execute('select value from systemconfig where key=?',('plugin.'+name,)).fetchone()[0];cfg=json.loads(config);ds=[]
  for ref in ['fromdownloader','todownloader']:
   matches=[x for x in services if x.get('name')==cfg[ref]];assert len(matches)==1 and matches[0]['enabled'];s=matches[0];c=s['config'];ds.append(dict(name=s['name'],kind=s['type'],host=c['host'],username=c['username'],password=c['password'],enabled=True))
  profiles.append(dict(version=1,source_container='cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a',plugin_id=name,source_sha256=sha(code),installed_count=1,config=config,data=dict(db.execute('select key,value from plugindata where plugin_id=?',(name,))),downloaders=ds,file_count=0,symlink_count=0))
 print(json.dumps(profiles))
