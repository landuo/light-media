import base64, hashlib, json, os, pathlib, re, shlex, subprocess, time, urllib.parse, uuid

stage = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/Users/accidia/projects/light-media')
label = 'transfer-reviewed-' + uuid.uuid4().hex
name = 'light-media-' + label
directory = '/vol2/1000/docker/light-media/owned-tests/' + label
image = 'sha256:c83674e1999044d33d751661371b873539f47e5b5c5ca3320c7e0377acca6238'
report = dict(state='preflight', scope='actual reviewed TorrentTransfer + music data and Go SDK in one owned Linux container', private_payload_saved=False, network='none', cpu_limit=1, memory_limit=536870912, created_container=name, runtime_directory=directory, runs=[])

def save():
    (stage / 'nas-verification.json').write_text(json.dumps(report, indent=2) + '\n')

def ssh(command, data=None, timeout=45):
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', 'admin@192.168.8.129', command], input=data, capture_output=True, timeout=timeout)

def remote(code):
    p = ssh('python3 -', code.encode())
    if p.returncode:
        raise RuntimeError('bounded_remote_inspection_failed_' + str(p.returncode))
    return json.loads(p.stdout)

prefix = '''import pathlib,subprocess,json,os,shutil,hashlib
def docker(*args):return subprocess.check_output(['sudo','-n','docker',*args],timeout=25)
def identity(name):
 x=json.loads(docker('inspect',name))[0]
 return dict(id=x['Id'],pid=x['State']['Pid'],started=x['State']['StartedAt'],restarts=x['RestartCount'],running=x['State']['Running'])
b=pathlib.Path('/vol2/1000/docker/light-media')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
'''

made = created = False
started_at = time.monotonic()
try:
    report['before'] = remote(prefix + '''
assert os.getuid()==1000 and os.getgid()==1001
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=3*1024**3
assert os.getloadavg()[0]<5 and shutil.disk_usage(b).free>=2*1024**3
assert sha(b/'light-media-server')=='4e14738c14a243767389d754dd7220ab4ee199b057731160fa4986e9c32c047b'
assert sha(b/'compose.yaml')=='1d528665848dc02c3452a7254645dea519f35cf06f8a67da057ebde6a9ddff39'
print(json.dumps({n:identity(n) for n in ['light-media','moviepilot','qb']}))
''')
    remote(prefix + 'p=pathlib.Path(' + repr(directory) + ');assert not p.exists();p.mkdir(mode=0o700,parents=True);os.chmod(p,0o700);print("{}")\n')
    made = True
    binaries = {}
    for source_name, target_name in [('app-linux.test', 'app.test'), ('transfer-migrate-linux', 'transfer-migrate')]:
        raw = (stage / source_name).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        code = "import pathlib,sys,hashlib,os\np=pathlib.Path(%r);raw=sys.stdin.buffer.read();assert hashlib.sha256(raw).hexdigest()==%r\nfd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o700);os.fchmod(fd,0o700)\nwith os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())\n" % (directory + '/' + target_name, digest)
        p = ssh(shlex.join(['python3', '-c', code]), raw)
        if p.returncode:
            raise RuntimeError('owned_binary_stage_failed')
        binaries[target_name] = digest
    report['binaries'] = binaries
    args = ['sudo', '-n', 'docker', 'create', '--name', name, '--label', 'light-media.owned-test=' + label, '--interactive', '--log-driver', 'none', '--read-only', '--network', 'none', '--cpus', '1', '--memory', '512m', '--pids-limit', '128', '--user', '1000:1001', '--mount', 'type=bind,src=' + directory + ',dst=/verify,readonly', '--tmpfs', '/tmp:rw,size=256m,mode=1777', '--env', 'LIGHT_MEDIA_REVIEWED_TRANSFER=owned-selected-stdin', '--env', 'LIGHT_MEDIA_REVIEWED_TRANSFER_CLI=/verify/transfer-migrate', '--entrypoint', '/verify/app.test', image, '-test.run=^TestReviewedTransferSelectedStdin$', '-test.v', '-test.timeout=600s']
    p = ssh(shlex.join(args))
    if p.returncode:
        raise RuntimeError('owned_container_create_failed')
    created = True
    report['container_id'] = p.stdout.decode().strip()
    report['state'] = 'running_owned_selected_source'
    save()
    print(json.dumps({'state': report['state'], 'network': 'none', 'cpu_limit': 1, 'memory_limit': 536870912}), flush=True)
    p = ssh('sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -', (repo / 'work/_torrent_transfer_migration_review/emit-reviewed-private-stdin.py').read_bytes())
    if p.returncode:
        raise RuntimeError('readonly_source_capture_failed')
    source = p.stdout
    selected = json.loads(source)
    secrets = {d['password'] for profile in selected for d in profile['downloaders'] if d.get('password')}
    def walk(v, key=''):
        if isinstance(v, dict):
            for k, child in v.items(): walk(child, k.lower())
        elif isinstance(v, list):
            for child in v: walk(child, key)
        elif isinstance(v, str):
            if key in ['token','password','cookie','apikey','passkey','rsskey'] and len(v)>=6: secrets.add(v)
            if v.startswith(('https://','http://')):
                for k, values in urllib.parse.parse_qs(urllib.parse.urlsplit(v).query).items():
                    if any(part in k.lower() for part in ['passkey','token','key','auth']): secrets.update(x for x in values if len(x)>=6)
    for profile in selected:
        walk(json.loads(profile['config']))
        for v in profile['data'].values(): walk(json.loads(v))
    variants = {w.encode() for v in secrets for w in [v, urllib.parse.quote(v, safe=''), base64.b64encode(v.encode()).decode()] if w}
    p = ssh(shlex.join(['sudo','-n','docker','start','-a','-i',name]), source, timeout=620)
    log = p.stdout + p.stderr
    if any(v in log for v in variants):
        raise RuntimeError('private_material_detected_no_log_saved')
    (stage / 'nas-selected.log').write_bytes(log)
    report['runs'].append(dict(exit=p.returncode, passed=p.returncode==0 and bool(re.search(rb'^--- PASS: TestReviewedTransferSelectedStdin \(',p.stdout,re.M)), source_secret_scan_passed=True, log_sha256=hashlib.sha256(log).hexdigest()))
    report['execution'] = remote(prefix + 'x=json.loads(docker("inspect",' + repr(name) + '))[0];print(json.dumps({"exit_code":x["State"]["ExitCode"],"oom_killed":x["State"]["OOMKilled"],"running":x["State"]["Running"],"network":x["HostConfig"]["NetworkMode"],"cpu_limit":x["HostConfig"]["NanoCpus"],"memory_limit":x["HostConfig"]["Memory"]}))\n')
    assert report['runs'][-1]['passed'] and report['execution']['exit_code']==0 and not report['execution']['oom_killed'] and not report['execution']['running']
    report['state'] = 'passed_owned_linux_business'
except BaseException as e:
    report['state'] = 'failed'
    report['error_class'] = type(e).__name__
    raise
finally:
    if created:
        cleanup = remote(prefix + 'name=' + repr(name) + ';x=json.loads(docker("inspect",name))[0];assert x["Config"]["Labels"]["light-media.owned-test"]==' + repr(label) + ';assert x["Image"]==' + repr(image) + '\nif x["State"]["Running"]:docker("stop","-t","5",name)\ndocker("rm",name);print(json.dumps({"owned_container_removed":True}))\n')
        report.update(cleanup)
    if made:
        report.update(remote(prefix + 'p=pathlib.Path(' + repr(directory) + ');assert p.is_dir() and not p.is_symlink()\nfor f in p.iterdir():\n assert f.name in ["app.test","transfer-migrate"] and f.is_file() and not f.is_symlink();f.unlink()\np.rmdir();assert not p.exists();print(json.dumps({"owned_runtime_directory_removed":True}))\n'))
    report['after'] = remote(prefix + 'print(json.dumps({n:identity(n) for n in ["light-media","moviepilot","qb"]}))\n')
    report['original_and_production_containers_unchanged'] = report.get('before')==report['after']
    report['elapsed_seconds'] = round(time.monotonic()-started_at, 2)
    save()
    print(json.dumps({'state':report['state'],'cleanup':bool(report.get('owned_container_removed') and report.get('owned_runtime_directory_removed')),'original_and_production_containers_unchanged':report['original_and_production_containers_unchanged']}), flush=True)
