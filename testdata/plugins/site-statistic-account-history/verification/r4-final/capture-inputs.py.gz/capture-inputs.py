import pathlib,subprocess,json,os,hashlib
stage=pathlib.Path(__file__).resolve().parent;app=stage/'app';paths=set();modes=[]
for name,env,flags in [('native',{'CGO_ENABLED':'0'},[]),('linux',{'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'},[]),('native-race',{'CGO_ENABLED':'1'},['-race'])]:
 r=subprocess.run(['go','list',*flags,'-deps','-test','-json','./internal/app','./cmd/server','./cmd/site-statistic-migrate-owned','./cmd/plugin-handoff-owned'],cwd=app,env=dict(os.environ,**env),capture_output=True,check=True)
 s=r.stdout.decode();pos=0;decoder=json.JSONDecoder();count=0
 while pos<len(s):
  while pos<len(s) and s[pos].isspace():pos+=1
  if pos==len(s):break
  v,pos=decoder.raw_decode(s,pos);d=v.get('Dir');count+=1
  if not d:continue
  for key in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles']:
   for n in v.get(key,[]):
    q=pathlib.Path(d)/n
    if q.is_file():paths.add(q)
  if isinstance(v.get('Module'),dict) and v['Module'].get('GoMod'):
   q=pathlib.Path(v['Module']['GoMod'])
   if q.is_file():paths.add(q)
 modes.append({'mode':name,'packages':count,'exit':0})
paths.update([app/'go.mod',app/'go.sum']);rows=[]
for q in sorted(paths):
 try:n='repo/'+str(q.relative_to(app))
 except ValueError:n=str(q)
 rows.append({'path':n,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()})
(stage/'COMPILATION-INPUTS.json').write_text(json.dumps(rows,indent=2)+'\n');(stage/'COMPILATION-MODES.json').write_text(json.dumps({'runs':modes,'boundary':'resolved Go/module/embedded/C/assembly inputs; does not claim complete compiler system header or linker dependency closure'},indent=2)+'\n');print(json.dumps({'resolved_inputs':len(rows),'modes':modes}))
