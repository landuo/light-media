import base64,hashlib,json,pathlib,shlex,subprocess,time,uuid
r=pathlib.Path(__file__).resolve().parent
base='/vol2/1000/docker/light-media';release=base+'/releases/plugin-v047-media-refresh-'+uuid.uuid4().hex[:8]
old='f1763c0c477cb5004bf3fd44b4c61d073cdd3f8dfe743cb9194c22e702e27204';new='2cb875b05e16e1e98a1ef2b2b88e47b4156b28adb05c52b1eb4c4d04b8c27b6e';toolsha='813432918c113203325d84fe24baeac9889cd1969f4cfb1fcd33286ec8f6f5fa';composeSHA='1d528665848dc02c3452a7254645dea519f35cf06f8a67da057ebde6a9ddff39'
prefix=(r/'remote-prefix.py.txt').read_text()+"\nrelease=pathlib.Path("+repr(release)+")\n"
prefix+='''
media_snapshot=snapshot
def snapshot(immutable=False):
 out=media_snapshot(immutable)
 db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro'+('&immutable=1' if immutable else ''),uri=True);db.execute('pragma query_only=ON')
 out['notice_preferences']=[(x[0],x[1],hashlib.sha256(x[2]).hexdigest()) for x in db.execute('select kind,token,sealed from plugin_notice_preferences order by kind,token')]
 out['receipt_digests']=[(x[0],x[1],x[2],x[3]) for x in db.execute('select source_fingerprint,source_plugin_id,instance_id,digest from plugin_migration_receipts order by source_plugin_id,instance_id')]
 if out['media_refresh']['events']:
  out['media_subscription']=db.execute("select handler_key,generation,config_revision,event_types,delay_ms,active,cursor from plugin_event_subscriptions where instance_id='MediaServerRefresh'").fetchall()
 db.close();return out
'''
def ssh(command,data=None,timeout=55):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129',command],input=data,capture_output=True,timeout=timeout)
 if p.returncode:raise RuntimeError('bounded_remote_exit_'+str(p.returncode))
 return p.stdout
def remote(code):return json.loads(ssh('python3 -',(prefix+code).encode()))
def source():return ssh('sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -',(r/'emit-reviewed-source.py').read_bytes())
def write(path,data):
 code="import hashlib,os,pathlib,sys\np=pathlib.Path(%r);raw=sys.stdin.buffer.read();assert hashlib.sha256(raw).hexdigest()==%r\nfd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o700);os.fchmod(fd,0o700)\nwith os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())\n"%(path,hashlib.sha256(data).hexdigest())
 ssh(shlex.join(['python3','-c',code]),data)
obs={'directory_file','directory_status','directory_file_state'}
allowed_new={('core_settings_lifecycle','notifications/v1'),('plugin_media_reference_mapping','MediaServerRefresh')}
def compare(a,c,imported=False,restart=False):
 for k in ['key_sha256','category_sha256','p0_jobs','domain_high_water']:assert a[k]==c[k],k
 before={(x[0],x[1]):x[2] for x in a['records'] if x[0] not in obs};after={(x[0],x[1]):x[2] for x in c['records'] if x[0] not in obs};assert all(after.get(k)==v for k,v in before.items()),'protected_records_changed';assert set(after)-set(before)<=allowed_new,'unexpected_new_record'
 for k in ['plugin_values','installations']:
  keep=lambda x:(not imported or x[0]!='MediaServerRefresh') and (not restart or k!='plugin_values' or x[0]!='CustomHosts' or x[1]!='config')
  assert [x for x in a[k] if keep(x)]==[x for x in c[k] if keep(x)],k
 for row in a['notice_preferences']:assert row in c['notice_preferences'],'notice_preference_changed'
 for row in a['receipt_digests']:assert row in c['receipt_digests'],'old_receipt_changed'
 for field in ['system_process','server_status','custom_hosts']:
  expected=dict(a[field])
  if restart:expected['runs']+=1;expected['succeeded_runs' if field=='system_process' else 'success']+=1
  assert c[field]==expected,field
def custom_config_digest():
 actual=remote("import base64\ndb=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro',uri=True);db.execute('pragma query_only=ON');sealed=db.execute(\"select sealed from plugin_values where instance_id='CustomHosts' and kind='config' and item_key='main'\").fetchone()[0];db.close();print(json.dumps(dict(key=base64.b64encode((b/'data/secret.key').read_bytes()).decode(),sealed=base64.b64encode(sealed).decode())))\n")
 code="const c=require('node:crypto');let raw='';process.stdin.on('data',x=>raw+=x);process.stdin.on('end',()=>{try{const x=JSON.parse(raw),s=Buffer.from(x.sealed,'base64'),d=c.createDecipheriv('aes-256-gcm',Buffer.from(x.key,'base64'),s.subarray(0,12));d.setAAD(Buffer.from(JSON.stringify(['light-media/plugins/v1','config','CustomHosts','main'])));d.setAuthTag(s.subarray(-16));const value=JSON.parse(Buffer.concat([d.update(s.subarray(12,-16)),d.final()]).toString()),canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;process.stdout.write(c.createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex'));}catch{process.exitCode=1}});"
 node=subprocess.run(['node','-e',code],input=json.dumps(actual).encode(),capture_output=True,timeout=10);assert node.returncode==0 and len(node.stdout)==64;return node.stdout.decode()
report=dict(state='preflight',release=release,version='0.4.7',server_sha256=new,tool_sha256=toolsha,actual_complete=6,remaining=17)
def save(): (r/'deployment-result.json').write_text(json.dumps(report,indent=2)+'\n')
stopped=swapped=exposed=False
try:
 assert json.loads((r/'cli-owned-verification.json').read_text())['state']=='passed'
 before=remote('''
assert sha(b/'light-media-server')==%r and sha(b/'compose.yaml')==%r
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=3) as response:assert json.load(response)['data']['version']=='0.4.6'
assert not release.exists() and os.getuid()==1000 and os.getgid()==1001
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=3*1024**3 and os.getloadavg()[0]<5 and shutil.disk_usage(b).free>=1024**3
out=snapshot();assert out['active_work']==0 and out['migration_receipts']==6 and sum(out['media_refresh'].values())==0
out['originals']={n:identity(n) for n in ['moviepilot','qb']};out['original_hosts_sha256']=docker('exec','moviepilot','sha256sum','/etc/hosts').decode().split()[0];out['owned_hosts_sha256']=sha(b/'container-hosts');out['target_before']=identity('light-media');release.mkdir(mode=0o700);print(json.dumps(out))
'''%(old,composeSHA));report['before']=before;report['custom_hosts_semantic_before']=custom_config_digest();save()
 for local,name,digest in [('light-media-linux-owned','light-media-server',new),('media-refresh-migrate-linux-owned','media-refresh-migrate-owned',toolsha)]:
  data=(r/local).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;write(release+'/'+name,data)
 payload=source();assert json.loads(payload)==json.loads(source());tool=release+'/media-refresh-migrate-owned';assert json.loads(ssh(shlex.join([tool,'--validate']),payload))['writes']==0
 report['state']='staged_validated_before_outage';save();print(report['state'],flush=True)
 ssh('sudo -n docker stop -t 30 light-media');stopped=True
 frozen=remote('''
assert not identity('light-media')['running'];lock=open(b/'data/instance.lock','rb');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
out=snapshot(True);assert out['active_work']==0
for suffix in ['-wal','-journal']:
 p=b/('data/light-media.db'+suffix);assert not p.exists() or p.is_file() and p.stat().st_size==0
db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro&immutable=1',uri=True);backup=sqlite3.connect(str(release/'rollback-light-media.db'));db.backup(backup);assert backup.execute('pragma quick_check').fetchone()[0]=='ok';backup.close();db.close();os.chmod(release/'rollback-light-media.db',0o600)
shutil.copy2(b/'light-media-server',release/'rollback-light-media-server');assert sha(release/'rollback-light-media-server')==%r
lock.close();print(json.dumps(out))
'''%old);compare(before,frozen);assert json.loads(payload)==json.loads(source())
 remote('''
assert not identity('light-media')['running'] and sha(b/'light-media-server')==%r and sha(release/'light-media-server')==%r
p=b/'light-media-server.v047.new';assert not p.exists();shutil.copy2(release/'light-media-server',p);os.chmod(p,0o755);os.replace(p,b/'light-media-server');print('{}')
'''%(old,new));swapped=True
 args=[tool,'--target-data-dir',base+'/data'];assert json.loads(ssh(shlex.join(args),payload))['writes']==0
 imported=json.loads(ssh(shlex.join(args+['--apply']),payload));assert imported['state']=='imported' and imported['desired_enabled'] and imported['media_reference_mappings']==1 and not imported['executed'] and not imported['scheduled']
 replay=json.loads(ssh(shlex.join(args+['--apply']),payload));assert replay['receipt']==imported['receipt'] and replay['replayed']
 preserved=remote("print(json.dumps(snapshot(True)))\n");compare(frozen,preserved,imported=True)
 init=dict(installation=1,config=1,runs=0,success=0,active=0,other=0,data=0,schedules=0,events=0,mapping=1);assert preserved['media_refresh']==init and preserved['migration_receipts']==7
 report.update(state='import_committed_target_stopped',import_result=imported,preserved=preserved);save();print(report['state'],flush=True)
 exposed=True;ssh('sudo -n docker compose -f /vol2/1000/docker/light-media/compose.yaml up -d --force-recreate --no-deps light-media');stopped=False
 after=None
 for _ in range(24):
  try:
   after=remote('''
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=2) as response:assert json.load(response)['data']['version']=='0.4.7'
assert sha(b/'light-media-server')==%r and docker('exec','light-media','sha256sum','/app/light-media-server').decode().split()[0]==%r and sha(b/'compose.yaml')==%r
out=snapshot();out['originals']={n:identity(n) for n in ['moviepilot','qb']};out['original_hosts_sha256']=docker('exec','moviepilot','sha256sum','/etc/hosts').decode().split()[0];out['target']=identity('light-media');out['owned_hosts_sha256']=sha(b/'container-hosts');print(json.dumps(out))
'''%(new,new,composeSHA))
   if after['media_refresh']=={**init,'runs':1,'success':1,'events':1} and after['active_work']==0:break
  except RuntimeError:pass
  time.sleep(.25)
 assert after is not None;compare(preserved,after,imported=True,restart=True);assert after['media_refresh']=={**init,'runs':1,'success':1,'events':1} and after['migration_receipts']==7 and after['active_work']==0
 assert custom_config_digest()==report['custom_hosts_semantic_before'],'custom_hosts_restart_semantics_changed'
 assert after['originals']==before['originals'] and after['original_hosts_sha256']==before['original_hosts_sha256'] and after['owned_hosts_sha256']==before['owned_hosts_sha256']
 assert len(after['media_subscription'])==1 and after['media_subscription'][0][3]=='["import.completed"]' and after['media_subscription'][0][5]==1 and after['media_subscription'][0][6]==after['domain_high_water']
 actual=remote('''
import base64
db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro',uri=True);config=db.execute("select sealed from plugin_values where instance_id='MediaServerRefresh' and kind='config' and item_key='main'").fetchone()[0];mapping=db.execute("select payload from records where kind='plugin_media_reference_mapping' and id='MediaServerRefresh'").fetchone()[0];db.close();print(json.dumps(dict(key=base64.b64encode((b/'data/secret.key').read_bytes()).decode(),config=base64.b64encode(config).decode(),mapping=base64.b64encode(mapping).decode())))
''')
 checkcode="""const c=require('node:crypto');let raw='';process.stdin.on('data',x=>raw+=x);process.stdin.on('end',()=>{try{const x=JSON.parse(raw),key=Buffer.from(x.actual.key,'base64'),decode=(v,kind)=>{const s=Buffer.from(v,'base64'),d=c.createDecipheriv('aes-256-gcm',key,s.subarray(0,12));d.setAAD(Buffer.from(JSON.stringify(['light-media/plugins/v1',kind,'MediaServerRefresh','main'])));d.setAuthTag(s.subarray(-16));return JSON.parse(Buffer.concat([d.update(s.subarray(12,-16)),d.final()]).toString())},config=decode(x.actual.config,'config'),mapping=decode(x.actual.mapping,'plugin_media_reference_mapping'),source=JSON.parse(x.source.config);if(config.enabled!==source.enabled||config.delay!==source.delay||JSON.stringify(config.mediaservers)!=='["fnos"]'||mapping.Target!=='fnos'||mapping.SourceConfigSHA!=='a9611ac9dcd35f975281a8adf02ca924a6f06410c6de53e5ba2644f48a7f1030')throw 0;process.stdout.write(JSON.stringify({source_fields_and_reference_verified:true}));}catch{process.exitCode=1}});"""
 node=subprocess.run(['node','-e',checkcode],input=json.dumps(dict(actual=actual,source=json.loads(payload))).encode(),capture_output=True,timeout=10);assert node.returncode==0 and json.loads(node.stdout)['source_fields_and_reference_verified'];assert json.loads(payload)==json.loads(source())
 report.update(state='cold_runtime_verified_pending_production_ui',after=after,candidate_complete_after_ui=7,original_services_and_hosts_unchanged=True,existing_configuration_and_preferences_preserved=True,source_fields_and_reference_verified=True,private_source_values_saved=False);save();print(json.dumps({k:report[k] for k in ['state','version','candidate_complete_after_ui']}))
except BaseException as e:
 report.update(state='failed',error_class=type(e).__name__,exposed=exposed);save()
 if stopped and not exposed:
  if swapped:
   remote('''
assert not identity('light-media')['running'] and sha(release/'rollback-light-media-server')==%r
p=b/'light-media-server.v047.rollback';assert not p.exists();shutil.copy2(release/'rollback-light-media-server',p);os.replace(p,b/'light-media-server')
src=sqlite3.connect('file:'+str(release/'rollback-light-media.db')+'?mode=ro&immutable=1',uri=True);dst=sqlite3.connect(str(b/'data/light-media.db'));src.backup(dst);assert dst.execute('pragma quick_check').fetchone()[0]=='ok';src.close();dst.close();print('{}')
'''%old)
  ssh('sudo -n docker start light-media')
 raise
