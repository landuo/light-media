import fcntl,hashlib,json,pathlib,subprocess,tempfile
r=pathlib.Path(__file__).resolve().parent
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(r/'emit-reviewed-source.py').read_bytes(),capture_output=True,timeout=20);assert p.returncode==0,'source_read_failed';payload=p.stdout
results=[]
def call(args,data=payload,expected=0):
 p=subprocess.run(args,input=data,capture_output=True,timeout=25);assert p.returncode==expected,'owned_cli_unexpected_exit';return json.loads(p.stdout) if expected==0 else dict(exit=p.returncode,error=p.stderr.decode().strip())
def files(d):return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
with tempfile.TemporaryDirectory(prefix='light-media-owned-media-cli-') as temp:
 d=pathlib.Path(temp)/'data';helper=lambda mode:call([str(r/'owned-cli-fixture'),'--dir',str(d),'--mode',mode]);helper('seed');args=[str(r/'media-refresh-migrate-owned'),'--target-data-dir',str(d)];before=files(d);dry=call(args);assert dry['writes']==0 and files(d)==before
 with open(d/'instance.lock','rb') as f:
  fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB);busy=call(args+['--apply'],expected=1);assert busy['error']=='target_application_is_running';fcntl.flock(f.fileno(),fcntl.LOCK_UN)
 assert files(d)==before
 result=call(args+['--apply']);assert result['state']=='imported' and result['desired_enabled'] and not result['executed'] and not result['scheduled'] and result['media_reference_mappings']==1
 current=helper('audit');assert current['config_sha256']=='25f28d91ef8c590fc30f1d232e6ee4f99a006d0bf5977e4e30b3df6e82eaaaa1' and current['counts']==dict(receipts=1,runs=0,schedules=0,events=0,mapping=1,installed=1)
 edited=helper('edit');replay=call(args+['--apply']);assert replay['receipt']==result['receipt'] and replay['replayed'];after=helper('audit');assert after['config_sha256']==edited['config_sha256'] and after['revision']==edited['revision'] and after['counts']==current['counts']
 invalid=json.loads(payload);invalid['source_sha256']='0'*64;before=files(d);refused=call(args+['--apply'],json.dumps(invalid).encode(),1);assert refused['error']=='invalid_reviewed_source_snapshot' and files(d)==before
 out=dict(state='passed',read_only_dry_run=True,live_store_lock_refused=True,atomic_apply=True,one_reference_mapping=True,no_workers_or_events_created=True,receipt_replay_preserves_user_edit=True,invalid_input_zero_writes=True,private_source_saved=False,network_business_calls=0,production_writes=0,cleanup='owned temporary directory removed after verification')
assert not d.exists();(r/'cli-owned-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
