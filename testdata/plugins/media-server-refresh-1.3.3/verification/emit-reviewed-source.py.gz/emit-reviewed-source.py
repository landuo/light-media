import hashlib,json,pathlib,sqlite3,sys,urllib.parse
counts=dict(network=0,writes=0,process=0)
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo'):counts['network']+=1;raise RuntimeError('network_denied')
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):counts['process']+=1;raise RuntimeError('process_denied')
 if event=='open' and (isinstance(args[1],str) and any(c in args[1] for c in 'wax+') or isinstance(args[2],int) and args[2]&(1|2|64|512)):counts['writes']+=1;raise RuntimeError('write_denied')
sys.addaudithook(audit)
p=pathlib.Path('/app/app/plugins/mediaserverrefresh/__init__.py');code=p.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(code)=='ea92f39a852aa0333cb625885e0fbf7b2a679f4f7449463bb6126afe6694a3fc'
with sqlite3.connect('file:/config/user.db?mode=ro',uri=True) as db:
 db.execute('pragma query_only=ON');db.execute('begin')
 raw=db.execute('select value from systemconfig where key=?',('plugin.MediaServerRefresh',)).fetchone()[0];assert sha(raw.encode())=='a9611ac9dcd35f975281a8adf02ca924a6f06410c6de53e5ba2644f48a7f1030';config=json.loads(raw)
 installed=json.loads(db.execute('select value from systemconfig where key=?',('UserInstalledPlugins',)).fetchone()[0]);assert installed.count('MediaServerRefresh')==1
 servers=json.loads(db.execute('select value from systemconfig where key=?',('MediaServers',)).fetchone()[0]);selected=[s for s in servers if isinstance(s,dict) and s.get('name') in config['mediaservers']];assert len(selected)==1;service=selected[0];assert service['type']=='trimemedia' and service['enabled'] is True
 assert sha(service['name'].encode())=='f879612a3abfb31c7c40e68b30c1ab87b3858fd7ed075059dc4129e911fa795b'
 kv=db.execute('select count(*) from plugindata where plugin_id=?',('MediaServerRefresh',)).fetchone()[0];assert kv==0 and not pathlib.Path('/config/plugins/MediaServerRefresh').exists()
 ref=dict(name=service['name'],kind=service['type'],enabled=service['enabled'],host=service['config']['host'],username=service['config']['username'])
 assert counts==dict(network=0,writes=0,process=0)
 print(json.dumps(dict(version=1,source_container='cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a',source_sha256=sha(code),config=raw,installed_count=1,kv_count=0,file_count=0,symlink_count=0,reference=ref),ensure_ascii=False,sort_keys=True,separators=(',',':')))
