import hashlib,json,os,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parent
sources=[('MediaServerRefresh',r/'emit-reviewed-source.py','TestReviewedMediaRefreshSelectedStdin','LIGHT_MEDIA_REVIEWED_MEDIA_REFRESH','selected_source_media_refresh_mapping_atomic_aead_cold_replay_and_rollback_verified'),('CustomHosts',r.parent/'_custom_hosts_formal_v046_r2/emit-source-selected.py','TestReviewedCustomHostsSelectedStdin','LIGHT_MEDIA_REVIEWED_CUSTOM_HOSTS','selected_source_atomic_aead_cold_replay_user_edit_and_rollback_verified')]
def capture(p):
 q=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=p.read_bytes(),capture_output=True,timeout=20)
 assert q.returncode==0,'selected_source_capture_failed'
 return q.stdout
results=[]
for plugin,source,test,env,marker in sources:
 payload=capture(source);assert json.loads(payload)==json.loads(capture(source))
 for exe in ['app-selected-owned.test','app-selected-owned-race.test']:
  p=subprocess.run([str(r/exe),'-test.run=^'+test+'$','-test.v','-test.timeout=60s'],input=payload,env={**os.environ,env:'owned-selected-stdin'},capture_output=True,timeout=65)
  (r/(plugin+'-'+exe+'.log')).write_bytes(p.stdout+p.stderr)
  assert p.returncode==0 and marker.encode() in p.stdout,'selected_'+plugin+'_'+exe+'_failed'
  results.append(dict(plugin=plugin,mode=exe,exit=0,binary_sha256=hashlib.sha256((r/exe).read_bytes()).hexdigest()))
 if plugin=='MediaServerRefresh':
  p=subprocess.run([str(r/'media-refresh-migrate-owned'),'--validate'],input=payload,capture_output=True,timeout=10);assert p.returncode==0 and json.loads(p.stdout)['writes']==0
out=dict(state='passed',tests=results,original_source_private_input_saved=False,source_configuration_mapping=True,connection_binding=True,atomic_rollback=True,cold_replay_preserves_user_edit=True,workers=0,network_business_calls=0,production_writes=0,cli_validate_writes=0)
(r/'selected-source-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['state','original_source_private_input_saved','source_configuration_mapping','connection_binding','atomic_rollback']}))
