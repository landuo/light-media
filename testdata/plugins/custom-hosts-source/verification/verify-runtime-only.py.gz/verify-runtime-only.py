import ast,json,pathlib,shlex,subprocess
r=pathlib.Path(__file__).resolve().parent;report=json.loads((r/'deployment-result.json').read_text())
assert report['state']=='failed' and report['exposed'] and report['import_result']['state']=='imported'
tree=ast.parse((r/'deploy-migrate.py').read_text())
prefix=(r.parent/'_server_status_formal_v045/remote-prefix.py.txt').read_text().replace('/vol2/1000/docker/light-media/releases/plugin-v045-server-status-20261021-92fe60',report['release'])
prefix+=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='prefix'))
def ssh(command,data=None):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129',command],input=data,capture_output=True,timeout=30)
 assert p.returncode==0,'bounded_readonly_remote_failed';return p.stdout
def remote(code):return json.loads(ssh('python3 -',(prefix+code).encode()))
ns={};exec(compile(ast.Module(body=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compare')],type_ignores=[]),'<readonly-comparison>','exec'),ns)
after=remote('''
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=3) as response:assert json.load(response)['data']['version']=='0.4.6'
assert sha(b/'light-media-server')==%r and docker('exec','light-media','sha256sum','/app/light-media-server').decode().split()[0]==%r
out=snapshot();out['originals']={n:identity(n) for n in ['moviepilot','qb']};out['original_hosts_sha256']=docker('exec','moviepilot','sha256sum','/etc/hosts').decode().split()[0];out['target']=identity('light-media');out['owned_hosts_sha256']=sha(b/'container-hosts');print(json.dumps(out))
'''%(report['server_sha256'],report['server_sha256']))
ns['compare'](report['preserved'],after,new_plugin=True,restart=True)
expected_counts=dict(installation=1,config=1,runs=1,success=1,active=0,other=0,data=0,schedules=0,events=0)
assert after['custom_hosts']==expected_counts and after['migration_receipts']==6 and after['active_work']==0
assert after['originals']==report['before']['originals'] and after['original_hosts_sha256']==report['before']['original_hosts_sha256']
assert after['owned_hosts_sha256']==report['expected_hosts_sha256']
hosts=ssh('sudo -n docker exec light-media cat /etc/hosts')
source_code=('import json\n_target_hosts='+repr(hosts.decode())+'\n').encode()+(r/'simulate-source-selected.py').read_bytes()
expected=json.loads(ssh('sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -',source_code))
assert expected['file_sha256']==after['owned_hosts_sha256'] and expected['actual_audit']==dict(network=0,writes=0,process=0)
actual=remote('''
import base64
db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro',uri=True);sealed=db.execute("select sealed from plugin_values where instance_id='CustomHosts' and kind='config' and item_key='main'").fetchone()[0];db.close()
x=json.loads(docker('inspect','light-media'))[0];assert x['Config']['User']=='1000:1001' and x['HostConfig']['ReadonlyRootfs'] and x['HostConfig']['NetworkMode']=='host' and x['HostConfig']['Memory']==536870912 and x['HostConfig']['NanoCpus']==1000000000
mount=next(m for m in x['Mounts'] if m['Destination']=='/etc/hosts');assert mount['Source']==str(b/'container-hosts') and mount['RW']
assert (b/'container-hosts').stat().st_uid==1000 and (b/'container-hosts').stat().st_mode&511==384
assert docker('exec','light-media','sha256sum','/etc/hosts').decode().split()[0]==sha(b/'container-hosts')
print(json.dumps(dict(key=base64.b64encode((b/'data/secret.key').read_bytes()).decode(),sealed=base64.b64encode(sealed).decode(),dedicated_mount_verified=True)))
''')
checkcode=ast.literal_eval(next(n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checkcode' for t in n.targets)))
p=subprocess.run(['node','-e',checkcode],input=json.dumps(dict(actual=actual,expected=expected['config'])).encode(),capture_output=True,timeout=10)
assert p.returncode==0 and json.loads(p.stdout)['runtime_source_config_equal']
(r/'second-deployment-observation-failure.json').write_text(json.dumps(report,indent=2)+'\n')
report.update(state='cold_runtime_verified_pending_production_ui',version='0.4.6',after=after,candidate_complete_after_ui=6,original_services_and_hosts_unchanged=True,existing_configuration_and_preferences_preserved=True,dedicated_mount_verified=True,runtime_source_config_equal=True,source_private_values_saved=False,observation_correction='PluginReload is a direct durable control queue (actual Cloudflare SDK reload test), not a generic domain-event SQL subscription; expected event rows corrected to zero without changing production.')
report.pop('error_class',None)
(r/'deployment-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['state','version','candidate_complete_after_ui','runtime_source_config_equal','dedicated_mount_verified']}))
