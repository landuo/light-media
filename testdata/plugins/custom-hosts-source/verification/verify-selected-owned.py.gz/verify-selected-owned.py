import hashlib,json,os,pathlib,subprocess
r=pathlib.Path(__file__).resolve().parent
def capture():
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(r/'emit-source-selected.py').read_bytes(),capture_output=True,timeout=20)
 assert p.returncode==0,'selected_source_capture_failed'
 return p.stdout
payload=capture(); assert json.loads(payload)==json.loads(capture())
results=[]
for exe in ['app-selected-owned.test','app-selected-owned-race.test']:
 p=subprocess.run([str(r/exe),'-test.run=^TestReviewedCustomHostsSelectedStdin$','-test.v','-test.timeout=50s'],input=payload,env={**os.environ,'LIGHT_MEDIA_REVIEWED_CUSTOM_HOSTS':'owned-selected-stdin'},capture_output=True,timeout=60)
 (r/(exe+'.log')).write_bytes(p.stdout+p.stderr)
 assert p.returncode==0 and b'selected_source_atomic_aead_cold_replay_user_edit_and_rollback_verified' in p.stdout,exe
 results.append(dict(binary=exe,exit=p.returncode,sha256=hashlib.sha256((r/exe).read_bytes()).hexdigest()))
p=subprocess.run([str(r/'custom-hosts-migrate-owned'),'--validate'],input=payload,capture_output=True,timeout=10)
assert p.returncode==0 and json.loads(p.stdout)['writes']==0
out=dict(state='passed',source_private_input_saved=False,source_private_config_sha256=hashlib.sha256(json.loads(payload)['config'].encode()).hexdigest(),selected_config_aead_and_cold_replay=True,user_edit_preserved=True,receipt_failure_rollback=True,wrong_source_rejected=True,tests=results,cli_validate=json.loads(p.stdout),workers=0,hosts_writes=0,network_business_calls=0)
(r/'selected-owned-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['state','source_private_input_saved','selected_config_aead_and_cold_replay','receipt_failure_rollback']}))
