import json,unicodedata
u=unicodedata.ucd_3_2_0
m=[];ccc=[];pairs=[]
for n in range(0x110000):
 c=chr(n);d=u.normalize('NFKD',c)
 if d!=c:m.append([n,d])
 k=unicodedata.combining(c)
 if k:ccc.append([n,k])
 d=unicodedata.decomposition(c)
 if d and not d.startswith('<'):
  p=[int(x,16) for x in d.split()]
  if len(p)==2 and u.normalize('NFC',''.join(map(chr,p)))==c:pairs.append([p[0],p[1],n])
print(json.dumps(dict(decomposition=m,combining=ccc,composition=sorted(pairs)),ensure_ascii=True,separators=(',',':')))
