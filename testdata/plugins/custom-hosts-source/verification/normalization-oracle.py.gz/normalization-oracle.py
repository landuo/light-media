import json,random,unicodedata
u=unicodedata.ucd_3_2_0;pool=list('aAeEIßΣσςİ')+[chr(x) for x in [0x300,0x301,0x315,0x327,0x1e4ec,0x1d165,0x1b06,0x20dd,0x1100,0x1161,0x11a8,0x2f868,0x1e030]]
rng=random.Random(37512);values=[''.join(rng.choice(pool) for _ in range(rng.randrange(13))) for _ in range(2048)]
values+=list(map(chr,range(0xac00,0xac00+11172)));values+=['가','각','각','a\U0001e4ec\u0301']
print(json.dumps(dict(python_unicode=unicodedata.unidata_version,normalizer_unicode=u.unidata_version,cases=[dict(input=s,output=u.normalize('NFKC',s)) for s in dict.fromkeys(values)]),ensure_ascii=True,separators=(',',':')))
