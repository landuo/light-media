"""Run selected public installed source against in-memory hosts and synthetic config."""
import ast,contextlib,copy,hashlib,io,json,pathlib,socket,sys,types,typing
attempts=dict(network=0,writes=0,process=0)
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo'):attempts['network']+=1;raise RuntimeError('network_denied')
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):attempts['process']+=1;raise RuntimeError('process_denied')
 if event=='open' and (isinstance(args[1],str) and any(c in args[1] for c in 'wax+') or isinstance(args[2],int) and args[2]&(1|2|64|512)):attempts['writes']+=1;raise RuntimeError('write_denied')
sys.addaudithook(audit)
import python_hosts.hosts as module
from python_hosts import Hosts,HostsEntry
source=pathlib.Path('/app/app/plugins/customhosts/__init__.py').read_bytes();source_sha=hashlib.sha256(source).hexdigest();assert source_sha=='0d6561baa5fdeddac87039718e10648c6df2deed52bbe6397f807cf3862560ca'
class Base:
 def __init__(self):
  self.saved=[];self.messages=[];self.systemmessage=types.SimpleNamespace(put=self.message)
 def update_config(self,v):self.saved.append(copy.deepcopy(v))
 def message(self,msg,title=None):self.messages.append(dict(title=title,message=msg))
ip_source=pathlib.Path('/app/app/utils/ip.py').read_bytes()
ip_class=next(n for n in ast.parse(ip_source).body if isinstance(n,ast.ClassDef) and n.name=='IpUtils')
ip_method=next(n for n in ip_class.body if isinstance(n,ast.FunctionDef) and n.name=='is_ipv4')
ip_class.body=[ip_method];ip_ns=dict(socket=socket);exec(compile(ast.Module(body=[ip_class],type_ignores=[]),'<installed-ip-predicate-ast>','exec'),ip_ns);IP=ip_ns['IpUtils']
ns=dict(_PluginBase=Base,Hosts=Hosts,HostsEntry=HostsEntry,IpUtils=IP,SystemUtils=types.SimpleNamespace(is_windows=lambda:False),eventmanager=types.SimpleNamespace(register=lambda _:lambda f:f),EventType=types.SimpleNamespace(PluginReload='PluginReload'),logger=types.SimpleNamespace(info=lambda *a:None,error=lambda *a:None),List=typing.List,Tuple=typing.Tuple,Dict=typing.Dict,Any=typing.Any)
node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CustomHosts');exec(compile(ast.Module(body=[node],type_ignores=[]),'<installed-customhosts-ast>','exec'),ns)

import sqlite3
assert isinstance(_target_hosts,str) and len(_target_hosts.encode())<131072
with sqlite3.connect('file:/config/user.db?mode=ro',uri=True) as db:
 db.execute('pragma query_only=ON');db.execute('begin')
 raw=db.execute('select value from systemconfig where key=?',('plugin.CustomHosts',)).fetchone()[0]
 assert hashlib.sha256(raw.encode()).hexdigest()=='e304545981b55e031afcdbedd617cd778b15d76224f6b8d63128df8f7aa09463'
 config=json.loads(raw)
state=dict(content=_target_hosts,reads=0,writes=0)
class Writer(io.StringIO):
 def __exit__(self,*args):
  if args[0] is None:state['content']=self.getvalue()
  self.close()
def fake_open(path,mode='r',**kwargs):
 assert path=='/etc/hosts'
 if mode=='r':state['reads']+=1;return io.StringIO(state['content'].replace('\r\n','\n').replace('\r','\n'))
 assert mode=='w';state['writes']+=1;return Writer()
module.safe_open=fake_open
obj=ns['CustomHosts']();obj.init_plugin(copy.deepcopy(config))
assert attempts==dict(network=0,writes=0,process=0) and obj.get_state() is True and len(obj.saved)==1 and not obj.messages
print(json.dumps(dict(config=obj.saved[0],content=state['content'],file_sha256=hashlib.sha256(state['content'].encode()).hexdigest(),memory_reads=state['reads'],memory_writes=state['writes'],actual_audit=attempts),ensure_ascii=False,separators=(',',':')))
