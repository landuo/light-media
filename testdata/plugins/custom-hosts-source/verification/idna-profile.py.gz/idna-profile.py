import hashlib,json,pathlib,stringprep,sys,unicodedata
u=unicodedata.ucd_3_2_0
predicates=dict(b1=stringprep.in_table_b1,prohibited=lambda c:any(p(c) for p in [stringprep.in_table_c12,stringprep.in_table_c22,stringprep.in_table_c3,stringprep.in_table_c4,stringprep.in_table_c5,stringprep.in_table_c6,stringprep.in_table_c7,stringprep.in_table_c8,stringprep.in_table_c9]),randal=stringprep.in_table_d1,lcat=stringprep.in_table_d2,assigned=lambda c:u.category(c)!='Cn')
ranges={k:[] for k in predicates};previous={k:False for k in predicates};mapping=[];normalization=[]
for n in range(0x110000):
 c=chr(n)
 for key,p in predicates.items():
  yes=p(c)
  if yes and previous[key]:ranges[key][-1][1]=n
  elif yes:ranges[key].append([n,n])
  previous[key]=yes
 b=stringprep.map_table_b2(c)
 if b!=c:mapping.append([n,b])
 if u.category(c)!='Cn':
  normalized=u.normalize('NFKC',c)
  if normalized!=c:normalization.append([n,normalized])
values=['','example','EXAMPLE.','a..b','a.' ,'a'*64,'é'*60+'.example','é\u2024x','\u200c','xn--é','a\x00b','😀.example','\u0130.example','abcאב','אב1','אבaאב','אב.مثال','\u1e9e','\u2f868','\U0001e030a','a\U0001e4ec\u0301']
values+=['x'+chr(n)+'y.example' for n,_ in mapping+normalization]
values+=['a'+chr(n)+'b.example' for n in [0x20,0xa0,0x2000,0x200b,0x200e,0x2060,0xfffd,0x10ffff,0x3002,0xff0e,0xff61]]
cases=[]
for text in dict.fromkeys(values):
 try:out=text.encode('idna').decode('ascii');error=None
 except UnicodeError as e:out=None;error=type(e).__name__
 cases.append(dict(input=text,output=out,error=error))
files={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in [stringprep.__file__]}
print(json.dumps(dict(python=sys.version.split()[0],unicode=unicodedata.unidata_version,normalization_unicode=u.unidata_version,source_files=files,ranges=ranges,mapping=mapping,normalization=normalization,cases=cases),ensure_ascii=True,separators=(',',':')))
