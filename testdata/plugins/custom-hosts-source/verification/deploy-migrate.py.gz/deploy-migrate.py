import base64,hashlib,json,pathlib,shlex,subprocess,time,uuid
r=pathlib.Path(__file__).resolve().parent
base='/vol2/1000/docker/light-media';release=base+'/releases/plugin-v046-custom-hosts-'+uuid.uuid4().hex[:8]
old='b8e56d0446960cf79c102e84822df705eb92422aeb94669102ea44dfc134a8d6'
new='f1763c0c477cb5004bf3fd44b4c61d073cdd3f8dfe743cb9194c22e702e27204'
toolsha='9425fe0e0d9ff65b5ab1a795f90526240285e5d438cea35096b7966c34e12502'
composeSHA='2f7eca5f2ee487c90adf65c7567cb478efa6a30a01f7a2ded58b6467c23ba4a8'
prefix=(r.parent/'_server_status_formal_v045/remote-prefix.py.txt').read_text()
prefix=prefix.replace('/vol2/1000/docker/light-media/releases/plugin-v045-server-status-20261021-92fe60',release)
prefix+='''
previous_snapshot=snapshot
def snapshot(immutable=False):
 out=previous_snapshot(immutable)
 db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro'+('&immutable=1' if immutable else ''),uri=True);db.execute('pragma query_only=ON')
 out['custom_hosts']={name:db.execute(sql).fetchone()[0] for name,sql in {
 'installation':"select count(*) from plugin_installations where instance_id='CustomHosts' and installed=1 and desired_enabled=1",
 'config':"select count(*) from plugin_values where instance_id='CustomHosts' and kind='config'",
 'runs':"select count(*) from plugin_runs where instance_id='CustomHosts'",
 'success':"select count(*) from plugin_runs where instance_id='CustomHosts' and state='succeeded'",
 'active':"select count(*) from plugin_runs where instance_id='CustomHosts' and state in ('pending','running','reconcile_pending')",
 'other':"select count(*) from plugin_runs where instance_id='CustomHosts' and action!='init'",
 'data':"select count(*) from plugin_values where instance_id='CustomHosts' and kind='data'",
 'schedules':"select count(*) from plugin_schedules where instance_id='CustomHosts'",
 'events':"select count(*) from plugin_event_subscriptions where instance_id='CustomHosts'"}.items()}
 out['active_work']=db.execute("select (select count(*) from jobs where state in ('queued','running'))+(select count(*) from plugin_runs where state in ('pending','running','reconcile_pending'))").fetchone()[0]
 db.close();return out
'''
def ssh(command,data=None,timeout=55):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129',command],input=data,capture_output=True,timeout=timeout)
 if p.returncode:raise RuntimeError('bounded_remote_exit_'+str(p.returncode))
 return p.stdout
def remote(code):return json.loads(ssh('python3 -',(prefix+code).encode()))
def capture(script):return ssh('sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -',script)
def source():return capture((r/'emit-source-selected.py').read_bytes())
def write(path,data,expected=None,exclusive=False,mode=0o600):
 code='''import hashlib,os,pathlib,sys
p=pathlib.Path(%r);raw=sys.stdin.buffer.read();assert len(raw)==%d and hashlib.sha256(raw).hexdigest()==%r
%s
fd=os.open(p,os.O_WRONLY|os.O_CREAT|%s,%d)
%s
with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
'''%(path,len(data),hashlib.sha256(data).hexdigest(),("assert hashlib.sha256(p.read_bytes()).hexdigest()==%r"%expected) if expected else '', 'os.O_EXCL' if exclusive else 'os.O_TRUNC',mode,('os.fchmod(fd,%d)'%mode) if exclusive else '')
 ssh(shlex.join(['python3','-c',code]),data)
def compare(a,c,new_plugin=False,restart=False):
 for k in ['key_sha256','category_sha256','p0_jobs']:assert a[k]==c[k],k
 obs={'directory_file','directory_status','directory_file_state'}
 assert [v for v in a['records'] if v[0] not in obs]==[v for v in c['records'] if v[0] not in obs],'protected_records'
 for k in ['plugin_values','installations']:
  assert [v for v in a[k] if not new_plugin or v[0]!='CustomHosts']==[v for v in c[k] if not new_plugin or v[0]!='CustomHosts'],k
 for field in ['system_process','server_status']:
  exp=dict(a[field])
  if restart:
   exp['runs']+=1;exp['succeeded_runs' if field=='system_process' else 'success']+=1
  assert c[field]==exp,field
report=dict(state='preflight',release=release,server_sha256=new,tool_sha256=toolsha,actual_complete=5,remaining=18)
def save(): (r/'deployment-result.json').write_text(json.dumps(report,indent=2)+'\n')
stopped=swapped=compose_changed=exposed=False;oldcompose=None;owned_created=False
try:
 assert json.loads((r/'VERIFICATION.json').read_text())['state'].startswith('passed')
 before=remote('''
assert sha(b/'light-media-server')==%r and sha(b/'compose.yaml')==%r
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=3) as response:assert json.load(response)['data']['version']=='0.4.5'
assert os.getuid()==1000 and os.getgid()==1001 and not (b/'container-hosts').exists() and not release.exists()
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=3*1024**3 and os.getloadavg()[0]<5
out=snapshot();assert out['active_work']==0 and out['migration_receipts']==5 and sum(out['custom_hosts'].values())==0
out['originals']={n:identity(n) for n in ['moviepilot','qb']};out['original_hosts_sha256']=docker('exec','moviepilot','sha256sum','/etc/hosts').decode().split()[0]
out['target_before']=identity('light-media');release.mkdir(mode=0o700);print(json.dumps(out))
'''%(old,composeSHA))
 report['before']=before;save()
 for local,name,digest in [('light-media-linux-owned','light-media-server',new),('custom-hosts-migrate-linux-owned','custom-hosts-migrate-owned',toolsha)]:
  data=(r/local).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;write(release+'/'+name,data,exclusive=True,mode=0o700)
 payload=source();assert json.loads(payload)==json.loads(source())
 tool=release+'/custom-hosts-migrate-owned';assert json.loads(ssh(shlex.join([tool,'--validate']),payload))['writes']==0
 oldcompose=ssh(shlex.join(['cat',base+'/compose.yaml']));assert hashlib.sha256(oldcompose).hexdigest()==composeSHA
 assert oldcompose.count(b'    volumes:\n')==1 and b'container-hosts' not in oldcompose
 newcompose=oldcompose.replace(b'    volumes:\n',b'    volumes:\n      - ./container-hosts:/etc/hosts\n',1)
 hosts=ssh('sudo -n docker exec light-media cat /etc/hosts');assert b'# CustomHostsPlugin' not in hosts
 code=('import json\n_target_hosts='+repr(hosts.decode())+'\n').encode()+(r/'simulate-source-selected.py').read_bytes()
 expected=json.loads(capture(code));assert expected['memory_reads']==1 and expected['memory_writes']==1 and expected['actual_audit']==dict(network=0,writes=0,process=0)
 write(base+'/container-hosts',hosts,exclusive=True);owned_created=True
 report.update(state='staged_validated_before_outage',expected_hosts_sha256=expected['file_sha256']);save();print('staged_validated_before_outage',flush=True)
 ssh('sudo -n docker stop -t 30 light-media');stopped=True
 frozen=remote('''
assert not identity('light-media')['running'];lock=open(b/'data/instance.lock','rb');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
out=snapshot(True);assert out['active_work']==0
for suffix in ['-wal','-journal']:
 p=b/('data/light-media.db'+suffix);assert not p.exists() or p.is_file() and p.stat().st_size==0
db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro&immutable=1',uri=True);backup=sqlite3.connect(str(release/'rollback-light-media.db'));db.backup(backup);assert backup.execute('pragma quick_check').fetchone()[0]=='ok';backup.close();db.close();os.chmod(release/'rollback-light-media.db',0o600)
shutil.copy2(b/'light-media-server',release/'rollback-light-media-server');assert sha(release/'rollback-light-media-server')==%r
lock.close();print(json.dumps(out))
'''%old)
 compare(before,frozen);assert json.loads(payload)==json.loads(source())
 remote('''
assert not identity('light-media')['running'] and sha(b/'light-media-server')==%r and sha(release/'light-media-server')==%r
p=b/'light-media-server.v046.new';assert not p.exists();shutil.copy2(release/'light-media-server',p);os.chmod(p,0o755);os.replace(p,b/'light-media-server');print('{}')
'''%(old,new));swapped=True
 args=[tool,'--target-data-dir',base+'/data','--owned-hosts-file',base+'/container-hosts']
 assert json.loads(ssh(shlex.join(args),payload))['writes']==0
 imported=json.loads(ssh(shlex.join(args+['--apply']),payload));assert imported['state']=='imported' and imported['desired_enabled'] and not imported['executed'] and not imported['scheduled']
 replay=json.loads(ssh(shlex.join(args+['--apply']),payload));assert replay['receipt']==imported['receipt'] and replay['replayed']
 preserved=remote("print(json.dumps(snapshot(True)))\n");compare(frozen,preserved,new_plugin=True)
 init=dict(installation=1,config=1,runs=0,success=0,active=0,other=0,data=0,schedules=0,events=0)
 assert preserved['custom_hosts']==init and preserved['migration_receipts']==6
 write(base+'/compose.yaml',newcompose,expected=composeSHA);compose_changed=True
 ssh('sudo -n docker compose -f /vol2/1000/docker/light-media/compose.yaml config --quiet')
 report.update(state='import_committed_target_stopped',import_result=imported,preserved=preserved,new_compose_sha256=hashlib.sha256(newcompose).hexdigest());save()
 exposed=True
 ssh('sudo -n docker compose -f /vol2/1000/docker/light-media/compose.yaml up -d --no-deps light-media');stopped=False
 after=None
 for _ in range(30):
  try:
   after=remote('''
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=2) as response:assert json.load(response)['data']['version']=='0.4.6'
assert sha(b/'light-media-server')==%r and docker('exec','light-media','sha256sum','/app/light-media-server').decode().split()[0]==%r
out=snapshot();out['originals']={n:identity(n) for n in ['moviepilot','qb']};out['original_hosts_sha256']=docker('exec','moviepilot','sha256sum','/etc/hosts').decode().split()[0];out['target']=identity('light-media');out['owned_hosts_sha256']=sha(b/'container-hosts');print(json.dumps(out))
'''%(new,new))
   if after['custom_hosts']=={**init,'runs':1,'success':1,'events':1} and after['active_work']==0:break
  except RuntimeError:pass
  time.sleep(.25)
 assert after is not None;compare(preserved,after,new_plugin=True,restart=True)
 assert after['custom_hosts']=={**init,'runs':1,'success':1,'events':1} and after['migration_receipts']==6 and after['originals']==before['originals'] and after['original_hosts_sha256']==before['original_hosts_sha256'] and after['owned_hosts_sha256']==expected['file_sha256']
 actual=remote('''
import base64
db=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro',uri=True);sealed=db.execute("select sealed from plugin_values where instance_id='CustomHosts' and kind='config' and item_key='main'").fetchone()[0];db.close()
x=json.loads(docker('inspect','light-media'))[0];assert x['Config']['User']=='1000:1001' and x['HostConfig']['ReadonlyRootfs'] and x['HostConfig']['NetworkMode']=='host' and x['HostConfig']['Memory']==536870912 and x['HostConfig']['NanoCpus']==1000000000
mount=next(m for m in x['Mounts'] if m['Destination']=='/etc/hosts');assert mount['Source']==str(b/'container-hosts') and mount['RW']
assert (b/'container-hosts').stat().st_uid==1000 and (b/'container-hosts').stat().st_mode&511==384
assert docker('exec','light-media','sha256sum','/etc/hosts').decode().split()[0]==sha(b/'container-hosts')
print(json.dumps(dict(key=base64.b64encode((b/'data/secret.key').read_bytes()).decode(),sealed=base64.b64encode(sealed).decode(),dedicated_mount_verified=True)))
''')
 checkcode="""const c=require('node:crypto');let raw='';process.stdin.on('data',x=>raw+=x);process.stdin.on('end',()=>{const x=JSON.parse(raw),s=Buffer.from(x.actual.sealed,'base64'),d=c.createDecipheriv('aes-256-gcm',Buffer.from(x.actual.key,'base64'),s.subarray(0,12));d.setAAD(Buffer.from(JSON.stringify(['light-media/plugins/v1','config','CustomHosts','main'])));d.setAuthTag(s.subarray(s.length-16));const value=JSON.parse(Buffer.concat([d.update(s.subarray(12,-16)),d.final()]).toString());const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;if(JSON.stringify(canonical(value))!==JSON.stringify(canonical(x.expected)))process.exit(1);process.stdout.write(JSON.stringify({runtime_source_config_equal:true}));});"""
 node=subprocess.run(['node','-e',checkcode],input=json.dumps(dict(actual=actual,expected=expected['config'])).encode(),capture_output=True,timeout=10);assert node.returncode==0 and json.loads(node.stdout)['runtime_source_config_equal']
 assert json.loads(payload)==json.loads(source())
 report.update(state='cold_runtime_verified_pending_production_ui',version='0.4.6',actual_complete=5,remaining=18,candidate_complete_after_ui=6,after=after,original_services_and_hosts_unchanged=True,existing_configuration_and_preferences_preserved=True,dedicated_mount_verified=True,runtime_source_config_equal=True,source_private_values_saved=False);save();print(json.dumps({k:report[k] for k in ['state','version','candidate_complete_after_ui']}))
except BaseException as e:
 report.update(state='failed',error_class=type(e).__name__,exposed=exposed);save()
 if stopped and not exposed:
  if compose_changed and oldcompose is not None:write(base+'/compose.yaml',oldcompose)
  if swapped:
   remote('''
assert not identity('light-media')['running'];assert sha(release/'rollback-light-media-server')==%r
p=b/'light-media-server.v046.rollback';assert not p.exists();shutil.copy2(release/'rollback-light-media-server',p);os.replace(p,b/'light-media-server')
src=sqlite3.connect('file:'+str(release/'rollback-light-media.db')+'?mode=ro&immutable=1',uri=True);dst=sqlite3.connect(str(b/'data/light-media.db'));src.backup(dst);assert dst.execute('pragma quick_check').fetchone()[0]=='ok';src.close();dst.close();print('{}')
'''%old)
  ssh('sudo -n docker start light-media')
 if owned_created and not exposed:
  remote("p=b/'container-hosts';assert p.is_file() and not p.is_symlink();p.unlink();print('{}')\n")
 raise
