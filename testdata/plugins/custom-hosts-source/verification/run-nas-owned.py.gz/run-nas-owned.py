import hashlib,json,pathlib,shlex,subprocess,uuid

root=pathlib.Path(__file__).resolve().parent
fixture=str(uuid.uuid4()); name='lm-hosts-source-'+fixture
base='/vol2/1000/docker/light-media/work/'+name
image='sha256:c83674e1999044d33d751661371b873539f47e5b5c5ca3320c7e0377acca6238'
binary=(root/'custom-hosts-linux.test').read_bytes(); digest=hashlib.sha256(binary).hexdigest()
report=dict(fixture=fixture,name=name,base=base,image=image,binary_sha256=digest,state='preflight')
def save(): (root/'nas-owned-result.json').write_text(json.dumps(report,indent=2)+'\n')
def ssh(command,data=None,timeout=60):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129',command],input=data,capture_output=True,timeout=timeout)
 if p.returncode: raise RuntimeError('remote_exit_'+str(p.returncode))
 return p.stdout
prefix='''import hashlib,json,os,pathlib,shutil,subprocess,sys
def docker(*args): return subprocess.check_output(['sudo','-n','docker',*args],timeout=40)
def identity(n):
 x=json.loads(docker('inspect',n))[0]
 return {k:x['State'][k] for k in ['Pid','StartedAt','Running']}|{'id':x['Id'],'restart':x['RestartCount']}
'''
def remote(code): return json.loads(ssh('python3 -',(prefix+code).encode()))
created=False
try:
 gate=remote("""
mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
load=os.getloadavg()[0];b=pathlib.Path(%r)
out=dict(uid=os.getuid(),gid=os.getgid(),memory_available=mem,load=load,disk_available=shutil.disk_usage(b.parent.parent).free,originals={n:identity(n) for n in ['moviepilot','qb','light-media']})
out['allowed']=mem>=3*1024**3 and load<5 and out['disk_available']>=1024**3
if out['allowed']:
 assert not b.exists();b.mkdir(mode=0o755);out['created']=True
else:out['created']=False
print(json.dumps(out))
"""%base)
 report['gate']=gate;created=gate['created'];save()
 if not gate['allowed']:
  report['state']='resource_gate_deferred';save();print(json.dumps({'state':report['state'],'memory_available':gate['memory_available'],'load':gate['load']}));raise SystemExit(0)
 writer="""import hashlib,os,pathlib,sys
b=pathlib.Path(%r);raw=sys.stdin.buffer.read();assert len(raw)==%d and hashlib.sha256(raw).hexdigest()==%r
p=b/'test';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o555)
with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
p=b/'hosts';p.write_text(%r);os.chmod(p,0o600)
"""%(base,len(binary),digest,'# light-media-owned-hosts-fixture '+fixture+'\n127.0.0.1\tlocalhost\n::1\tlocalhost\n')
 ssh(shlex.join(['python3','-c',writer]),binary)
 # The authenticated SSH user and target container both use uid 1000/gid 1001.
 assert gate['uid']==1000 and gate['gid']==1001
 args=['sudo','-n','docker','run','--name',name,'--label','light-media.owned-fixture='+fixture,'--network','none','--user','1000:1001','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges:true','--memory','512m','--cpus','1','--pids-limit','128','--tmpfs','/tmp:rw,size=64m,mode=1777','--mount','type=bind,src='+base+'/test,dst=/fixture/test,readonly','--mount','type=bind,src='+base+'/hosts,dst=/etc/hosts','--env','LIGHT_MEDIA_HOSTS_TEST=1','--env','LIGHT_MEDIA_HOSTS_TEST_ID='+fixture,'--entrypoint','/fixture/test',image,'-test.run=^TestIsolatedCustomHostsNetwork$','-test.v','-test.timeout=40s']
 output=ssh(shlex.join(args),timeout=60).decode()
 assert 'owned_container_hosts_write_go_http_and_restore_verified' in output and '--- PASS: TestIsolatedCustomHostsNetwork' in output and 'FAIL' not in output
 (root/'nas-owned-test-output.txt').write_text(output)
 after=remote("""
x=json.loads(docker('inspect',%r))[0];assert x['Config']['Labels']['light-media.owned-fixture']==%r
assert x['State']['ExitCode']==0 and not x['State']['OOMKilled'] and not x['State']['Running']
assert x['HostConfig']['NetworkMode']=='none' and x['Config']['User']=='1000:1001' and x['HostConfig']['ReadonlyRootfs']
print(json.dumps(dict(exit=x['State']['ExitCode'],oom=x['State']['OOMKilled'],originals={n:identity(n) for n in ['moviepilot','qb','light-media']},hosts_sha256=hashlib.sha256(pathlib.Path(%r).read_bytes()).hexdigest())))
"""%(name,fixture,base+'/hosts'))
 assert gate['originals']==after['originals']
 report.update(state='passed',after=after,actual_go_sdk_write_resolver_http_restore=True,source_or_production_writes=0);save()
finally:
 if created:
  cleanup=remote("""
b=pathlib.Path(%r)
p=subprocess.run(['sudo','-n','docker','inspect',%r],capture_output=True)
if p.returncode==0:
 x=json.loads(p.stdout)[0];assert x['Config']['Labels']['light-media.owned-fixture']==%r
 if x['State']['Running']:docker('stop','-t','5',%r)
 docker('rm',%r)
assert b.is_dir() and b.name==%r and set(x.name for x in b.iterdir()).issubset({'test','hosts'})
for p in b.iterdir():assert p.is_file() and not p.is_symlink()
shutil.rmtree(b)
print(json.dumps(dict(owned_directory_absent=not b.exists(),owned_container_absent=subprocess.run(['sudo','-n','docker','inspect',%r],capture_output=True).returncode!=0,originals={n:identity(n) for n in ['moviepilot','qb','light-media']})))
"""%(base,name,fixture,name,name,name,name))
  assert cleanup['owned_directory_absent'] and cleanup['owned_container_absent'] and cleanup['originals']==report['gate']['originals']
  report['cleanup']=cleanup;save()
if report['state']=='passed': print(json.dumps({'state':'passed','owned_resources_cleaned':True,'original_and_production_container_identities_unchanged':True}))
