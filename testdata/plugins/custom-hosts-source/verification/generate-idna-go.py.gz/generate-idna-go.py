import hashlib,json,pathlib,re,shutil
root=pathlib.Path(__file__).resolve().parent;profile=json.loads((root/'reference/idna-profile.json').read_text());target=root/'app/internal/pythonidna';target.mkdir(parents=True,exist_ok=True)
extra=json.loads((root/'reference/normalization-profile.json').read_text());profile['normalization']=[(r,v) for r,v in extra['decomposition'] if not 0xac00<=r<0xac00+11172]
rows=['// Code generated from installed Python '+profile['python']+' stringprep and Unicode '+profile['normalization_unicode']+'; DO NOT EDIT.','package pythonidna','']
for key,go in [('mapping','mapB2'),('normalization','normalize32')]:
 rows.append('var '+go+' = [...]mapping{')
 rows+=['{0x%x,%s},'%(n,json.dumps(v,ensure_ascii=False)) for n,v in profile[key]];rows+=['}','']
for key,items in profile['ranges'].items():
 if key=='assigned':continue
 rows.append('var '+key+' = [...]interval{');rows+=['{0x%x,0x%x},'%(a,b) for a,b in items];rows+=['}','']
rows.append('var combining = [...]combiningEntry{')
rows+=['{0x%x,%d},'%(a,b) for a,b in extra['combining']];rows+=['}','']
rows.append('var composition = [...]composeEntry{')
rows+=['{0x%x,0x%x},'%((a<<21)|b,c) for a,b,c in extra['composition']];rows+=['}','']
(target/'profile_data.go').write_text('\n'.join(rows))
source=pathlib.Path('/Users/accidia/go/pkg/mod/golang.org/x/net@v0.61.0/idna/punycode.go').read_text();functions=[]
for name in ['encode','madd','encodeDigit','adapt']:
 a=source.index('func '+name+'(');b=source.index('{',a);depth=1;pos=b+1
 while depth:
  if source[pos]=='{':depth+=1
  elif source[pos]=='}':depth-=1
  pos+=1
 functions.append(source[a:pos])
s='''// Copyright 2016 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license in LICENSE.Go.
// RFC 3492 encoder extracted from golang.org/x/net v0.61.0/idna/punycode.go.
package pythonidna
import("math";"errors")
const(base int32=36;damp int32=700;initialBias int32=72;initialN int32=128;skew int32=38;tmax int32=26;tmin int32=1)
func punyError(string)error{return errors.New("invalid_python_idna_label")}
'''+ '\n\n'.join(functions)
s=re.sub(r'\n\s*if unicode16 && r == 0xfffd \{\n\s*return s, &labelError\{s, "A3"\}\n\s*\}', '',s)
(target/'punycode.go').write_text(s)
shutil.copyfile('/Users/accidia/go/pkg/mod/golang.org/x/net@v0.61.0/LICENSE',target/'LICENSE.Go')
(target/'testdata').mkdir(exist_ok=True)
(target/'testdata/original-idna.json').write_text(json.dumps(dict(python=profile['python'],unicode=profile['unicode'],normalization_unicode=profile['normalization_unicode'],cases=profile['cases']),ensure_ascii=True,separators=(',',':'))+'\n')
(target/'NOTICE.txt').write_text('Python builtin IDNA 2003 profile: generated from actual installed Python '+profile['python']+' stringprep/ucd_3_2_0; values are public Unicode character data. Python source file pins '+json.dumps(profile['source_files'])+'.\nPunycode encoder extracted from golang.org/x/net v0.61.0 under BSD license (LICENSE.Go), without the unrelated UTS46 decode and Unicode-version hooks.\n')
print({'profile_bytes':(target/'profile_data.go').stat().st_size,'oracle_cases':len(profile['cases'])})
