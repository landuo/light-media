import hashlib,json,os,pathlib,sqlite3,sys
counts=dict(network=0,writes=0,process=0)
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo'):counts['network']+=1;raise RuntimeError('network_denied')
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):counts['process']+=1;raise RuntimeError('process_denied')
 if event=='open' and (isinstance(args[1],str) and any(c in args[1] for c in 'wax+') or isinstance(args[2],int) and args[2]&(1|2|64|512)):counts['writes']+=1;raise RuntimeError('write_denied')
sys.addaudithook(audit)
sha=lambda b:hashlib.sha256(b).hexdigest()
p=pathlib.Path('/app/app/plugins/customhosts/__init__.py');source=p.read_bytes()
assert sha(source)=='0d6561baa5fdeddac87039718e10648c6df2deed52bbe6397f807cf3862560ca'
with sqlite3.connect('file:/config/user.db?mode=ro',uri=True) as db:
 db.execute('pragma query_only=ON');db.execute('begin')
 rows=db.execute('select value from systemconfig where key=?',('plugin.CustomHosts',)).fetchall();assert len(rows)==1 and isinstance(rows[0][0],str)
 value=rows[0][0];assert isinstance(json.loads(value),dict)
 installed=db.execute('select value from systemconfig where key=?',('UserInstalledPlugins',)).fetchone();assert installed and json.loads(installed[0]).count('CustomHosts')==1
 kv=db.execute('select count(*) from plugindata where plugin_id=?',('CustomHosts',)).fetchone()[0];assert kv==0
 assert not os.path.lexists('/config/plugins/CustomHosts')
 assert counts==dict(network=0,writes=0,process=0)
 assert len(value.encode())==261 and sha(value.encode())=='e304545981b55e031afcdbedd617cd778b15d76224f6b8d63128df8f7aa09463'
 print(json.dumps(dict(version=1,source_container='cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a',source_sha256=sha(source),config=value,installed_count=1,kv_count=0,file_count=0,symlink_count=0),ensure_ascii=False,sort_keys=True,separators=(',',':')))
