import hashlib,json,os,pathlib,signal,sqlite3,subprocess,tempfile,time
r=pathlib.Path(__file__).resolve().parent
p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(r/'emit-source-selected.py').read_bytes(),capture_output=True,timeout=20)
assert p.returncode==0,'selected_source_capture_failed';payload=p.stdout
with tempfile.TemporaryDirectory(prefix='light-media-hosts-cli-owned-') as td:
 b=pathlib.Path(td);data=b/'data';hosts=b/'container-hosts';hosts.write_text('127.0.0.1\tlocalhost\n');hosts.chmod(0o600);before=hosts.read_bytes()
 server=subprocess.Popen([str(r/'light-media-native-owned'),'--data-dir',str(data),'--listen','127.0.0.1:0'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  ready=False
  for _ in range(100):
   assert server.poll() is None,'owned_server_stopped'
   try:
    db=sqlite3.connect('file:'+str(data/'light-media.db')+'?mode=ro',uri=True);ready=db.execute('select version from plugin_storage_schema').fetchone()[0]==1;db.close()
    if ready:break
   except sqlite3.Error:pass
   time.sleep(.05)
  assert ready,'owned_server_not_ready'
  args=[str(r/'custom-hosts-migrate-owned'),'--target-data-dir',str(data),'--owned-hosts-file',str(hosts)]
  locked=subprocess.run(args,input=payload,capture_output=True,timeout=10)
  assert locked.returncode!=0 and b'target_application_is_running' in locked.stderr,'active_target_lock_not_enforced'
 finally:
  if server.poll() is None:server.send_signal(signal.SIGTERM)
  assert server.wait(timeout=10)==0,'owned_server_unclean_stop'
 outputs=[]
 for extra in [[],['--apply'],['--apply']]:
  p=subprocess.run(args+extra,input=payload,capture_output=True,timeout=15)
  assert p.returncode==0,'owned_cli_operation_failed';outputs.append(json.loads(p.stdout))
 assert outputs[0]['writes']==0 and not outputs[0]['same_receipt']
 assert outputs[1]['state']=='imported' and outputs[1]['desired_enabled'] and not outputs[1]['executed'] and not outputs[1]['scheduled']
 assert outputs[2]['receipt']==outputs[1]['receipt'] and outputs[2]['replayed']
 assert hosts.read_bytes()==before,'offline_tool_wrote_hosts'
 db=sqlite3.connect('file:'+str(data/'light-media.db')+'?mode=ro&immutable=1',uri=True)
 assert db.execute('pragma quick_check').fetchone()[0]=='ok'
 assert db.execute("select (select count(*) from plugin_runs)+(select count(*) from plugin_schedules)+(select count(*) from plugin_event_subscriptions)").fetchone()[0]==0
 assert db.execute('select count(*) from plugin_migration_receipts').fetchone()[0]==1
 db.close()
 report=dict(state='passed',active_target_lock_enforced=True,actual_product_clean_start_stop=True,actual_cli_dry_apply_replay=True,hosts_unchanged=True,source_private_input_saved=False,workers=0,schedules=0,owned_directory_cleaned=False)
assert not pathlib.Path(td).exists();report['owned_directory_cleaned']=True
(r/'cli-owned-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
