"""Run selected public installed source against in-memory hosts and synthetic config."""
import ast,contextlib,copy,hashlib,io,json,pathlib,socket,sys,types,typing
attempts=dict(network=0,writes=0,process=0)
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo'):attempts['network']+=1;raise RuntimeError('network_denied')
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):attempts['process']+=1;raise RuntimeError('process_denied')
 if event=='open' and (isinstance(args[1],str) and any(c in args[1] for c in 'wax+') or isinstance(args[2],int) and args[2]&(1|2|64|512)):attempts['writes']+=1;raise RuntimeError('write_denied')
sys.addaudithook(audit)
import python_hosts.hosts as module
from python_hosts import Hosts,HostsEntry
source=pathlib.Path('/app/app/plugins/customhosts/__init__.py').read_bytes();source_sha=hashlib.sha256(source).hexdigest();assert source_sha=='0d6561baa5fdeddac87039718e10648c6df2deed52bbe6397f807cf3862560ca'
class Base:
 def __init__(self):
  self.saved=[];self.messages=[];self.systemmessage=types.SimpleNamespace(put=self.message)
 def update_config(self,v):self.saved.append(copy.deepcopy(v))
 def message(self,msg,title=None):self.messages.append(dict(title=title,message=msg))
ip_source=pathlib.Path('/app/app/utils/ip.py').read_bytes()
ip_class=next(n for n in ast.parse(ip_source).body if isinstance(n,ast.ClassDef) and n.name=='IpUtils')
ip_method=next(n for n in ip_class.body if isinstance(n,ast.FunctionDef) and n.name=='is_ipv4')
ip_class.body=[ip_method];ip_ns=dict(socket=socket);exec(compile(ast.Module(body=[ip_class],type_ignores=[]),'<installed-ip-predicate-ast>','exec'),ip_ns);IP=ip_ns['IpUtils']
ns=dict(_PluginBase=Base,Hosts=Hosts,HostsEntry=HostsEntry,IpUtils=IP,SystemUtils=types.SimpleNamespace(is_windows=lambda:False),eventmanager=types.SimpleNamespace(register=lambda _:lambda f:f),EventType=types.SimpleNamespace(PluginReload='PluginReload'),logger=types.SimpleNamespace(info=lambda *a:None,error=lambda *a:None),List=typing.List,Tuple=typing.Tuple,Dict=typing.Dict,Any=typing.Any)
node=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='CustomHosts');exec(compile(ast.Module(body=[node],type_ignores=[]),'<installed-customhosts-ast>','exec'),ns)
base='# owned fixture\n127.0.0.1\tlocalhost\n203.0.113.7\told.example\n';tail='# CustomHostsPlugin\n192.0.2.1\tstale.example\n'
cases=[]
def add(name,config,original=base+tail,write_error=False):cases.append(dict(name=name,config=config,original=original,write_error=write_error))
for name,config in [('none',None),('empty',{}),('off',{'enabled':False,'hosts':'127.0.0.1 keep.invalid'}),('missing',{'hosts':'127.0.0.1 keep.invalid'}),('null-hosts',{'enabled':True,'hosts':None}),('empty-hosts',{'enabled':True,'hosts':''}),('empty-lines',{'enabled':True,'hosts':'\n'}),('empty-array',{'enabled':True,'hosts':[]}),('truthy-enable',{'enabled':'source-truthy','hosts':'127.0.0.1 owned.invalid'}),('falsey-enable',{'enabled':[],'hosts':'127.0.0.1 owned.invalid'}),('ignored-errors',{'enabled':False,'err_hosts':{'unused':'source-does-not-read'}})]:add(name,config)
rows=['127.0.0.1 Fixture.One','0.0.0.0 ad.invalid','192.0.2.2 new.example new-alias.example','203.0.113.7 duplicate-address.example','192.0.2.3 old.example','2001:db8::1 IPv6.Example','::ffff:192.0.2.1 mapped.example','010.0.0.1 leading.example','127.1 short.example','fe80::1%eth0 zone.example','bad-ip invalid.example','127.0.0.1','  ','\x1c','\u0085','192.0.2.9\x1ePythonSpace.example','# own comment','192.0.2.8 www.EXAMPLE.','192.0.2.8 host.example # inline words','192.0.2.8 FAß.Example','192.0.2.8 ΣΟΣ.Example','192.0.2.8 例子.测试','192.0.2.8 emoji😀.example','192.0.2.8 a\u200db.example','192.0.2.8 '+('é'*60)+'.example','192.0.2.8 a..例子','192.0.2.8 A\u2024B.example','192.0.2.8 \u0130.Example']
for i,row in enumerate(rows):add('row-'+str(i),dict(enabled=True,hosts=row))
add('all-invalid',dict(enabled=True,hosts='bad-ip broken.example\n127.0.0.1\n  '))
add('duplicates',dict(enabled=True,hosts=['127.0.0.1 A.example','127.0.0.1 B.example','127.0.0.1 A.example','192.0.2.8 A.example','192.0.2.9 Fresh.example','192.0.2.9 Dropped.example']))
add('inline-base',dict(enabled=True,hosts='192.0.2.2 name.example'),original='# owned fixture\n127.0.0.1 localhost # old inline\n'+tail)
for n,c in [('write-fail',dict(enabled=True,hosts='127.0.0.1 owned.invalid')),('clear-fail',dict(enabled=False,hosts='')),('mixed-fail',dict(enabled=True,hosts='bad-ip invalid.example\n127.0.0.1 owned.invalid'))]:add(n,c,write_error=True)
for i,c in enumerate([{'enabled':True,'hosts':[1]},{'enabled':True,'hosts':1},{'enabled':True,'hosts':False},{'enabled':False,'hosts':{'ignored':1}}]):add('dynamic-'+str(i),c)
results=[]
for c in cases:
 state=dict(content=c['original'],reads=0,writes=0)
 class Writer(io.StringIO):
  def __exit__(self,*args):
   if args[0] is None:state['content']=self.getvalue()
   self.close()
 def fake_open(path,mode='r',**kwargs):
  assert path=='/etc/hosts'
  if mode=='r':state['reads']+=1;return io.StringIO(state['content'].replace('\r\n','\n').replace('\r','\n'))
  assert mode=='w';state['writes']+=1
  if c['write_error']:raise OSError('owned denied')
  return Writer()
 module.safe_open=fake_open
 obj=ns['CustomHosts']();error=None
 try:obj.init_plugin(copy.deepcopy(c['config']))
 except Exception as e:error=dict(class_name=type(e).__name__,message=str(e))
 results.append(dict(**c,result=dict(content=state['content'],reads=state['reads'],writes=state['writes'],saved=obj.saved,messages=obj.messages,state=obj.get_state(),error=error)))
assert attempts==dict(network=0,writes=0,process=0)
print(json.dumps(dict(source_sha256=source_sha,ip_source_sha256=hashlib.sha256(ip_source).hexdigest(),python=sys.version.split()[0],mode='actual selected class AST and installed python_hosts; in-memory IO/synthetic config only',audit=attempts,form=ns['CustomHosts']().get_form(),cases=results),ensure_ascii=False,separators=(',',':')))
