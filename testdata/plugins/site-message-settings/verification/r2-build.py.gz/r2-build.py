import pathlib,subprocess,os,json,sys
s=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];out=[]
normal=kind=='normal';race=kind=='race';linux=kind=='linux'
env=dict(os.environ,**({'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'} if linux else {}));suffix='-linux' if linux else '-race' if race else '';flags=['-race'] if race else []
cmds=[('app'+suffix,['go','test',*flags,'-c','-o',str(s/('app'+suffix+'.test')),'./internal/app'])]
for pkg in ['source-settings-migrate-owned','site-message-settings-migrate-owned']:
 cmds.append((pkg+suffix,['go','test',*flags,'-c','-o',str(s/(pkg+suffix+'.test')),'./cmd/'+pkg]))
 cmds.append((pkg+suffix+'-cli',['go','build',*flags,'-o',str(s/(pkg+suffix)),'./cmd/'+pkg]))
if linux:
 cmds.extend([('server-linux',['go','build','-trimpath','-o',str(s/'server-linux'),'./cmd/server']),('server-linux-modernconly',['go','build','-tags','modernconly','-trimpath','-o',str(s/'server-linux-modernconly'),'./cmd/server'])])
elif normal:
 cmds.extend([('web',['go','test','./web']),('vet',['go','vet','./internal/app','./cmd/source-settings-migrate-owned','./cmd/site-message-settings-migrate-owned']),('modules',['go','mod','verify'])])
for name,cmd in cmds:
 with (s/('build-'+name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=s/'app',env=env,stdout=f,stderr=subprocess.STDOUT)
 out.append({'name':name,'exit':r.returncode});(s/('build-'+kind+'-status.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out[-1]),flush=True)
 if r.returncode:sys.exit(r.returncode)
