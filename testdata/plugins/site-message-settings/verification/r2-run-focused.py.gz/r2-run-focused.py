import concurrent.futures,hashlib,json,pathlib,re,subprocess,sys,time
s=pathlib.Path(__file__).resolve().parent;kind=sys.argv[1];binary=s/('app-race.test' if kind=='race' else 'app.test')
pattern='^Test(ReviewedSourceSettings|ReviewedSiteMessageSettings|SiteMessageImportedSetting|SiteImport|SiteExport|Managed|LegacyUnkeyed|SiteAccount|SiteStatistics|SiteStatistic|PluginSiteStatistic|SourceAccount|SiteDataRefresh|SiteRefreshEvent|PluginMergeSiteSwitch|PluginHTTP|PluginCustomAPI|PriorityRuleDownloadSort|UnrelatedSettingsSave|FNOSSettings|FNOSCredential|SiteOptions)'
r=subprocess.run([str(binary),'-test.list='+pattern],capture_output=True,check=True,cwd=s/'app/internal/app');names=[x for x in r.stdout.decode().splitlines() if x.startswith('Test')];assert len(names)>70
by={k:[] for k in ['nexus','mteam','rousi','remaining']}
for n in names:
 k='nexus' if 'NexusOriginalRequests' in n else 'mteam' if 'MTeam' in n else 'rousi' if 'RousiOriginalRequests' in n else 'remaining';by[k].append(n)
(s/('focused-'+kind+'-groups.json')).write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'names':names,'groups':by},indent=2)+'\n')
def run(item):
 group,selected=item;started=time.monotonic();pattern='^('+('|'.join(re.escape(n) for n in selected))+')$'
 p=subprocess.run([str(binary),'-test.run='+pattern,'-test.v','-test.timeout=600s'],capture_output=True,cwd=s/'app/internal/app',timeout=615);log=p.stdout+p.stderr;(s/('focused-'+kind+'-'+group+'.log')).write_bytes(log)
 v={'group':group,'selected':selected,'exit':p.returncode,'top_pass':len(re.findall(rb'^--- PASS:',log,re.M)),'inclusive_pass':len(re.findall(rb'^\s*--- PASS:',log,re.M)),'failures':[x.decode() for x in re.findall(rb'^\s*--- FAIL: (\S+)',log,re.M)],'race_reports':len(re.findall(rb'WARNING: DATA RACE',log)),'elapsed':round(time.monotonic()-started,2)}
 print(json.dumps({k:v[k] for k in ['group','exit','top_pass','inclusive_pass','elapsed']}),flush=True);return v
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:out=list(executor.map(run,by.items()))
cli=s/('site-message-settings-migrate-owned-race.test' if kind=='race' else 'site-message-settings-migrate-owned.test')
p=subprocess.run([str(cli),'-test.v','-test.timeout=120s'],capture_output=True,timeout=130);(s/('cli-'+kind+'.log')).write_bytes(p.stdout+p.stderr);out.append({'group':'cli','exit':p.returncode})
(s/('focused-'+kind+'-status.json')).write_text(json.dumps(out,indent=2)+'\n')
assert all(x['exit']==0 and (x.get('top_pass')==len(x['selected']) if 'selected'in x else True) for x in out), 'focused_checks_failed'
