import hashlib,json,pathlib,subprocess,shlex,time,uuid,re
s=pathlib.Path(__file__).resolve().parent;label='site-message-settings-'+uuid.uuid4().hex;name='light-media-'+label;directory='/vol2/1000/docker/light-media/owned-tests/'+label
image='sha256:c83674e1999044d33d751661371b873539f47e5b5c5ca3320c7e0377acca6238';report={'state':'preflight','scope':'owned synthetic Go offline settings import, cold policy, actual SDK revocation, CLI; no real sites/downloader/media','network':'none','created_container':name,'runtime_directory':directory,'runs':[]}
def save():(s/'nas-verification.json').write_text(json.dumps(report,indent=2)+'\n')
def ssh(cmd,data=None,timeout=45):return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129',cmd],input=data,capture_output=True,timeout=timeout)
prefix='''import pathlib,subprocess,json,os,shutil,hashlib
def docker(*a):return subprocess.check_output(['sudo','-n','docker',*a],timeout=25)
b=pathlib.Path('/vol2/1000/docker/light-media')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def identity(n):
 x=json.loads(docker('inspect',n))[0];return {'id':x['Id'],'pid':x['State']['Pid'],'started':x['State']['StartedAt'],'restarts':x['RestartCount'],'running':x['State']['Running']}
'''
def remote(code):
 p=ssh('python3 -',(prefix+code).encode());assert p.returncode==0,'bounded_remote_inspection_failed';return json.loads(p.stdout)
made=created=False;start=time.monotonic()
try:
 report['before']=remote('''assert os.getuid()==1000 and os.getgid()==1001
assert int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024>=3*1024**3
assert os.getloadavg()[0]<5 and shutil.disk_usage(b).free>=2*1024**3
assert sha(b/'light-media-server')=='4e14738c14a243767389d754dd7220ab4ee199b057731160fa4986e9c32c047b'
assert sha(b/'compose.yaml')=='1d528665848dc02c3452a7254645dea519f35cf06f8a67da057ebde6a9ddff39'
print(json.dumps({n:identity(n) for n in ['light-media','moviepilot','qb']}))
''')
 assert report['before']['light-media']['id']=='beaede83591e8ed6d25bc532ec2b7bd537df0b1c0a2f8a5e7ba47eb3047df9e6' and report['before']['moviepilot']['id']=='cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a'
 remote('p=pathlib.Path('+repr(directory)+');assert not p.exists();p.mkdir(mode=0o700,parents=True);print("{}")\n');made=True;report['binaries']={}
 for source,target in [('app-linux.test','app.test'),('site-message-settings-migrate-owned-linux.test','cli.test')]:
  raw=(s/source).read_bytes();digest=hashlib.sha256(raw).hexdigest();code="import sys,pathlib,os,hashlib\np=pathlib.Path(%r);raw=sys.stdin.buffer.read();assert hashlib.sha256(raw).hexdigest()==%r\nfd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o700);os.fchmod(fd,0o700)\nwith os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())\n"%(directory+'/'+target,digest)
  p=ssh(shlex.join(['python3','-c',code]),raw);assert p.returncode==0,'owned_stage_failed';report['binaries'][target]=digest
 args=['sudo','-n','docker','create','--name',name,'--label','light-media.owned-test='+label,'--log-driver','none','--read-only','--network','none','--cpus','1','--memory','512m','--pids-limit','128','--user','1000:1001','--mount','type=bind,src='+directory+',dst=/verify,readonly','--tmpfs','/tmp:rw,size=256m,mode=1777','--entrypoint','/bin/sh',image,'-c','/verify/app.test -test.v -test.timeout=180s -test.run="^Test(ReviewedSourceSettings|ReviewedSiteMessageSettings|SiteMessageImportedSettingActualSDKAndRevocation|SiteStatisticAPIRevocationBeforeMessageReadStopsSideEffect|SiteStatisticConnectionTestDoesNotReadMessages|SiteStatisticJobCancellationBeforeMessageReadStopsSideEffect)" && /verify/cli.test -test.v -test.timeout=90s']
 p=ssh(shlex.join(args));assert p.returncode==0,'owned_create_failed';created=True;report['container_id']=p.stdout.decode().strip();report['state']='running_owned_synthetic';save();print(json.dumps({'state':report['state'],'network':'none'}),flush=True)
 p=ssh(shlex.join(['sudo','-n','docker','start','-a',name]),timeout=300);log=p.stdout+p.stderr;(s/'nas-selected.log').write_bytes(log);report['runs'].append({'exit':p.returncode,'top_pass':len(re.findall(rb'^--- PASS:',log,re.M)),'inclusive_pass':len(re.findall(rb'^\s*--- PASS:',log,re.M)),'fail':len(re.findall(rb'^\s*--- FAIL:',log,re.M)),'sha256':hashlib.sha256(log).hexdigest()})
 report['execution']=remote('x=json.loads(docker("inspect",'+repr(name)+'))[0];print(json.dumps({"exit_code":x["State"]["ExitCode"],"oom_killed":x["State"]["OOMKilled"],"running":x["State"]["Running"],"pid":x["State"]["Pid"],"network":x["HostConfig"]["NetworkMode"],"memory_limit":x["HostConfig"]["Memory"],"cpu_limit":x["HostConfig"]["NanoCpus"]}))\n')
 assert p.returncode==0 and report['execution']['exit_code']==0 and not report['execution']['oom_killed'] and report['execution']['pid']==0 and not report['runs'][0]['fail'],'owned_tests_failed'
 report['state']='passed_owned_linux_synthetic'
except BaseException as e:
 report['state']='failed';report['error_class']=type(e).__name__;raise
finally:
 if created:
  report.update(remote('x=json.loads(docker("inspect",'+repr(name)+'))[0];assert x["Config"]["Labels"]["light-media.owned-test"]=='+repr(label)+' and x["Image"]=='+repr(image)+'\nif x["State"]["Running"]:docker("stop","-t","5",'+repr(name)+')\ndocker("rm",'+repr(name)+');print(json.dumps({"owned_container_removed":True}))\n'))
 if made:
  report.update(remote('p=pathlib.Path('+repr(directory)+');assert p.is_dir() and not p.is_symlink()\nfor f in p.iterdir():\n assert f.name in ["app.test","cli.test"] and f.is_file() and not f.is_symlink();f.unlink()\np.rmdir();assert not p.exists();print(json.dumps({"owned_runtime_directory_removed":True}))\n'))
 report['after']=remote('print(json.dumps({n:identity(n) for n in ["light-media","moviepilot","qb"]}))\n');report['original_and_production_containers_unchanged']=report.get('before')==report['after']
 report['production_hashes_unchanged']=remote('assert sha(b/"light-media-server")=="4e14738c14a243767389d754dd7220ab4ee199b057731160fa4986e9c32c047b";assert sha(b/"compose.yaml")=="1d528665848dc02c3452a7254645dea519f35cf06f8a67da057ebde6a9ddff39";print("true")\n')
 report['elapsed_seconds']=round(time.monotonic()-start,2);save();print(json.dumps({'state':report['state'],'runs':report['runs'],'cleanup':bool(report.get('owned_container_removed') and report.get('owned_runtime_directory_removed'))}),flush=True)
