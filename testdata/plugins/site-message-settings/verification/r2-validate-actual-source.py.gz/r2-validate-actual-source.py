import pathlib,json,subprocess,hashlib
s=pathlib.Path(__file__).resolve().parent;producer=(s.parent/'r1/capture-selected.py').read_bytes();expected='0d1020215c3187d16580fcff7a4f207bf1e75a06a75ab4b34902bf99216d36f6';assert hashlib.sha256(producer).hexdigest()==expected
host='admin@192.168.8.129';cid='cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a'
def ssh(cmd,data=None):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5',host,cmd],input=data,capture_output=True,timeout=35);assert p.returncode==0,'bounded_source_read_failed';return p.stdout
def identity():
 raw=ssh("sudo -n docker inspect --format '{{.Id}} {{.State.Pid}} {{.State.StartedAt}} {{.RestartCount}}' moviepilot");p=raw.decode().strip().split();assert p[0]==cid and len(p)==4;return p
before=identity();last=None;validated=[]
for _ in range(2):
 raw=ssh('sudo -n docker exec -i '+cid+' /opt/venv/bin/python -I -B - --capture',producer);v=json.loads(raw)
 assert last is None or v==last,'cold_selected_source_changed';last=v
 p=subprocess.run([str(s/'site-message-settings-migrate-owned'),'--validate-input'],input=raw,capture_output=True,timeout=15)
 assert p.returncode==0 and not p.stderr,'native_input_validation_failed';result=json.loads(p.stdout)
 assert result=={'state':'validated','source_mode':'selected_installed_cold_site_message_not_live_cache','records':1,'writes':0,'jobs_queued':0,'external_calls':0},'native_summary_changed';validated.append(result)
assert identity()==before,'original_identity_changed'
report={'state':'actual_cold_selected_input_validated_not_imported','original_identity_unchanged':True,'captures_equal':True,'original_config_unchanged':last['original_config_unchanged'],'original_app_imports':last['original_app_imports'],'original_settings_constructors':last['original_settings_constructors'],'audit':last['audit'],'source_mode':last['mode'],'selected_boolean':last['site_message'],'normalization_fields':last['normalization_fields'],'source_hashes':last['source_hashes'],'env_sha256':last['env_sha256'],'producer_sha256':expected,'native_cli_sha256':hashlib.sha256((s/'site-message-settings-migrate-owned').read_bytes()).hexdigest(),'native_validations':validated,'target_opened':False,'private_configuration_saved':False,'migrated':False}
(s/'actual-source-validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'state':report['state'],'captures':2,'target_opened':False,'original_unchanged':True}))
