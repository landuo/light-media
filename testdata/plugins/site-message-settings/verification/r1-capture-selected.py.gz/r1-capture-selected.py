"""One-purpose read-only migration producer, run by python -B through stdin.

MoviePilot is never imported. --fixture consumes synthetic JSON; --capture emits
private selected settings only through stdout for an encrypted target writer.
The real Settings.__init__, API_TOKEN validator and env writer are not executed.
"""
import ast
import copy
import hashlib
import io
import importlib.metadata
import json
import os
import pathlib
import platform
import sys
import types
import uuid
import warnings
from typing import Any, Dict, List, Optional, Tuple, Type, Union, get_args, get_origin

from pydantic import BaseModel, ConfigDict, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

FIELDS = ('CONFIG_DIR', 'SITE_MESSAGE')
HASHES = {
    '/app/app/core/config.py': 'f19111073a7ef25ecd0b7e9d53dab343d76fe64ff3ad821f4ff39a790c104033',
    '/app/app/utils/system.py': '3477c8585dd955bcb42f7180e5fabaae05c528af8ddb0cbae0935dbdb0c031db',
    '/app/app/helper/server.py': 'd71d14373d8984390c6b7a6669ce6f6ffc4258fcf5f163ee189c52c8d3b0d47f',
    '/app/version.py': '02e895f5f3678698656958e333a7eb03b81280aa196ed39bf60974529ec6a1e4',
    '/opt/venv/lib/python3.12/site-packages/tzlocal/__init__.py': 'a6d7c04d705c6d917d62eaedfd73b1d72bc6044dafebc358b701b84bd567d181',
    '/opt/venv/lib/python3.12/site-packages/tzlocal/unix.py': '68e936f6076c4dac8c9e8a4a76fb6a7cec73f38294ee7dd92d493d03f15bd876',
    '/opt/venv/lib/python3.12/site-packages/tzlocal/utils.py': 'a2ff1f3f03e3caf5d1a96f56cf1fec9004ec8e207d800ccad42107276508f756',
}
PROXY_NAMES = {'HTTP_PROXY', 'http_proxy', 'HTTPS_PROXY', 'https_proxy', 'ALL_PROXY', 'all_proxy', 'NO_PROXY', 'no_proxy'}
COUNTERS = {'denied_writes': 0, 'denied_network': 0, 'denied_processes': 0}
FIXTURE = sys.argv[1:] == ['--fixture']
CAPTURE = sys.argv[1:] == ['--capture']


def audit(event, args):
    if event == 'open':
        path, mode, flags = args
        if (isinstance(mode, str) and any(c in mode for c in 'wax+')) or (isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)):
            COUNTERS['denied_writes'] += 1
            raise RuntimeError('write_denied')
        if FIXTURE and str(path).endswith('/app.env'):
            raise RuntimeError('real_configuration_read_in_fixture')
    if event in {'os.remove', 'os.rmdir', 'os.mkdir', 'os.rename', 'os.chmod', 'os.chown', 'os.symlink', 'os.link', 'os.truncate', 'os.putenv', 'os.unsetenv'}:
        COUNTERS['denied_writes'] += 1
        raise RuntimeError('write_denied')
    if event.startswith('socket.') and event not in {'socket.__new__'}:
        COUNTERS['denied_network'] += 1
        raise RuntimeError('network_denied')
    if event in {'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn'}:
        COUNTERS['denied_processes'] += 1
        raise RuntimeError('process_denied')


sys.addaudithook(audit)
warnings.simplefilter('ignore')


class QuietLog:
    def error(self, *args, **kwargs):
        pass


def load_reviewed_source():
    trees = {}
    for name, expected in HASHES.items():
        if name not in ('/app/app/core/config.py','/app/app/utils/system.py'): continue
        raw = pathlib.Path(name).read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected:
            raise RuntimeError('reviewed_source_changed')
        trees[name] = ast.parse(raw)
    return trees


def member(node, name):
    for child in node.body:
        key = getattr(child, 'name', None)
        if isinstance(child, ast.AnnAssign) and isinstance(child.target, ast.Name):
            key = child.target.id
        if isinstance(child, ast.Assign) and len(child.targets) == 1 and isinstance(child.targets[0], ast.Name):
            key = child.targets[0].id
        if key == name:
            return copy.deepcopy(child)
    raise RuntimeError('selected_member_missing')


def class_node(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)


def compact(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'), sort_keys=True).encode()


def derive(trees, fixture=None):
    settings_source=class_node(trees['/app/app/core/config.py'],'Settings')
    model_source=class_node(trees['/app/app/core/config.py'],'ConfigModel')
    system_source=class_node(trees['/app/app/utils/system.py'],'SystemUtils')
    corrections=[]
    namespace=dict(BaseModel=BaseModel,ConfigDict=ConfigDict,BaseSettings=BaseSettings,SettingsConfigDict=SettingsConfigDict,model_validator=model_validator,Any=Any,Dict=Dict,List=List,Optional=Optional,Tuple=Tuple,Type=Type,Union=Union,get_origin=get_origin,get_args=get_args,Path=pathlib.Path,os=os,sys=sys,copy=copy,json=json,logger=QuietLog(),__file__='/app/app/core/config.py',FIELDS=FIELDS,corrections=corrections)
    system=ast.ClassDef(name='SystemUtils',bases=[],keywords=[],body=[member(system_source,key) for key in ('is_docker','is_frozen','get_config_path','get_env_path')],decorator_list=[])
    config=ast.ClassDef(name='SelectedConfigModel',bases=[ast.Name(id='BaseModel',ctx=ast.Load())],keywords=[],body=[member(model_source,'model_config')]+[member(model_source,key) for key in FIELDS],decorator_list=[])
    selected=ast.ClassDef(name='SelectedSettings',bases=[ast.Name(id='BaseSettings',ctx=ast.Load()),ast.Name(id='SelectedConfigModel',ctx=ast.Load())],keywords=[],body=[member(settings_source,key) for key in ('model_config','generic_type_converter','generic_type_validator')],decorator_list=[])
    selected.body+=ast.parse('''
@classmethod
def update_env_config(cls,name,before,after):
    if name not in FIELDS: raise RuntimeError('unselected_conversion')
    corrections.append(name)
@classmethod
def settings_customise_sources(cls,settings_cls,init_settings,env_settings,dotenv_settings,file_secret_settings):
    if fixture_sources is not None:
        return tuple((lambda source=source:{k:v for k,v in source.items() if k in FIELDS}) for source in fixture_sources)
    return tuple((lambda source=source:{k:v for k,v in source().items() if k in FIELDS}) for source in (init_settings,env_settings,dotenv_settings,file_secret_settings))
''').body
    namespace['fixture_sources']=None if fixture is None else [fixture.get('init',{}),fixture.get('environment',{}),fixture.get('dotenv',{}),fixture.get('secrets',{})]
    m=ast.Module(body=[system,config,selected],type_ignores=[]);exec(compile(ast.fix_missing_locations(m),'<reviewed-site-message-settings>','exec'),namespace)
    model=namespace['SelectedSettings']() if fixture is None else namespace['SelectedSettings'](_env_file=None)
    return dict(site_message=model.SITE_MESSAGE,normalization_fields=sorted(set(corrections)))

def main():
    if not FIXTURE and not CAPTURE:raise RuntimeError('explicit_mode_required')
    trees=load_reviewed_source()
    if FIXTURE:
        cases=[]
        for c in json.loads(sys.stdin.read())['cases']:
            try:cases.append(dict(name=c['name'],value=derive(trees,c)))
            except Exception as e:cases.append(dict(name=c['name'],error_class=type(e).__name__))
        result=dict(mode='synthetic_selected_original_SITE_MESSAGE',cases=cases,real_config_read=False,audit=COUNTERS)
    else:
        p=pathlib.Path('/config/app.env')
        if p.is_symlink() or not p.is_file():raise RuntimeError('env_source_changed')
        before=p.read_bytes();a=derive(trees);b=derive(trees)
        if a!=b or p.read_bytes()!=before:raise RuntimeError('source_changed_during_capture')
        result=dict(version=1,mode='selected_installed_cold_site_message_not_live_cache',known=True,site_message=a['site_message'],normalization_fields=a['normalization_fields'],source_hashes={k:HASHES[k] for k in ('/app/app/core/config.py','/app/app/utils/system.py')},env_path='/config/app.env',env_sha256=hashlib.sha256(before).hexdigest(),captures_equal=True,original_config_unchanged=True,original_app_imports=0,original_settings_constructors=0,audit=COUNTERS)
    if any(COUNTERS.values()):raise RuntimeError('audit_failed')
    print(json.dumps(result,separators=(',',':')))
try:main()
except BaseException as e:
    sys.stderr.write('site_message_capture_failed:'+type(e).__name__+'\n');sys.exit(1)
