"""Installed complete NexusPHP/HHan parser methods, isolated synthetic HTTP."""
import ast,sys,json,hashlib,copy,re,io,contextlib
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime
from urllib import parse
from urllib.parse import urlsplit,urljoin,parse_qsl,urlencode,urlunsplit
from abc import ABCMeta,abstractmethod
from enum import Enum
from typing import Optional,Any,Union,Dict,List,Tuple
from pydantic import BaseModel,Field,ConfigDict
from pyquery import PyQuery
from lxml import etree
import dateparser as original_dateparser
def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('side_effect_denied')
 if event=='open' and ((isinstance(args[1],str) and any(c in args[1] for c in 'wax+')) or (isinstance(args[2],int) and args[2]&(1|2|64|512))):raise RuntimeError('write_denied')
sys.addaudithook(audit)
class Quiet:
 def __getattr__(self,n):return lambda *a,**k:None
class FixedDatetime(datetime):
 @classmethod
 def now(cls,*args,**kwargs):return cls(2026,10,21,12,34,56)
sources={};ns=dict(globals());ns.update(logger=Quiet(),Session=object,datetime=FixedDatetime,settings=SimpleNamespace(SITE_MESSAGE=False,PROXY=None,ENCODING_DETECTION_PERFORMANCE_MODE=True,ENCODING_DETECTION_MIN_CONFIDENCE=0.5),dateparser=SimpleNamespace(parse=lambda text:original_dateparser.parse(text,settings={'RELATIVE_BASE':datetime(2026,10,21,12,34,56)})))
def tree(path):
 raw=(Path('/app')/path).read_bytes();sources[path]=hashlib.sha256(raw).hexdigest();return ast.parse(raw)
def execute(nodes):
 m=ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[]));exec(compile(m,'<installed-owned-nexus-oracle>','exec'),ns)
def loadclass(path,name,methods=None):
 n=next(n for n in tree(path).body if isinstance(n,ast.ClassDef) and n.name==name)
 if methods is not None:n.body=[n for n in n.body if isinstance(n,ast.FunctionDef) and n.name in methods];n.bases=[];n.keywords=[]
 execute([n]);return ns[name]
st=tree('app/utils/string.py');execute([next(n for n in st.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_special_domains' for t in n.targets))])
loadclass('app/utils/string.py','StringUtils',['get_url_domain','get_url_netloc','num_filesize','str_int','str_float','unify_datetime_str','is_valid_html_element'])
cf=tree('app/helper/cloudflare.py');execute([n for n in cf.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['CHALLENGE_TITLES','CHALLENGE_SELECTORS'] for t in n.targets) or isinstance(n,ast.FunctionDef) and n.name=='under_challenge'])
loadclass('app/utils/site.py','SiteUtils')
loadclass('app/schemas/site.py','SiteUserData')
base='app/modules/indexer/parser/__init__.py';execute([next(n for n in tree(base).body if isinstance(n,ast.ClassDef) and n.name=='SiteSchema')]);loadclass(base,'SiteParserBase')
nexus=loadclass('app/modules/indexer/parser/nexus_php.py','NexusPhpSiteUserInfo');hhan=loadclass('app/modules/indexer/parser/nexus_hhanclub.py','NexusHhanclubSiteUserInfo')
module=loadclass('app/modules/indexer/__init__.py','IndexerModule',['refresh_userdata'])
trace=[];positions={};responses={};unexpected=[]
class Response:
 def __init__(self,v):self.status_code=v['status'];self.text=v['body']
 def json(self):return json.loads(self.text)
class RequestUtils:
 def __init__(self,**kwargs):self.options=kwargs
 @staticmethod
 def get_decoded_html_content(response,*args):return response.text
 def _call(self,method,url,kwargs):
  u=urlsplit(url);key=u.path+('?' + u.query if u.query else '');index=positions.get(key,0);positions[key]=index+1
  kind='json' if 'json' in kwargs else 'form' if 'data' in kwargs else 'none'
  body=copy.deepcopy(kwargs.get('json') if kind=='json' else {k:[str(v)] for k,v in (kwargs.get('data') or {}).items() if v is not None} if kind=='form' else None)
  headers=copy.deepcopy(self.options.get('headers') or {});headers['Cookie']=self.options.get('cookies')
  trace.append(dict(method=method,url=url,headers=headers,body_kind=kind,body=body,timeout=self.options['timeout']))
  items=responses.get(key,[])
  if index>=len(items):unexpected.append(key);raise RuntimeError('owned_reply_exhausted')
  return Response(items[index])
 def post_res(self,url,**kwargs):return self._call('POST',url,kwargs)
 def get_res(self,url,**kwargs):return self._call('GET',url,kwargs)
ns['RequestUtils']=RequestUtils
def reply(body='',status=200):return dict(status=status,body=body)
nav='<a href="logout.php">out</a><a href="userdetails.php?id=7"><b> self </b></a>'
home=nav+'<div>上传量：2 GB 下载量：1 GB 分享率：2.00 下载中：2 <i>end</i></div><a href="mybonus.php">12.5</a>'
detail='<table><tr><td>等级</td><td><img title="Power User"></td></tr><tr><td>加入日期</td><td>2024-01-02T03:04:05 (2 years ago)</td></tr></table>'
def seeds(rows=None,next=''):
 rows=[(1024,3),(2048,4)] if rows is None else rows
 return '<table class="torrents"><tr><td>名称</td><td>大小</td><td>类型</td><td>在做种</td></tr>'+''.join('<tr><td>owned</td><td>'+str(size)+' B</td><td>video</td><td><b><a>'+str(peers)+'</a></b></td></tr>' for size,peers in rows)+'</table>'+next
cases=[]
def case(name,root=None,prof=None,seed=None,extra=None,read=False,kind='NexusPhp'):
 responses.clear();positions.clear();trace.clear();unexpected.clear()
 responses.update({'/':[root or reply(home)],'/userdetails.php?id=7':[prof or reply(detail)],'/getusertorrentlistajax.php?userid=7&type=seeding':[seed or reply(seeds())]})
 responses.update(extra or {});inputs=copy.deepcopy(responses);ns['settings'].SITE_MESSAGE=read
 m=module();m._site_schemas=[nexus,hhan];data=None;error=None;captured=io.StringIO()
 with contextlib.redirect_stdout(captured):
  try:data=m.refresh_userdata(dict(name='owned',url='https://owned.example/',schema=kind,cookie='synthetic-cookie=1',ua='synthetic-cookie-UA'))
  except Exception as e:error=type(e).__name__
 assert not unexpected,(name,unexpected)
 cases.append(dict(name=name,kind=kind,read_messages=read,replies=inputs,requests=copy.deepcopy(trace),data=data.model_dump() if data is not None else None,error_type=error,source_stdout=captured.getvalue()))
case('root-profile-and-seed')
case('next-page-fixup-and-detail-link-skip',seed=reply(seeds([(100,2)],'<a href="getusertorrentlistajax.php?page=1">下一页</a><a href="details.php?id=9">&gt;</a>')),extra={'/getusertorrentlistajax.php?page=1&userid=7&type=seeding':[reply(seeds([(200,3)]))]})
case('extended-seeding-page',seed=reply('<a href="torrents.php?seeding=1">extended</a>'),extra={'/torrents.php?seeding=1':[reply(seeds())]})
case('direct-seeding-page-from-profile',prof=reply(detail+'<a href="getusertorrentlist.php?type=seeding&userid=7">seed</a>'),extra={'/getusertorrentlist.php?type=seeding&userid=7':[reply(seeds())]})
case('csrf-post-from-profile',prof=reply(detail+'<meta name="x-csrf" content="synthetic-csrf"><a href="javascript: getusertorrentlistajax(\'7\',\'seeding\')">seed</a>'),extra={'/ajax_getusertorrentlist.php':[reply(seeds())]})
case('js-ID-recovery-does-not-use-csrf',root=reply('<a href="logout.php">out</a><a href="userdetails">self</a>'),extra={'/userdetails':[reply('<meta name="x-csrf" content="synthetic-csrf"><a href="javascript: getusertorrentlistajax(\'7\',\'seeding\')">seed</a>')]})
case('profile-summary-plus-page-count',prof=reply(detail+'<table><tr><td>做种统计</td><td>总做种数: 10 总做种体积: 1 GB</td></tr></table>'))
upload_table='<table><tr><td>当前上传</td><td><table><tr><td>name</td><td>x</td><td>y</td><td>尺寸</td><td>做种者</td></tr><tr><td>owned</td><td>x</td><td>y</td><td>100 B</td><td>2</td></tr></table></td></tr></table>'
case('profile-fallback-rows-plus-page',prof=reply(detail+upload_table))
case('explicit-tbody-preserved',prof=reply(detail+upload_table.replace('<tr>','<tbody><tr>',1).replace('</table>','</tbody></table>',1)))
case('coin-last-text-and-exact-class',root=reply(home+'<span class="ucoin-symbol ucoin-gold">1<b>2</b>tail</span><span class="ucoin-symbol ucoin-silver">3</span><span class="ucoin-symbol ucoin-copper">4</span>'))
case('detail-bonus-fallback',root=reply(nav+'<div>上传：1 GB 下载：2 GB</div>'),prof=reply(detail+'<table><tr><td>猫粮</td><td>32.5</td></tr></table>'))
case('ratio-infinity-is-calculated',root=reply(nav+'<div>上传：667 B 下载：2000 B 分享率：∞</div>'))
case('logged-out-error-DTO',root=reply('<input type="password">'))
case('HTTP500-body-accepted',root=reply(home,500))
case('HTTP503-profile-is-empty',prof=reply('unavailable',503))
case('password-profile-is-not-login-tested-again',prof=reply('<input type="password">'))
case('invalid-size-and-seeders-default',seed=reply(seeds([('bad','bad')])))
case('short-seeder-array-throws',seed=reply('<table class="torrents"><tr><td>name</td><td>大小</td><td>type</td><td>在做种</td></tr><tr><td>a</td><td>1 B</td><td>v</td><td>1</td></tr><tr><td>b</td><td>2 B</td><td>v</td><td></td></tr></table>'))
case('existing-userid-next-query-is-not-rewritten',seed=reply(seeds([(10,1)],'<a href="?page=2&userid=99">下一页</a>')),extra={'/getusertorrentlistajax.php?page=2&userid=99':[reply(seeds([(20,2)]))]})
case('strong-username-overrides-direct-text',root=reply('<a href="logout.php">out</a><a href="userdetails.php?id=7">direct</a><a href="userdetails.php?id=9"><strong> other </strong></a><div>上传：1 GB 下载：2 GB</div>'))
panel='<div id="user-info-panel"><div></div><div><div><div><div>分享率: 99</div></div></div><div><div></div><div></div><div></div><div> 1.5 TiB</div><div> 256 GiB</div></div></div></div>'
case('hhan-exact-panel',kind='NexusHhanclub',root=reply(home+panel),prof=reply(detail+'<b class="Power_Name"> Hhan User </b><span>加入日期</span><span><span title="2024年1月2日 03:04:05"></span></span>'))
case('hhan-missing-panel-throws',kind='NexusHhanclub')
case('date-relative-clock',prof=reply('<table><tr><td>加入日期</td><td>2 days ago</td></tr></table>'))
case('date-invalid-is-retained',prof=reply('<table><tr><td>加入日期</td><td>not_a_date</td></tr></table>'))
msg1='messages.php?action=viewmailbox&box=1&unread=yes';msg2='messages.php?action=viewmailbox&box=-2&unread=yes'
content='messages.php?action=viewmessage&id=1'
inbox='<table><tr><td><a href="'+content+'">new</a></td></tr><tr><td><img alt="Read"><a href="messages.php?action=viewmessage&id=2">old</a></td></tr></table>'
message='<h1> heading </h1><table><tr><td class="colhead">head</td></tr><tr><td>date</td><td> 2026-10-21 </td></tr><tr><td> body <b>bold</b> tail </td></tr></table>'
case('messages-box-order-is-unspecified',root=reply(home+'<span><a href="messages.php">信息箱</a> (1)</span>'),read=True,extra={'/'+msg1:[reply(inbox)],'/'+msg2:[reply('')],'/'+content:[reply(message)]})
case('message-duplicates-and-null-content',root=reply(home+'<span><a href="messages.php">信息箱</a> (2)</span>'),read=True,extra={'/'+msg1:[reply(inbox+inbox)],'/'+msg2:[reply('')],'/'+content:[reply('<h1> title </h1>'),reply('<h1> title </h1>')]})
case('all-native-values-unknown',root=reply(nav),prof=reply(''),seed=reply(''))
print(json.dumps(dict(scope='installed complete NexusPHP/HHan/BaseParser and Indexer DTO, mocked HTTP only; source dateparser clock explicitly pinned; unordered user/system mailbox groups normalized in comparisons',clock='2026-10-21T12:34:56+08:00',source_dateparser_version=original_dateparser.__version__,source_sha256=sources,cases=cases),ensure_ascii=False,separators=(',',':')))
