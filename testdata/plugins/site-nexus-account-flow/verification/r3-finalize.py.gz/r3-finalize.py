import pathlib,subprocess,json,hashlib,re,urllib.parse,base64,gzip
root=pathlib.Path('/Users/accidia/projects/light-media');s=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((s/n).read_text())
statuses={n:read(n) for n in ['sites-status.json','actual-status.json','build-normal-status.json','build-race-status.json','build-linux-status.json']}
for name,values in statuses.items():
 assert values and all(x['exit']==0 for x in values),name
 if name in ['sites-status.json','actual-status.json']:assert len(values)==2
first=read('related-status.json');assert len(first)==2 and first[0]['exit']==0 and first[1]['exit']==2
splits=read('related-race-split-status.json');groups=read('related-race-groups.json');assert len(splits)==3 and all(x['exit']==0 and x['top_pass']==len(x['selected']) for x in splits)
assert sorted(n for x in splits for n in x['selected'])==sorted(groups['names']) and len(groups['names'])==48
statuses['related-normal']=[first[0]];statuses['related-race-groups']=splits
nas=read('nas-verification.json');assert nas['state']=='passed_owned_linux_business' and nas['owned_container_removed'] and nas['owned_runtime_directory_removed'] and nas['original_and_production_containers_unchanged'];assert not nas['execution']['oom_killed'] and nas['execution']['exit_code']==0
cleanup=read('nas-independent-cleanup.json');assert all(cleanup.values())
checks={}
for name in ['sites-normal','sites-race','related-normal','related-race-split-nexus','related-race-split-mteam','related-race-split-remaining','actual-normal','actual-race','nas-selected']:
 b=(s/(name+'.log')).read_bytes();v={k:len(re.findall(pattern,b,re.M)) for k,pattern in [('top_pass',rb'^--- PASS:'),('inclusive_pass',rb'^\s*--- PASS:'),('fail',rb'^\s*--- FAIL:'),('skip',rb'^\s*--- SKIP:')]};v['sha256']=hashlib.sha256(b).hexdigest();assert not v['fail'] and not v['skip'];checks[name]=v
assert checks['nas-selected']['inclusive_pass']==85
sources=read('SOURCE-INPUTS.json');inputs=read('COMPILATION-INPUTS.json')
assert all(hashlib.sha256((s/'app'/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in sources)
for x in inputs:
 p=s/'app'/x['path'][5:] if x['path'].startswith('repo/') else pathlib.Path(x['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
paths=set(p.decode() for p in subprocess.check_output(['git','ls-files','-mo','--exclude-standard','-z'],cwd=root).split(b'\0') if p)
focus=sorted(n for n in paths if n.startswith('internal/') or n in ['go.mod','go.sum','testdata/plugins/site-nexus-account-original-oracle.json'])
manifest={x['path']:x['sha256'] for x in sources};assert all(manifest[n]==hashlib.sha256((root/n).read_bytes()).hexdigest() for n in focus)
drift={'frozen_source_files':len(sources),'resolved_compilation_files':len(inputs),'frozen_drift':0,'compilation_drift':0,'main_product_focus_drift':0,'docs_written_after_checks':['docs/plugin-site-nexus-account-flow.txt','docs/plugin-site-nexus-account-flow-verification.json','docs/plugin-installed-migration-baseline.md'],'scope_limit':'does not claim complete compiler, system header or linker dependency closure'}
(s/'DRIFT-REVIEW.json').write_text(json.dumps(drift,indent=2)+'\n')
web=[x for x in sources if x['path'].startswith('web/')];assert all((root/x['path']).read_bytes()==(s/'app'/x['path']).read_bytes() for x in web)
files=sorted(p for d in [s,s.parent/'r1',s.parent/'r2'] for p in d.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log','.stderr'])
docs=[root/'docs/plugin-site-nexus-account-flow.txt',root/'docs/plugin-installed-migration-baseline.md']
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(root/'work/_site_statistic_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=35);assert r.returncode==0,'readonly_final_source_scan_failed';v=json.loads(r.stdout);needles=set();secrets=set()
def walk(v,k=''):
 if isinstance(v,dict):
  for key,x in v.items():walk(x,key.lower())
 elif isinstance(v,list):
  for x in v:walk(x,k)
 elif isinstance(v,str):
  if v[:1] in ('{','['):
   try:walk(json.loads(v),k)
   except (ValueError,TypeError):pass
  if len(v)>=6 and any(x in k for x in ['password','cookie','token','apikey','api_key','passkey','authorization','secret']):secrets.add(v)
  for url in re.findall(r'https?://[^\s<>"\']+',v):
   for key,vals in urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).items():
    if any(x in key.lower() for x in ['passkey','token','auth','key']):secrets.update(x for x in vals if len(x)>=6)
walk(v)
for raw in v['account_rows']:
 needles.add(raw.encode());row=json.loads(raw)
 for key in ['username','userid']:
  value=row.get(key)
  if isinstance(value,str) and value:
   needles.update([('"'+key+'":'+json.dumps(value,ensure_ascii=False)).encode(),('"'+key+'": '+json.dumps(value,ensure_ascii=False)).encode()])
   if len(value)>=6:
    q=json.dumps(value,ensure_ascii=False);needles.update([q.encode(),json.dumps(q,ensure_ascii=False)[1:-1].encode()])
for value in secrets:needles.update(x.encode() for x in [value,urllib.parse.quote(value,safe=''),base64.b64encode(value.encode()).decode()])
for p in files+docs+[root/n for n in focus]:assert not any(x in p.read_bytes() for x in needles),'private_source_material_detected_no_archive_written'
oracle=json.loads((root/'testdata/plugins/site-nexus-account-original-oracle.json').read_text())
report={'version':1,'date':'2026-10-21','base_commit':'d1bbd6743672b7d18219b67ffaac455b09306fac','state':'NexusPHP_HHan_source_account_flow_verified_not_full_plugin_migration','actual_complete':7,'remaining':16,'production_version':'0.4.8','deployed':False,'original_mutations':0,'production_mutations':0,'real_execution_handoffs':0,'real_user_site_downloader_media_or_notification_business_calls':0,'python_runtime_dependency_added':False,'source_account_rows':len(v['account_rows']),'source_nexus_flow_oracle':{'cases':len(oracle['cases']),'source_sha256':oracle['source_sha256'],'scope':oracle['scope'],'fixture_sha256':hashlib.sha256((root/'testdata/plugins/site-nexus-account-original-oracle.json').read_bytes()).hexdigest()},'implementation':{'independent_source_collector_not_native_projection':True,'original_home_profile_messages_seed_order':True,'literal_original_XPath_and_raw_regex':True,'HTML5_implicit_tbody_removed_explicit_tbody_preserved':True,'original_hhan_panel_exceptions':True,'detail_link_CSRF_and_JS_ID_branching':True,'seed_extension_page_and_original_next_query_fixup':True,'original_summary_plus_rows_accumulation':True,'mailbox_phase_order_and_duplicate_null_contents':True,'unordered_source_mailboxes_normalized_in_oracle_only':True,'HTTP_200_403_500_and_empty_body_branches':True,'GBK_decoding':True,'source_host_timezone_and_relative_join_date':True,'DTO_defaults_separate_from_native_unknowns':True,'guard_revocation_cancellation_and_page_limits':True,'actual_Go_SDK_events_and_encrypted_cold_lost_ACK':True,'existing_notification_receipt_three_request_regression':True,'original_dateparser_version':oracle['source_dateparser_version'],'go_dateparser_version':'1.4.7','all_rare_date_strings_proven':False},'checks':checks,'statuses':statuses,'nas':nas,'independent_cleanup':cleanup,'inputs':drift,'source_manifest_sha256':hashlib.sha256((s/'SOURCE-INPUTS.json').read_bytes()).hexdigest(),'compilation_manifest_sha256':hashlib.sha256((s/'COMPILATION-INPUTS.json').read_bytes()).hexdigest(),'focus':[{'path':n,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()} for n in focus],'frontend':{'changed':False,'retested':False,'same_as_base_commit':True,'verified_file_count':len(web),'user_acceptance_claimed':False},'production_peak_RSS_measured':False,'native_package_init_comparison':read('native-package-init-comparison.json'),'secret_scan':{'passed':True,'source_account_rows':len(v['account_rows']),'patterns':len(needles),'files':len(files+docs+focus),'private_payload_saved':False},'failures_retained':[{'scope':'r3 final proof packaging','cause':'Copied finalizer still targeted existing MTeam evidence folder; exclusive mkdir refused before writes. Corrected to new Nexus folder; existing evidence unchanged. All test/source/private scans had passed.','accepted':False},{'scope':'r3 combined related race','cause':'600-second aggregate deadline reached while running Nexus case25 of27; 15top95inclusive passes, no assertion or race failure before panic. Same unchanged frozen binary rerun as three exact disjoint groups; combined timeout remains archived, not called a combined pass.','accepted':False},{'scope':'r1 wire','cause':'Empty HTTP200 response hit charset EOF; corrected empty body handling before fixtures passed.','accepted':False},{'scope':'r1 compile','cause':'Removed approximate sourceAccountDOM still referenced by native collector; restored native pageDOM without changing original source flow.','accepted':False},{'scope':'r1 app fixtures','cause':'Earlier simplified fixtures expected /index.php, two requests and native headers; updated to actual source root/profile/seeding flow and literal seed columns.','accepted':False},{'scope':'r2 related normal','cause':'Existing notification/recovery fixture still expected old root and two requests; corrected in formal root then froze r3. All notification and recovery assertions retained. r2 race not started after normal failure.','accepted':False}],'remaining':['Optimize the measured approximately 50MiB native package initialization RSS increase from date parsing dependency before final production delivery.','Other non-Nexus/HHan special site parsers and all rare lxml/date/Pydantic/large integer cases are not universally proven.','Actual configured SitesHelper catalog/schema/alias context and Go integration; independent synthetic compiled evidence exists separately.','SystemError event and full source site-message/statistic notification producers/channels.','Global source setting import, final source binding, execution handoff and production migration; completed remains 7/23.']}
out=root/'docs/plugin-site-nexus-account-flow-verification.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');assert not any(x in out.read_bytes() for x in needles)
archive=root/'testdata/plugins/site-nexus-account-flow/verification';archive.mkdir(parents=True,exist_ok=False)
for p in files:
 (archive/(p.parent.name+'-'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(archive/'index.json').write_text(json.dumps({'files':[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(archive.iterdir())]},indent=2)+'\n')
print(json.dumps({'report':str(out),'proof_files':len(list(archive.iterdir())),'checks':checks,'secret_scan_passed':True,'actual_complete':7,'goal_complete':False}))
