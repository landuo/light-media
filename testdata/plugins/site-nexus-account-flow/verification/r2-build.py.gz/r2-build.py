import pathlib,subprocess,os,json,sys
stage=pathlib.Path(__file__).resolve().parent;group=sys.argv[1];cmds=[]
if group in ['normal','race']:
 flags=['-race'] if group=='race' else [];suffix='-race' if flags else ''
 cmds=[('app'+suffix,{},['go','test',*flags,'-c','-o',str(stage/('app'+suffix+'.test')),'./internal/app']),('statistic-migrate'+suffix,{},['go','build',*flags,'-o',str(stage/('statistic-migrate'+suffix)),'./cmd/site-statistic-migrate-owned']),('handoff'+suffix,{},['go','build',*flags,'-o',str(stage/('handoff'+suffix)),'./cmd/plugin-handoff-owned'])]
else:
 native={'CGO_ENABLED':'0'};linux={'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'}
 for n,env,pkg in [('server-native',native,'server'),('server-linux',linux,'server'),('statistic-migrate-linux',linux,'site-statistic-migrate-owned'),('handoff-linux',linux,'plugin-handoff-owned')]:cmds.append((n,env,['go','build','-trimpath','-o',str(stage/n),'./cmd/'+pkg]))
 cmds.extend([('app-linux',linux,['go','test','-c','-o',str(stage/'app-linux.test'),'./internal/app']),('vet',{},['go','vet','./internal/app','./internal/plugins/statistic','./cmd/site-statistic-migrate-owned','./cmd/plugin-handoff-owned']),('mod-verify',{},['go','mod','verify'])])
if group in ['normal','race']:
 cmds.append(('sites'+suffix,{},['go','test',*flags,'-c','-o',str(stage/('sites'+suffix+'.test')),'./internal/sites']))
out=[]
for name,env,cmd in cmds:
 with (stage/('build-'+name+'.log')).open('wb') as log:r=subprocess.run(cmd,cwd=stage/'app',env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT)
 out.append({'name':name,'exit':r.returncode});(stage/('build-'+group+'-status.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out[-1]),flush=True)
 if r.returncode:sys.exit(r.returncode)
