"""Actual disabled Category migration; original config stays in memory/stdin."""
import hashlib,json,pathlib,shlex,subprocess,sys,time
S=pathlib.Path(__file__).resolve().parent
HOST='admin@192.168.8.129'
BASE='/vol2/1000/docker/light-media'
RELEASE=BASE+'/releases/plugin-v040-category-20261020-4c1747'
EXPECTED_SERVER='7732dd6a7f7d3c85f41589a0aa7250c385bc1e1f33ef65857ebe8cd3b805ef22'
EXPECTED_TOOL='57ab17cd5982126bd0f30fcaae99bc2edfedb0f193c253a2b04dba054c5a7b9c'
CONFIG='59ce8c0dd98c95235ffffed7c8e091b0c72c59e92b7cc5e05aa45cfe822b6821'
POLICY='61502da87836ee756bdc8e5e3dad67d31893e517ba4c170a170ba8a9a695ac47'
EMITTER=S.parent/'_category_editor_delivery/revision2/emit-reviewed-original.py'
report={'stage':'preflight','migrated':False};stopped=False
def ssh(command,payload=None,timeout=60):
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',HOST,command],input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 if r.returncode:
  # Producer/tool outputs cannot be echoed on an exceptional path.
  raise RuntimeError('remote_command_failed_'+str(r.returncode))
 return r.stdout
def remote(code):return json.loads(ssh('python3 -',code.encode()))
def source_payload():
 b=EMITTER.read_bytes()
 assert hashlib.sha256(b).hexdigest()=='46ef1d2c49ee8b924cccd81802ba73097bcd8560fc47276d77ecfdae75ce462d'
 payload=ssh('sudo -n docker exec -i moviepilot python3 -B -',b)
 v=json.loads(payload)
 assert v['config_sha256']==CONFIG and v['content_sha256']==POLICY and v['kv_count']==0
 assert v['config']['enabled'] is False and set(v['config'])=={'enabled','content'}
 # Return original emitter bytes, not a JSON re-encoding.
 return payload
CHECK_PREFIX=f"""import pathlib,hashlib,json,sqlite3,subprocess,urllib.request
b=pathlib.Path({BASE!r});r=pathlib.Path({RELEASE!r})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(b/'light-media-server')=={EXPECTED_SERVER!r}
assert sha(r/'category-migrate-owned')=={EXPECTED_TOOL!r}
assert sha(b/'data/category.yaml')=={POLICY!r}
c=sqlite3.connect('file:'+str(b/'data/light-media.db')+'?mode=ro',uri=True)
"""
try:
 # All local verification must be terminal before production import.
 for job in ['app','race','core','build','web']:
  checks=json.loads((S/(job+'-result.json')).read_text())
  assert checks and all(x['exit_code']==0 for x in checks),job
 smoke=json.loads((S/'tool-smoke-result.json').read_text());assert smoke['state']=='passed'
 payload=source_payload()
 before=remote(CHECK_PREFIX+"""
assert c.execute('select count(*) from plugin_installations').fetchone()[0]==0
assert c.execute('select count(*) from plugin_migration_receipts').fetchone()[0]==0
assert c.execute("select count(*) from jobs where state='running'").fetchone()[0]==0
assert c.execute("select count(*) from plugin_runs where state in ('pending','running','reconcile_pending')").fetchone()[0]==0
notice=c.execute("select count(*) from records where kind='notification'").fetchone()[0]
c.close()
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=3) as response:assert json.load(response)['data']['version']=='0.4.0'
print(json.dumps({'notifications':notice,'key_sha256':sha(b/'data/secret.key'),'category_sha256':sha(b/'data/category.yaml')}))
""")
 report.update(stage='preflight_passed',version='0.4.0',original_enabled=False,original_config_sha256=CONFIG,original_policy_sha256=POLICY,original_kv=0)
 ssh('sudo -n docker stop -t 30 light-media');stopped=True
 # Same read-only source transaction is repeated immediately before use.
 payload=source_payload()
 db_before=remote(CHECK_PREFIX+"c.close();p=b/'data/light-media.db';print(json.dumps({'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns,'bytes':p.stat().st_size}))\n")
 args=[RELEASE+'/category-migrate-owned','--target-data-dir',BASE+'/data','--expected-source-config-sha',CONFIG,'--expected-policy-sha',POLICY]
 command=shlex.join(args)
 dry=json.loads(ssh(command,payload));assert dry['state']=='ready' and dry['writes']==0 and not dry['target_exists']
 db_after=remote(CHECK_PREFIX+"c.close();p=b/'data/light-media.db';print(json.dumps({'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns,'bytes':p.stat().st_size}))\n")
 assert db_before==db_after,'dry_run_mutated_database'
 report.update(stage='dry_run_passed',dry_run=dry,dry_run_database_unchanged=True)
 (S/'migration-progress.json').write_text(json.dumps(report,indent=2)+'\n')
 applied=json.loads(ssh(command+' --apply',payload));assert applied['state']=='imported_disabled' and not applied['scheduled'] and not applied['global_policy_written']
 report.update(stage='import_committed',import_result=applied)
 (S/'migration-progress.json').write_text(json.dumps(report,indent=2)+'\n')
 ssh('sudo -n docker start light-media');stopped=False
 for _ in range(30):
  try:
   after=remote(CHECK_PREFIX+"""
with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=2) as response:assert json.load(response)['data']['version']=='0.4.0'
i=c.execute("select plugin_id,version,installed,desired_enabled from plugin_installations where instance_id='CategoryEditor'").fetchone()
assert i==('CategoryEditor','1.3',1,0)
counts={
 'installations':c.execute("select count(*) from plugin_installations where instance_id='CategoryEditor'").fetchone()[0],
 'receipts':c.execute("select count(*) from plugin_migration_receipts where instance_id='CategoryEditor'").fetchone()[0],
 'runs':c.execute("select count(*) from plugin_runs where instance_id='CategoryEditor'").fetchone()[0],
 'kv':c.execute("select count(*) from plugin_values where instance_id='CategoryEditor' and kind='data'").fetchone()[0],
 'schedules':c.execute("select count(*) from plugin_schedules where instance_id='CategoryEditor'").fetchone()[0],
 'events':c.execute("select count(*) from plugin_event_subscriptions where instance_id='CategoryEditor'").fetchone()[0],
 'notifications':c.execute("select count(*) from records where kind='notification'").fetchone()[0]}
sealed=c.execute("select sealed from plugin_values where instance_id='CategoryEditor' and kind='config'").fetchone()[0]
assert b'content' not in sealed and b'enabled' not in sealed
assert c.execute('pragma quick_check').fetchone()[0]=='ok'
c.close()
print(json.dumps({'counts':counts,'key_sha256':sha(b/'data/secret.key'),'category_sha256':sha(b/'data/category.yaml'),'sealed_config_sha256':hashlib.sha256(sealed).hexdigest(),'sealed_config_bytes':len(sealed)}))
""")
   break
  except Exception:time.sleep(.25)
 else:raise RuntimeError('cold_target_verification_failed')
 assert after['key_sha256']==before['key_sha256'] and after['category_sha256']==before['category_sha256']
 assert after['counts']=={'installations':1,'receipts':1,'runs':0,'kv':0,'schedules':0,'events':0,'notifications':before['notifications']}
 source_payload() # Fresh source remains off and byte-identical; do not store it.
 report.update(stage='cold_verified_pending_ui',migrated=True,actual_plugins_migrated=1,cold_state=after,original_source_unchanged=True)
 (S/'migration-result.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
except Exception as e:
 report.update(stage='failed',error_class=type(e).__name__,error=str(e) if isinstance(e,RuntimeError) else 'migration_check_failed')
 if stopped:
  try:ssh('sudo -n docker start light-media');report['service_restart_requested']=True
  except Exception as restart:report['restart_error_class']=type(restart).__name__
 (S/'migration-failure.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report));sys.exit(1)
