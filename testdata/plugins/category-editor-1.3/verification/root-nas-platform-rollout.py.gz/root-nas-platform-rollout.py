"""One reviewed deployment, run on NAS via existing SSH; no credentials here."""
import fcntl,hashlib,json,os,pathlib,shutil,sqlite3,stat,subprocess,sys,time,urllib.request
BASE=pathlib.Path('/vol2/1000/docker/light-media')
RELEASE=BASE/'releases/plugin-v040-category-20261020-4c1747'
OLD='073d1a62039c6cebf32f49908d7cf586fdc5f95bd869deb95b0202088373bff0'
NEW='7732dd6a7f7d3c85f41589a0aa7250c385bc1e1f33ef65857ebe8cd3b805ef22'
TOOL='57ab17cd5982126bd0f30fcaae99bc2edfedb0f193c253a2b04dba054c5a7b9c'
POLICY='61502da87836ee756bdc8e5e3dad67d31893e517ba4c170a170ba8a9a695ac47'
CID='28ace504eeb607a808a947ead449142b6d58ebb9826b0acd92f56d273da3849b'
APPLY='--apply' in sys.argv
def require(ok,code):
 if not ok:raise RuntimeError(code)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def docker(*args):
 r=subprocess.run(['sudo','-n','docker',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 require(r.returncode==0,'docker_'+args[0]+'_failed')
 return r.stdout
def inspect(name):return json.loads(docker('inspect',name))[0]
def identity(name):
 s=inspect(name);return {'id':s['Id'],'pid':s['State']['Pid'],'started':s['State']['StartedAt'],'restart':s['RestartCount'],'running':s['State']['Running']}
def readonly_db():return sqlite3.connect('file:'+str(BASE/'data/light-media.db')+'?mode=ro',uri=True)
def health(version):
 for _ in range(40):
  try:
   with urllib.request.urlopen('http://192.168.8.129:3120/healthz',timeout=1) as r:
    value=json.load(r)
   if value.get('data',{}).get('version')==version:return True
  except (OSError,ValueError):pass
  time.sleep(.25)
 return False
stopped=False;swapped=False
report={'stage':'preflight','mode':'apply' if APPLY else 'read_only'}
try:
 s=inspect('light-media')
 require(s['Id']==CID and s['State']['Running'],'target_container_changed')
 require(s['Config']['User']=='1000:1001' and s['HostConfig']['NetworkMode']=='host' and s['HostConfig']['ReadonlyRootfs'],'target_runtime_changed')
 mounts={(m['Source'],m['Destination'],m['RW']) for m in s['Mounts']}
 require((str(BASE/'light-media-server'),'/app/light-media-server',False) in mounts and (str(BASE/'data'),'/config',True) in mounts,'target_mount_changed')
 require(digest(BASE/'light-media-server')==OLD,'target_binary_changed')
 require(digest(BASE/'data/category.yaml')==POLICY,'target_policy_changed')
 require(RELEASE.is_dir() and not RELEASE.is_symlink(),'owned_release_missing')
 require(digest(RELEASE/'light-media-server')==NEW and digest(RELEASE/'category-migrate-owned')==TOOL,'staged_binary_changed')
 key_before=digest(BASE/'data/secret.key')
 identities={name:identity(name) for name in ['moviepilot','qb']}
 require(all(v['running'] for v in identities.values()),'original_services_unavailable')
 db=readonly_db()
 require(db.execute("select count(*) from jobs where state='running'").fetchone()[0]==0,'target_jobs_running')
 require(db.execute("select count(*) from sqlite_master where type='table' and name='plugin_installations'").fetchone()[0]==0,'target_plugin_platform_already_changed')
 require(db.execute('pragma quick_check').fetchone()[0]=='ok','target_database_invalid')
 counts=dict(db.execute('select kind,count(*) from records group by kind'))
 db.close()
 require(health('0.3.21'),'old_target_health_failed')
 report.update(stage='preflight_passed',old_binary_sha256=OLD,new_binary_sha256=NEW,existing_record_counts=counts,original_services=identities,category_sha256=POLICY)
 if not APPLY:
  print(json.dumps(report));sys.exit(0)
 require(not (RELEASE/'rollback-light-media-server').exists() and not (RELEASE/'rollback-light-media.db').exists(),'rollback_location_already_used')
 docker('stop','-t','30','light-media');stopped=True
 require(not inspect('light-media')['State']['Running'],'target_not_stopped')
 lock=open(BASE/'data/instance.lock','rb')
 fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  db=readonly_db()
  require(db.execute("select count(*) from jobs where state='running'").fetchone()[0]==0,'target_jobs_not_quiescent')
  backup=sqlite3.connect(str(RELEASE/'rollback-light-media.db'))
  db.backup(backup);require(backup.execute('pragma quick_check').fetchone()[0]=='ok','rollback_database_invalid')
  backup.close();db.close();os.chmod(RELEASE/'rollback-light-media.db',0o600)
  shutil.copy2(BASE/'light-media-server',RELEASE/'rollback-light-media-server')
  require(digest(RELEASE/'rollback-light-media-server')==OLD,'rollback_binary_mismatch')
  temporary=BASE/'light-media-server.v040.new'
  require(not temporary.exists(),'target_staging_conflict')
  shutil.copy2(RELEASE/'light-media-server',temporary);os.chmod(temporary,0o755)
  with temporary.open('rb') as f:os.fsync(f.fileno())
  os.replace(temporary,BASE/'light-media-server');swapped=True
  fd=os.open(BASE,os.O_RDONLY);os.fsync(fd);os.close(fd)
 finally:
  fcntl.flock(lock.fileno(),fcntl.LOCK_UN);lock.close()
 docker('start','light-media');stopped=False
 require(health('0.4.0'),'new_target_health_failed')
 require(docker('exec','light-media','sha256sum','/app/light-media-server').decode().split()[0]==NEW,'container_bound_wrong_binary')
 db=readonly_db()
 require(db.execute('select version from plugin_storage_schema').fetchone()[0]==1,'plugin_schema_not_initialized')
 require(db.execute('select count(*) from plugin_installations').fetchone()[0]==0,'unexpected_plugin_installation')
 require(db.execute('pragma quick_check').fetchone()[0]=='ok','new_target_database_invalid')
 after_counts=dict(db.execute('select kind,count(*) from records group by kind'));db.close()
 require(digest(BASE/'data/category.yaml')==POLICY and digest(BASE/'data/secret.key')==key_before,'protected_target_file_changed')
 require({name:identity(name) for name in identities}==identities,'original_service_identity_changed')
 report.update(stage='platform_deployed',version='0.4.0',plugin_schema=1,installed_plugins=0,original_plugins_migrated=0,category_unchanged=True,encryption_key_unchanged=True,existing_record_counts_after=after_counts,rollback_database='rollback-light-media.db',rollback_binary='rollback-light-media-server',new_identity=identity('light-media'))
 (RELEASE/'rollout-result.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
except Exception as e:
 report.update(stage='failed',error_class=type(e).__name__,error=str(e) if isinstance(e,RuntimeError) else 'bounded_deployment_failure')
 if swapped:
  try:
   if inspect('light-media')['State']['Running']:docker('stop','-t','30','light-media')
   require(digest(RELEASE/'rollback-light-media-server')==OLD,'rollback_binary_changed')
   shutil.copy2(RELEASE/'rollback-light-media-server',BASE/'light-media-server.rollback.new')
   os.replace(BASE/'light-media-server.rollback.new',BASE/'light-media-server')
   docker('start','light-media');report['binary_rollback_healthy']=health('0.3.21')
   report['database_preserved']=True
  except Exception as rollback:report['rollback_error_class']=type(rollback).__name__
 elif stopped:
  try:docker('start','light-media');report['old_service_restarted']=health('0.3.21')
  except Exception as rollback:report['rollback_error_class']=type(rollback).__name__
 if RELEASE.is_dir():(RELEASE/'rollout-failure.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report));sys.exit(1)
