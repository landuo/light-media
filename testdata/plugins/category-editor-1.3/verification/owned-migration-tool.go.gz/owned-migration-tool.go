// One-purpose delivery tool. Not part of the public application or API.
package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"

	"golang.org/x/sys/unix"
	"light-media/internal/app"
	"light-media/internal/plugins/builtin"
)

type input struct {
	Config     json.RawMessage `json:"config"`
	ConfigSHA  string          `json:"config_sha256"`
	ContentSHA string          `json:"content_sha256"`
	KVCount    int             `json:"kv_count"`
}

func digest(b []byte) string { sum := sha256.Sum256(b); return hex.EncodeToString(sum[:]) }
func regular(path string, limit int64) ([]byte, error) {
	st, e := os.Lstat(path)
	if e != nil || !st.Mode().IsRegular() || st.Size() > limit {
		return nil, errors.New("invalid_owned_input_file")
	}
	return os.ReadFile(path)
}
func run() error {
	var dir, expectedConfig, expectedPolicy string
	var apply bool
	flag.StringVar(&dir, "target-data-dir", "", "existing target application data directory")
	flag.StringVar(&expectedConfig, "expected-source-config-sha", "", "reviewed source raw JSON SHA256")
	flag.StringVar(&expectedPolicy, "expected-policy-sha", "", "reviewed matching source-content/target-policy SHA256")
	flag.BoolVar(&apply, "apply", false, "perform the reviewed isolated plugin import; default is read-only")
	flag.Parse()
	if dir == "" || !filepath.IsAbs(dir) || filepath.Clean(dir) != dir || dir == "/" || len(expectedConfig) != 64 || len(expectedPolicy) != 64 {
		return errors.New("explicit_reviewed_target_and_digests_required")
	}
	st, e := os.Lstat(dir)
	if e != nil || !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
		return errors.New("invalid_target_directory")
	}
	var in input
	d := json.NewDecoder(io.LimitReader(os.Stdin, (1<<20)+1))
	d.DisallowUnknownFields()
	if d.Decode(&in) != nil || d.Decode(new(any)) != io.EOF || in.KVCount != 0 || in.ConfigSHA != expectedConfig || digest(in.Config) != expectedConfig || in.ContentSHA != expectedPolicy {
		return errors.New("source_metadata_changed")
	}
	var fields map[string]json.RawMessage
	var content string
	if json.Unmarshal(in.Config, &fields) != nil || len(fields) != 2 || string(fields["enabled"]) != "false" || json.Unmarshal(fields["content"], &content) != nil || digest([]byte(content)) != expectedPolicy {
		return errors.New("source_not_exact_disabled_category_config")
	}
	policy, e := regular(filepath.Join(dir, "category.yaml"), 64<<10)
	if e != nil || digest(policy) != expectedPolicy {
		return errors.New("independent_target_policy_differs")
	}
	// Acquire the application's existing instance lock; never create anything in
	// dry-run mode and never edit a running target. No daemon signal is sent.
	lockPath := filepath.Join(dir, "instance.lock")
	if _, e = regular(lockPath, 4096); e != nil {
		return errors.New("target_instance_lock_missing")
	}
	lock, e := os.Open(lockPath)
	if e != nil {
		return errors.New("target_instance_lock_unavailable")
	}
	defer lock.Close()
	if unix.Flock(int(lock.Fd()), unix.LOCK_EX|unix.LOCK_NB) != nil {
		return errors.New("target_application_is_running")
	}
	defer unix.Flock(int(lock.Fd()), unix.LOCK_UN)
	dbPath := filepath.Join(dir, "light-media.db")
	st, e = os.Lstat(dbPath)
	if e != nil || !st.Mode().IsRegular() {
		return errors.New("existing_target_database_required")
	}
	ro, e := sql.Open("sqlite", "file:"+dbPath+"?mode=ro")
	if e != nil {
		return errors.New("target_read_failed")
	}
	defer ro.Close()
	var schema int
	if ro.QueryRow(`SELECT version FROM plugin_storage_schema`).Scan(&schema) != nil || schema != 1 {
		return errors.New("deploy_plugin_platform_before_migration")
	}
	fingerprint := digest([]byte("CategoryEditor/1.3/24a8109b5c15bb73b845e42653933d09eb83b608a53303fbab9ebff39b801c27/" + expectedConfig + "/" + expectedPolicy + "/kv0"))
	var existing, receipts int
	if ro.QueryRow(`SELECT COUNT(*) FROM plugin_installations WHERE instance_id='CategoryEditor'`).Scan(&existing) != nil {
		return errors.New("target_read_failed")
	}
	if ro.QueryRow(`SELECT COUNT(*) FROM plugin_migration_receipts WHERE source_fingerprint=? AND source_plugin_id='CategoryEditor' AND instance_id='CategoryEditor'`, fingerprint).Scan(&receipts) != nil {
		return errors.New("target_read_failed")
	}
	if existing > 0 && receipts != 1 {
		return errors.New("target_category_instance_exists_without_same_receipt")
	}
	var active int
	if ro.QueryRow(`SELECT (SELECT COUNT(*) FROM jobs WHERE state='running')+(SELECT COUNT(*) FROM plugin_runs WHERE state IN ('pending','running','reconcile_pending'))`).Scan(&active) != nil || active != 0 {
		return errors.New("target_has_unfinished_active_work")
	}
	key, e := regular(filepath.Join(dir, "secret.key"), 32)
	if e != nil || len(key) != 32 {
		return errors.New("existing_target_encryption_key_required")
	}
	if !apply {
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"mode": "read_only_dry_run", "state": "ready", "config_fields": []string{"content", "enabled"}, "source_enabled": false, "kv_count": 0, "source_fingerprint": fingerprint, "target_policy_sha256": expectedPolicy, "target_exists": existing > 0, "same_receipt": receipts == 1, "writes": 0})
	}
	// The authenticated encrypted store owns its transaction and receipt. Import
	// deliberately leaves desired_enabled=false and queues no worker invocation.
	ro.Close()
	// OpenStore takes its own nonblocking instance lock. A process winning this
	// handoff makes OpenStore fail; no migration proceeds under a stale lock.
	if unix.Flock(int(lock.Fd()), unix.LOCK_UN) != nil {
		return errors.New("target_lock_handoff_failed")
	}
	s, e := app.OpenStore(dir)
	if e != nil {
		return errors.New("target_store_open_failed")
	}
	defer s.Close()
	p, e := app.NewPluginStore(context.Background(), s)
	if e != nil {
		return errors.New("target_plugin_store_open_failed")
	}
	m, e := p.BeginMigration(context.Background(), fingerprint, "CategoryEditor", "CategoryEditor")
	if e != nil {
		return errors.New("migration_plan_failed")
	}
	manifest := builtin.CategoryEditorManifest()
	raw, _ := json.Marshal(manifest)
	r, e := p.Import(context.Background(), app.PluginImport{RunID: m.ID, Installation: app.PluginInstallation{InstanceID: "CategoryEditor", PluginID: "CategoryEditor", Version: "1.3", ManifestSchemaVersion: 1, Manifest: raw}, Config: in.Config, Data: map[string]json.RawMessage{}})
	if e != nil {
		return errors.New("atomic_import_failed")
	}
	stored, e := p.Config(context.Background(), "CategoryEditor")
	var compact bytes.Buffer
	if json.Compact(&compact, in.Config) != nil || e != nil || !bytes.Equal(stored.Value, compact.Bytes()) {
		return errors.New("post_import_config_mismatch")
	}
	i, e := p.Installation(context.Background(), "CategoryEditor")
	if e != nil || !i.Installed || i.DesiredEnabled {
		return errors.New("post_import_activation_mismatch")
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"mode": "apply", "state": "imported_disabled", "receipt": r, "config_sha256": digest(stored.Value), "target_policy_sha256": expectedPolicy, "kv_count": 0, "scheduled": false, "global_policy_written": false})
}
func main() {
	if e := run(); e != nil {
		fmt.Fprintln(os.Stderr, e.Error())
		os.Exit(1)
	}
}
