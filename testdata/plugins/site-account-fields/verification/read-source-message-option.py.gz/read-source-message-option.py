import pathlib,os,json,ast,hashlib
p=pathlib.Path('/app/app/core/config.py');raw=p.read_bytes();tree=ast.parse(raw)
values=[n.value.value for n in ast.walk(tree) if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='SITE_MESSAGE' and isinstance(n.value,ast.Constant)];assert values==[True]
value=os.environ.get('SITE_MESSAGE');source='container_environment'
if value is None:
 source='config_app_env';env=pathlib.Path('/config/app.env');found=[]
 if env.exists():
  with env.open() as f:
   for line in f:
    line=line.strip()
    if line.startswith('export '):line=line[7:]
    key,sep,item=line.partition('=')
    if sep and key.strip()=='SITE_MESSAGE':found.append(item.strip())
 if found:
  value=found[-1]
  if len(value)>=2 and value[0] in (chr(34),chr(39)) and value[-1]==value[0]:value=value[1:-1]
  else:value=value.split(' #',1)[0].strip()
 else:source='source_default';value='true'
normalized=str(value).lower();assert normalized in ('true','1','yes','on','false','0','no','off')
print(json.dumps(dict(value=normalized in ('true','1','yes','on'),source=source,mode='read_only_cold_derivation_not_live_state',core_source_sha256=hashlib.sha256(raw).hexdigest(),original_writes=0,network_calls=0)))
