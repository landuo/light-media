import ast,pathlib,json,hashlib,typing,sys
from lxml import etree

def audit(event,args):
 if event in ('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system','os.fork','os.posix_spawn'):raise RuntimeError('side_effect_denied')
 if event=='open' and ((isinstance(args[1],str) and any(c in args[1] for c in 'wax+')) or (isinstance(args[2],int) and args[2]&(1|2|64|512))):raise RuntimeError('write_denied')
sys.addaudithook(audit)
class Quiet:
 def __getattr__(self,n):return lambda *a,**k:None
class StringUtils:
 is_valid_html_element=staticmethod(lambda x:x is not None)
 str_int=staticmethod(lambda x:int(x))
namespace=dict(etree=etree,logger=Quiet(),StringUtils=StringUtils,Optional=typing.Optional,json=json,urljoin=__import__('urllib.parse',fromlist=['urljoin']).urljoin)
import re
namespace['re']=re
sources={};classes={}
for name,wanted in [('nexus_php.py',['_parse_message_unread','_parse_message_unread_links','_parse_message_content']),('mtorrent.py',['_parse_message_unread_links'])]:
 p=pathlib.Path('/app/app/modules/indexer/parser')/name;raw=p.read_bytes();sources[name]=hashlib.sha256(raw).hexdigest();tree=ast.parse(raw)
 original=next(n for n in tree.body if isinstance(n,ast.ClassDef));methods=[n for n in original.body if isinstance(n,ast.FunctionDef) and n.name in wanted]
 assert len(methods)==len(wanted)
 c=ast.ClassDef(name='Owned'+name.replace('.','_'),bases=[],keywords=[],body=methods,decorator_list=[]);module=ast.fix_missing_locations(ast.Module(body=[c],type_ignores=[]));exec(compile(module,str(p),'exec'),namespace);classes[name]=namespace[c.name]
counts=[]
for name,html in [('zero','<span><a href="messages.php">0</a></span>'),('paren','<span><a href="messages.php">信息箱</a> (2)</span>'),('time-not-count','<span><a href="messages.php">Date (12:34)</a></span>'),('nbsp','<span><a href="messages.php">你有\u00a03</a></span>'),('absent','<div>none</div>'),('exact-link-preferred','<span><a href="messages.php?action=other">(7)</a></span><span><a href="messages.php">(2)</a></span>'),('unknown-count','<span><a href="messages.php">信息箱</a></span>')]:
 obj=classes['nexus_php.py']();obj.message_unread=None;obj._site_name='owned';obj._parse_message_unread(html);counts.append(dict(name=name,html=html,observed=obj.message_unread))
contents=[]
for name,html in [('nexus','<h1> heading </h1><table><tr><td class="colhead">header</td></tr><tr><td>sent</td><td>2026-10-21</td></tr><tr><td>body <b>bold</b>\n tail</td></tr></table>'),('direct-title-text','<h1>first<em>nested</em>tail</h1>'),('layui','<div class="layui-card-header"><span>title</span><span><span>from</span><span>date</span></span></div><div class="layui-card-body extra"> body <b>x</b> </div>'),('union-order','<div class="layui-card-header"><span>early</span><span><span>from</span><span>early-date</span></span></div><div class="layui-card-body">early-body</div><h1>late</h1><table><tr><td class="colhead">h</td></tr><tr><td>x</td><td>late-date</td></tr><tr><td>late-body</td></tr></table>'),('missing','<div>none</div>')]:
 obj=classes['nexus_php.py']();contents.append(dict(name=name,html=html,tuple=obj._parse_message_content(html)))
links=[]
for name,html in [('read-and-unread','<table><tr><td><a href="messages.php?action=viewmessage&amp;id=1">new</a></td></tr><tr><td><img alt="Read"><a href="messages.php?action=viewmessage&amp;id=2">old</a></td></tr></table><a href="messages.php?action=viewmailbox&amp;box=1&amp;page=2">下一页</a>'),('direct-only','<table><tr><td><span><a href="messages.php?action=viewmessage&amp;id=3">nested</a></span><a href="messages.php?action=viewmessage&amp;id=4">direct</a></td></tr></table>'),('duplicate-preserved','<table><tr><td><a href="messages.php?action=viewmessage&amp;id=1">one</a></td></tr><tr><td><a href="messages.php?action=viewmessage&amp;id=1">same</a></td></tr></table>')]:
 obj=classes['nexus_php.py']();selected=[];next_page=obj._parse_message_unread_links(html,selected);links.append(dict(name=name,html=html,links=selected,next_page=next_page or ''))
obj=classes['mtorrent.py']();obj.message_unread_contents=[];obj._base_url='https://owned.invalid/';marks=[];obj._get_page_content=lambda **kwargs:marks.append(kwargs)
payload={'code':'0','data':{'data':[{'id':'1','unread':True,'title':'title','createdDate':'date','context':'body'},{'id':'2','unread':False,'title':'read','createdDate':'date','context':'body'},{'id':'3','unread':True,'title':'incomplete'}]}}
obj._parse_message_unread_links(json.dumps(payload),[])
print(json.dumps(dict(version=1,source_sha256=sources,network_calls=0,original_writes=0,count_sentinel='None distinguishes no assignment from original constructor default zero',counts=counts,contents=contents,links=links,mtorrent=dict(payload=payload,contents=obj.message_unread_contents,marks=marks)),ensure_ascii=False,separators=(',',':')))
