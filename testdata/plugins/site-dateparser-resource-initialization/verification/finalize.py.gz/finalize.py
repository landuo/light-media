import pathlib,json,hashlib,re,subprocess,gzip,base64,urllib.parse
root=pathlib.Path('/Users/accidia/projects/light-media');s=pathlib.Path(__file__).resolve().parent
read=lambda n:json.loads((s/n).read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
statuses={n:read(n) for n in ['sites-status.json','related-status.json','actual-status.json','module-status.json','build-normal-status.json','build-race-status.json','build-linux-status.json']}
for n,v in statuses.items():
 assert v and all(x['exit']==0 for x in v),n
 if n in ['sites-status.json','related-status.json','actual-status.json','module-status.json']:assert len(v)==2
nas=read('nas-verification.json');assert nas['state']=='passed_owned_linux_business' and nas['owned_container_removed'] and nas['owned_runtime_directory_removed'] and nas['original_and_production_containers_unchanged'] and nas['execution']['exit_code']==0 and not nas['execution']['oom_killed']
cleanup=read('nas-independent-cleanup.json');assert all(cleanup.values())
checks={}
for name in ['sites-normal','sites-race','related-normal','related-race','actual-normal','actual-race','nas-selected','module-normal','module-cold-race']:
 b=(s/(name+'.log')).read_bytes();v={k:len(re.findall(p,b,re.M)) for k,p in [('top_pass',rb'^--- PASS:'),('inclusive_pass',rb'^\s*--- PASS:'),('fail',rb'^\s*--- FAIL:'),('skip',rb'^\s*--- SKIP:')]};v['sha256']=hashlib.sha256(b).hexdigest();assert not v['fail'] and not v['skip'];checks[name]=v
assert checks['sites-normal']['inclusive_pass']==246 and checks['sites-race']['inclusive_pass']==246 and checks['related-normal']['inclusive_pass']==167 and checks['related-race']['inclusive_pass']==167 and checks['nas-selected']['inclusive_pass']==85
sources=read('SOURCE-INPUTS.json');assert all(sha(s/'app'/x['path'])==x['sha256'] for x in sources)
for name in ['COMPILATION-INPUTS.json','COMPILATION-MODULE-INPUTS.json']:
 for x in read(name):
  p=s/'app'/x['path'][5:] if x['path'].startswith('repo/') else pathlib.Path(x['path']);assert sha(p)==x['sha256'],x['path']
paths=set(p.decode() for p in subprocess.check_output(['git','ls-files','-mo','--exclude-standard','-z'],cwd=root).split(b'\0') if p)
focus=sorted(n for n in paths if n.startswith('third_party/') or n in ['Dockerfile','Makefile','go.mod','go.sum'])
manifest={x['path']:x['sha256'] for x in sources};assert all(manifest[n]==sha(root/n) for n in focus)
web=[x for x in sources if x['path'].startswith('web/')];assert all((root/x['path']).read_bytes()==(s/'app'/x['path']).read_bytes() for x in web)
comparison=read('formal-body-comparison.json');assert comparison['initializers']==205 and len(comparison['comparisons'])==206 and comparison['all_equal'] and not comparison['data_removed']
assert read('docker-dependency-stage-status.json')['exit']==0
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','admin@192.168.8.129','sudo -n docker exec -i cb82e3f550881334ef3814426016d08d909bccd88d3297522756ba31654d129a /opt/venv/bin/python -I -B -'],input=(root/'work/_site_statistic_migration_review/emit-reviewed-private-stdin.py').read_bytes(),capture_output=True,timeout=35);assert r.returncode==0;v=json.loads(r.stdout);needles=set();secrets=set()
def walk(v,k=''):
 if isinstance(v,dict):
  for key,x in v.items():walk(x,key.lower())
 elif isinstance(v,list):
  for x in v:walk(x,k)
 elif isinstance(v,str):
  if v[:1] in ('{','['):
   try:walk(json.loads(v),k)
   except (ValueError,TypeError):pass
  if len(v)>=6 and any(x in k for x in ['password','cookie','token','apikey','api_key','passkey','authorization','secret']):secrets.add(v)
  for url in re.findall(r'https?://[^\s<>"\']+',v):
   for key,vals in urllib.parse.parse_qs(urllib.parse.urlsplit(url).query).items():
    if any(x in key.lower() for x in ['passkey','token','auth','key']):secrets.update(x for x in vals if len(x)>=6)
walk(v)
for raw in v['account_rows']:
 needles.add(raw.encode());row=json.loads(raw)
 for key in ['username','userid']:
  value=row.get(key)
  if isinstance(value,str) and value:
   needles.update([('"'+key+'":'+json.dumps(value,ensure_ascii=False)).encode(),('"'+key+'": '+json.dumps(value,ensure_ascii=False)).encode()])
   if len(value)>=6:
    q=json.dumps(value,ensure_ascii=False);needles.update([q.encode(),json.dumps(q,ensure_ascii=False)[1:-1].encode()])
for value in secrets:needles.update(x.encode() for x in [value,urllib.parse.quote(value,safe=''),base64.b64encode(value.encode()).decode()])
files=sorted(p for p in s.iterdir() if p.is_file() and p.suffix in ['.py','.json','.log'])
docs=[root/'docs/site-dateparser-resource-initialization.txt',root/'docs/plugin-installed-migration-baseline.md']
for p in files+docs+[root/n for n in focus]:assert not any(x in p.read_bytes() for x in needles),'private_material_no_archive_written'
drift={'frozen_source_files':len(sources),'main_compiler_inputs':len(read('COMPILATION-INPUTS.json')),'dependency_test_compiler_inputs':len(read('COMPILATION-MODULE-INPUTS.json')),'frozen_drift':0,'compiler_drift':0,'product_focus_drift':0,'complete_compiler_system_headers_linker_closure_claimed':False}
report={'date':'2026-10-21','base_commit':'2d0d534ddc70fd9850bbe29760b705688416df93','state':'Go_dateparser_locale_initialization_verified_not_plugin_completion','actual_complete':7,'remaining':16,'production_version':'0.4.8','deployed':False,'python_runtime_added':False,'old_and_production_mutations':0,'real_business_calls':0,'real_handoffs':0,'initializers':205,'restored_formatted_body_comparisons':206,'all_languages_retained':True,'first_real_lookup_initializes_all_tables':True,'cold_concurrent_callers':256,'cold_concurrent_locales':8,'checks':checks,'statuses':statuses,'nas':nas,'independent_cleanup':cleanup,'drift':drift,'measurements':read('formal-native-package-init.json'),'docker_dependency_stage':read('docker-dependency-stage-status.json'),'docker_image_built':False,'body_comparison_sha256':sha(s/'formal-body-comparison.json'),'source_manifest_sha256':sha(s/'SOURCE-INPUTS.json'),'compiler_manifest_sha256':sha(s/'COMPILATION-INPUTS.json'),'module_compiler_manifest_sha256':sha(s/'COMPILATION-MODULE-INPUTS.json'),'focus':[{'path':n,'sha256':sha(root/n)} for n in focus],'frontend_changed':False,'frontend_retested':False,'source_history_rows':len(v['account_rows']),'private_scan':{'passed':True,'files':len(files+docs+focus),'patterns':len(needles),'payload_saved':False},'failures_retained':['Prototype copy into inherited readonly directories failed; fresh v2 copy used.','Optional upstream toolchain go1.27.1 download failed EOF; no toolchain installed. GOTOOLCHAIN=local passed; formal fork removes preference.'],'remaining':['All rare original dateparser strings are not proven.','Production peak RSS and actual Docker image build not measured/run.','RousiPro dedicated account flow, actual catalog integration, source notification/global setting/handoff and remaining 16 plugins.']}
out=root/'docs/site-dateparser-resource-initialization-verification.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');assert not any(x in out.read_bytes() for x in needles)
archive=root/'testdata/plugins/site-dateparser-resource-initialization/verification';archive.mkdir(parents=True,exist_ok=False)
for p in files:(archive/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
(archive/'index.json').write_text(json.dumps({'files':[{'path':p.name,'sha256':sha(p)} for p in sorted(archive.iterdir())]},indent=2)+'\n')
print(json.dumps({'proof_files':len(files),'focus_files':len(focus),'drift':drift,'private_scan_passed':True,'actual_complete':7,'goal_complete':False}))
