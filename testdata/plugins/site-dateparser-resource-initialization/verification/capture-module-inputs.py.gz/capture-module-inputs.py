import pathlib,subprocess,json,os,hashlib
s=pathlib.Path(__file__).resolve().parent;app=s/'app';mod=app/'third_party/go-dateparser';paths=set();runs=[]
for mode,flags in [('normal',[]),('race',['-race'])]:
 raw=subprocess.check_output(['go','list',*flags,'-deps','-test','-json','.','./date/...','./internal/...'],cwd=mod);value=raw.decode();pos=0;decoder=json.JSONDecoder();count=0
 while pos<len(value):
  while pos<len(value) and value[pos].isspace():pos+=1
  if pos==len(value):break
  v,pos=decoder.raw_decode(value,pos);count+=1;d=v.get('Dir')
  if not d:continue
  for key in ['GoFiles','CgoFiles','CFiles','CXXFiles','MFiles','HFiles','SFiles','SysoFiles','EmbedFiles','TestGoFiles','XTestGoFiles']:
   for name in v.get(key,[]):
    p=pathlib.Path(d)/name
    if p.is_file():paths.add(p)
  if isinstance(v.get('Module'),dict) and v['Module'].get('GoMod'):paths.add(pathlib.Path(v['Module']['GoMod']))
 runs.append({'mode':mode,'packages':count,'exit':0})
paths.update([mod/'go.mod',mod/'go.sum']);rows=[]
for p in sorted(paths):
 try:n='repo/'+str(p.relative_to(app))
 except ValueError:n=str(p)
 rows.append({'path':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(s/'COMPILATION-MODULE-INPUTS.json').write_text(json.dumps(rows,indent=2)+'\n');(s/'COMPILATION-MODULE-MODES.json').write_text(json.dumps({'runs':runs,'boundary':'resolved module library test inputs only; not complete compiler/system-header/linker closure'},indent=2)+'\n');print(json.dumps({'inputs':len(rows),'runs':runs}))
