import http.cookiejar,json,pathlib,sys,urllib.request
root=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');state=json.loads((root/'browser-catalog-sources-state.json').read_text());assert state['origin'].startswith('http://127.0.0.1:')
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
client.open(urllib.request.Request(state['origin']+'/api/auth/login',data=json.dumps({'username':'catalog-sources-acceptance','password':'owned-catalog-sources-password'}).encode(),headers={'Content-Type':'application/json'})).read()
def get(path):return json.load(client.open(state['origin']+path))
out={'phase':sys.argv[1],'kind':'actual owned native preferences and Go SDK snapshot; no browser hidden-state read','preferences':get('/api/catalog/recommend/preferences')['data'],'explore_preferences':get('/api/catalog/explore/preferences')['data']}
for label in ['source','clone']:
 raw=get('/api/v1/plugin/'+state[label+'_id']+'/snapshot');last=raw.get('last_feed') or {};out[label]={'pid':raw.get('pid'),'calls':raw.get('calls'),'last_feed':{k:last.get(k) for k in ['method','path','query','params']}}
print(json.dumps(out,ensure_ascii=False))
