import hashlib,json,pathlib,sys,urllib.request,http.cookiejar
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module29-ui-state.json').read_text());mode=sys.argv[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(method,path,body=None):
 data=json.dumps(body).encode()if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method))as response:return json.loads(response.read())
request('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
sources=[s['ui_plan']['files'][0]['source']]+s['related_sources']
if mode in ['fail','restore','clone']:
 cfg=json.loads(json.dumps(s['source_config']))
 if mode in ['fail','clone']:
  cfg['modules']['transfer']='module_execute';cfg.pop('transfer_results',None)
  cfg.pop('build_transfer_info',None);cfg['result']=None
 if mode=='fail':cfg['build_transfer_info']=True;cfg['result']={'success':False,'message':'owned constructor veto','need_scrape':None}
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 if mode in ['restore','clone']:
  other={'enabled':True,'modules':{'transfer':'module_execute'},'result':None}
  if mode=='clone':
   other['transfer_results']={path:{'__plugin_transfer_info':{'success':True,'need_scrape':False,'transfer_type':'link','target_item':{'storage':'local','type':'file','path':s['target']+'/Owned clone preview/ClonePreview'+ext,'name':'ClonePreview'+ext}}}for path,ext in zip(sources,['.mkv','.srt','.flac'])}
  assert request('PUT','/api/plugins/'+s['clone'],other)['data']['success']
if mode in ['collection-false','collection-clone','collection-restore','collection-browse']:
 cfg=json.loads(json.dumps(s['source_config']))
 other={'enabled':True,'modules':{'transfer':'module_execute'},'result':None}
 if mode=='collection-false':cfg['storage_siblings']=False
 if mode=='collection-browse':cfg['storage_siblings']=None
 if mode=='collection-clone':
  cfg['storage_siblings']=None
  other['modules'].update({'get_parent_item':'module_storage_parent','list_files':'module_storage_siblings'})
  other['storage_siblings']={'__plugin_module_tuple':[{'storage':'local','type':'file','path':s['related_sources'][0],'name':pathlib.Path(s['related_sources'][0]).name,'extension':'srt','size':24}]}
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert request('PUT','/api/plugins/'+s['clone'],other)['data']['success']
if mode in ['held-start','held-release']:
 import sqlite3,time,copy
 statefile=r/'transfer-module29-held-ui-state.json'
 if mode=='held-start':
  history=request('GET','/api/history/transfers?q=HistoryBusyOwner')['data']['items']
  selected=next(x for x in history if x['source'].endswith('/HistoryBusyOwner.2024.srt'))
  name='BrowserHeldConsumer';identity=90009400;path=pathlib.Path(s['directory'])/(name+'.2024.mkv');path.write_bytes(b'owned browser held source')
  gate=pathlib.Path(s['directory'])/'owned-browser-hold.gate'
  cfg=copy.deepcopy(s['source_config'])
  def media(v):
   if isinstance(v,dict):return {k:media(x)for k,x in v.items()}
   if isinstance(v,list):return [media(x)for x in v]
   if isinstance(v,int)and v==90001799:return identity
   if isinstance(v,str):return v.replace('Owned high-level UI',name).replace('90001799',str(identity))
   return v
  cfg['media_result']=media(cfg['media_result']);cfg['modules']={'recognize_media':'module_search_media','get_parent_item':'module_storage_parent','list_files':'module_storage_siblings','transfer':'module_execute'}
  cfg['result']=None;cfg.pop('transfer_results',None);cfg.pop('transfer_targets',None)
  cfg['transfer_hold']=str(gate);cfg['storage_siblings']={'__plugin_module_tuple':[{'storage':'local','type':'file','path':selected['source'],'name':name+'.2024.srt','basename':name+'.2024','extension':'srt','size':selected['size']}]}
  assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
  plan=request('POST','/api/import/preview',{'media_type':'movie','tmdb_id':identity,'root_id':'owned-module-transfer-root','mode':'hardlink','scraping':False,'files':[{'path':str(path)}]})['data']
  assert plan['media']['id']==identity and plan['files'][0]['status']=='ready',plan
  con=sqlite3.connect('file:'+s['data_dir']+'/light-media.db?mode=ro',uri=True)
  meta=json.loads(con.execute("SELECT payload FROM records WHERE kind='import_meta'AND id=?",(plan['id'],)).fetchone()[0]);con.close()
  assert [x['source']for x in meta['sidecars'][plan['files'][0]['id']]]==[selected['source']],meta
  job=request('POST','/api/import/execute',{'plan_id':plan['id']})['data']
  for _ in range(300):
   if pathlib.Path(str(gate)+'.entered').exists():break
   time.sleep(.01)
  assert pathlib.Path(str(gate)+'.entered').exists(),'held SDK not entered'
  detail=request('GET','/api/jobs/'+job['id'])['data']['job'];assert detail['state']=='running',detail
  proof={'selected':selected,'plan':plan,'job':detail,'gate':str(gate),'source_exists':pathlib.Path(selected['source']).exists(),'target_exists':pathlib.Path(selected['target']).exists()}
  statefile.write_text(json.dumps(proof,indent=2)+'\n');print({'held':True,'job_state':detail['state'],'source':selected['source'],'target':selected['target']});sys.exit(0)
 held=json.loads(statefile.read_text());pathlib.Path(held['gate']).write_bytes(b'release owned browser hold')
 for _ in range(500):
  detail=request('GET','/api/jobs/'+held['job']['id'])['data']['job']
  if detail['state']=='succeeded':break
  time.sleep(.02)
 assert detail['state']=='succeeded',detail
 held.update(completed_job=detail,source_still_exists=pathlib.Path(held['selected']['source']).exists(),target_still_exists=pathlib.Path(held['selected']['target']).exists())
 statefile.write_text(json.dumps(held,indent=2)+'\n');print({'held_released':True,'job_state':detail['state'],'source_exists':held['source_still_exists'],'target_exists':held['target_still_exists']});sys.exit(0)
if mode in ['native-browse','native-ready','native-restore-final']:
 cfg=json.loads(json.dumps(s['source_config']))
 cfg['modules'].pop('transfer',None)
 if mode=='native-browse':cfg['storage_siblings']=None
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert request('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{}})['data']['success']
if mode=='parent-prepare':
 import copy,time
 name='BrowserHistoryParent';identity=90009600;path=pathlib.Path(s['directory'])/(name+'.2024.mkv');path.write_bytes(b'owned browser parent cleanup')
 def media(v):
  if isinstance(v,dict):return {k:media(x)for k,x in v.items()}
  if isinstance(v,list):return [media(x)for x in v]
  if isinstance(v,int)and v==90001799:return identity
  if isinstance(v,str):return v.replace('Owned high-level UI',name).replace('90001799',str(identity))
  return v
 cfg={'enabled':True,'modules':{'recognize_media':'module_search_media','transfer':'module_execute'},'media_result':media(s['source_config']['media_result']),'result':None}
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert request('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{}})['data']['success']
 plan=request('POST','/api/import/preview',{'media_type':'movie','tmdb_id':identity,'root_id':'owned-module-transfer-root','mode':'hardlink','scraping':False,'files':[{'path':str(path)}]})['data']
 assert plan['media']['id']==identity and plan['files'][0]['status']=='ready',plan
 job=request('POST','/api/import/execute',{'plan_id':plan['id']})['data']
 for _ in range(1000):
  detail=request('GET','/api/jobs/'+job['id'])['data']['job']
  if detail['state']=='succeeded':break
  time.sleep(.01)
 assert detail['state']=='succeeded',detail
 target=pathlib.Path(plan['files'][0]['target']);nfo=target.with_suffix('.nfo');nfo.write_bytes(b'owned nonmedia parent cleanup')
 (r/'transfer-module29-parent-ui-state.json').write_text(json.dumps({'plan':plan,'job':detail,'target':str(target),'nfo':str(nfo)},indent=2)+'\n')
if mode in ['delete-false','delete-clone','delete-true']:
 cfg={'enabled':True,'modules':{'delete_file':'module_storage_delete'},'storage_root':str(pathlib.Path(s['directory']).parent),'storage_mode':'no_effect','result':False if mode=='delete-false' else None}
 other={'enabled':True,'modules':{'delete_file':'module_storage_delete'},'storage_root':str(pathlib.Path(s['directory']).parent),'storage_mode':'effect','result':True}
 if mode=='delete-true':cfg.update(storage_mode='effect',result=True)
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert request('PUT','/api/plugins/'+s['clone'],other)['data']['success']
def file(path):
 p=pathlib.Path(path)
 if not p.exists():return None
 st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
proof={'mode':mode,'source':request('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':request('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'input':file(sources[0]),'target':file(s['expected_module_target']),'related':[{'input':file(src),'target':file(dst)}for src,dst in zip(s['related_sources'],s['expected_related_targets'])],'jobs':request('GET','/api/jobs'),'plans':request('GET','/api/import/plans'),'history':request('GET','/api/history/transfers')}
native=s['ui_plan']['files'][0]['target'];stem=str(pathlib.Path(native).with_suffix(''))
proof['native_target']=file(native)
proof['native_related']=[file(stem+'.default.chi.zh-cn.srt'),file(stem+'.flac')]
names=['StorageHistorySourceFalse','StorageHistoryTargetFalse','StorageHistoryMainTargetTrue','BrowserHistoryParent']
proof['storage_history_files']={}
for name in names:
 paths=[str(pathlib.Path(s['directory'])/(name+'.2024'+ext))for ext in ['.mkv','.srt','.flac']]
 folder=pathlib.Path(s['target'])/(name+' (2024)')
 paths += [str(folder/(name+' (2024)'+ext))for ext in ['.mkv','.srt','.flac','.nfo']]
 proof['storage_history_files'][name]={'files':[file(p)for p in paths],'target_parent_exists':folder.exists()}
import sqlite3
con=sqlite3.connect('file:'+s['data_dir']+'/light-media.db?mode=ro',uri=True)
proof['history_removal_receipts']=[]
for kind,key,payload in con.execute("SELECT kind,id,payload FROM records WHERE kind IN ('history_target_removal','history_source_removal','history_parent_cleanup')"):
 if kind=='history_parent_cleanup':
  proof['history_removal_receipts'].append({'kind':kind,'id':key,'sealed_sha256':hashlib.sha256(payload).hexdigest()});continue
 value=json.loads(payload);f=value.get('File',value.get('file',{}));proof['history_removal_receipts'].append({'kind':kind,'id':key,'state':value.get('State',value.get('state')),'path':f.get('path'),'deleted':f.get('deleted',False),'operation_sha256':hashlib.sha256(f.get('source_operation','').encode()).hexdigest()})
con.close()
(r/('transfer-module29-observed-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
print({'mode':mode,'source_pid':proof['source']['pid'],'clone_pid':proof['clone']['pid'],'source_calls':proof['source']['calls'],'clone_calls':proof['clone']['calls'],'target':proof['target'],'related_targets':[x['target']for x in proof['related']]})
