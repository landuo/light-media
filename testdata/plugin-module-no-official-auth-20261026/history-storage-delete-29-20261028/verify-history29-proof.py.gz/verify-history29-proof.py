import json,pathlib,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A')
def load(mode):return json.loads((r/('transfer-module29-observed-'+mode+'.json')).read_text())
def calls(p,who):return p[who]['calls'].get('module_storage_delete',0)
def files(p,name):return p['storage_history_files'][name]['files']
failed=load('source-false-after');cold=load('cold-after-false');cloned=load('source-clone-deleted');main=load('main-target-clone-deleted');parent=load('parent-deleted-after-r2');final=load('final-cold-after-parent');rejected=load('final-target-false-after');last=load('final-cold-after-target-false')
assert all(x is not None for x in files(failed,'StorageHistorySourceFalse')[:6]), 'false removed a physical file'
assert files(failed,'StorageHistorySourceFalse')==files(cold,'StorageHistorySourceFalse')
assert calls(failed,'source')==1 and calls(failed,'clone')==0
assert calls(cold,'source')==calls(cold,'clone')==0
assert cold['source']['pid']!=failed['source']['pid'] and cold['clone']['pid']!=failed['clone']['pid']
assert calls(cloned,'source')==calls(cloned,'clone')==1
f=files(cloned,'StorageHistorySourceFalse');assert f[1] is None and all(f[i] is not None for i in [0,2,3,4,5])
assert calls(main,'source')==calls(main,'clone')==2
f=files(main,'StorageHistorySourceFalse');assert f[1] is None and f[3] is None and all(f[i] is not None for i in [0,2,4,5])
assert f[0]['sha256']==files(failed,'StorageHistorySourceFalse')[0]['sha256']
assert calls(parent,'source')==calls(parent,'clone')==1
for p in [parent,final,last]:
 f=files(p,'BrowserHistoryParent');assert f[0] is not None and f[3] is None and f[6] is None
 assert not p['storage_history_files']['BrowserHistoryParent']['target_parent_exists']
assert calls(final,'source')==calls(final,'clone')==0
assert calls(rejected,'source')==1 and calls(rejected,'clone')==0
assert all(x is not None for x in files(rejected,'StorageHistoryTargetFalse')[:6])
assert files(rejected,'StorageHistoryTargetFalse')==files(last,'StorageHistoryTargetFalse')
assert calls(last,'source')==calls(last,'clone')==0
assert last['source']['pid']!=rejected['source']['pid']
for p,name,count in [(failed,'StorageHistorySourceFalse',3),(cloned,'StorageHistorySourceFalse',2),(main,'StorageHistorySourceFalse',1),(parent,'BrowserHistoryParent',0),(rejected,'StorageHistoryTargetFalse',1),(last,'StorageHistoryTargetFalse',1)]:
 items=p['history']['data']['items']; assert len([x for x in items if name in x['source']])==count,(p['mode'],name,count)
proof={'passed':True,'scope':'Actual Linux server, ordinary SDK source/clone, browser actions, physical bytes/inodes and independent history projection. The pre-r2 directory FileItem failure is retained separately. Final cold starts perform no storage writes.','main_sha256':hashlib.sha256((r/'server-platform29-20261027-linux').read_bytes()).hexdigest(),'final_cli_test_sha256':hashlib.sha256((r/'process-platform29-20261027-linux.test').read_bytes()).hexdigest(),'pid_pairs':[[p['source']['pid'],p['clone']['pid']]for p in [failed,cold,parent,final,last]],'observations':[p['mode']for p in [failed,cold,cloned,main,parent,final,rejected,last]]}
proof['ui_driver_sha256']='65f7e99c24b6574c95f99bc18323607c6b15f8fd0be0c6dd5af6ade33e0b5f44'
proof['ui_main_revisions']=[{'sha256':'1b0a76c8d91a71532936e41e942609c50e249a085327b677a3c7c5427eb37776','scope':'source false, None-clone source removal, main target isolation; parent cleanup failed before directory dispatch'}, {'sha256':'717fa94193a0e59040f7ebc554ec68bf2e206da9b9a69965aed11f2aba10234d','scope':'cold resume of the actual failed parent cleanup'}, {'sha256':proof['main_sha256'],'scope':'cold preservation and target false deletion; final CLI and SDK tests are separate'}]
(r/'history29-browser-assertions.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
