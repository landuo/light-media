{
  "go_version": "go version go1.26.2 darwin/arm64",
  "environment": {
    "GOOS": "linux",
    "GOARCH": "amd64",
    "CGO_ENABLED": "0"
  },
  "binaries": [
    {
      "name": "server-platform29-20261027-linux",
      "sha256": "717fa94193a0e59040f7ebc554ec68bf2e206da9b9a69965aed11f2aba10234d",
      "command": [
        "go",
        "build",
        "-trimpath",
        "-o",
        "/Users/accidia/projects/light-media/work/plugin-no-official-auth-20261026/server-platform29-20261027-linux",
        "./cmd/server"
      ],
      "inputs": 3712,
      "changed": [],
      "elapsed_seconds": 3.89
    },
    {
      "name": "process-platform29-20261027-linux.test",
      "sha256": "d823d75175cbfc394bd8a12cf5aab0c9f1fd6cd8f15360ca9d927d4c967cee4a",
      "command": [
        "go",
        "test",
        "-c",
        "-o",
        "/Users/accidia/projects/light-media/work/plugin-no-official-auth-20261026/process-platform29-20261027-linux.test",
        "./internal/app"
      ],
      "inputs": 4168,
      "changed": [],
      "elapsed_seconds": 7.43
    }
  ]
}
