import json,pathlib,http.cookiejar,urllib.request,sys,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module34-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
if mode in ['fail','restore']:
 cfg=dict(s['source_config'])
 cfg['modules']={k:v for k,v in cfg['modules'].items()if k not in ['list_files','get_parent_item']}
 if mode=='fail':cfg['media_result']=False
 req('PUT','/api/plugins/'+s['source'],cfg)
def file(p):
 p=pathlib.Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=req('GET','/api/history/transfers?q=OwnedUITransfer')['data']
proof={'mode':mode,'history':h,'files':[file(p)for p in [s['ui_plan']['files'][0]['source'],s['expected_module_target']]+s['related_sources']+s['expected_related_targets']],'plans':[p for p in req('GET','/api/import/plans')['data']if any('OwnedUITransfer' in f['source']for f in p['files'])],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot')}
(r/('auto34-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print({'mode':mode,'pids':[proof[k]['pid']for k in ['source','clone']],'calls':[proof[k]['calls']for k in ['source','clone']],'histories':[(h['source'],h['status'])for h in h['items']]})
