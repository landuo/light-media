import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'auto34-runtime'
def read(n):return json.loads((r/('auto34-browser-'+n+'.json')).read_text())
f,x,p,a,c=map(read,['fail','rejected','preview','complete','cold-reloaded'])
assert f['history']['total']==0 and x['history']['total']==1 and x['history']['items'][0]['status']=='failed'
for d in [f,x,p]:
 assert all(d['files'][i].get('exists') is False for i in [1,4,5])
 assert all(d['files'][i]==f['files'][i]for i in [0,2,3])
assert x['source']['calls']['module_search_media']-f['source']['calls']['module_search_media']==2
assert x['source']['calls'].get('module_images',0)==x['source']['calls'].get('module_transfer',0)==0
assert p['source']['calls']['module_search_media']-x['source']['calls']['module_search_media']==1
assert p['source']['calls']['module_images']==1 and p['source']['calls']['module_transfer']==3
assert a['source']['calls']['module_search_media']-p['source']['calls']['module_search_media']==1
assert a['source']['calls']['module_images']==2 and a['source']['calls']['module_transfer']==6
assert a['history']==c['history'] and a['files']==c['files'] and a['history']['total']==3
assert {h['status']for h in a['history']['items']}=={'success'}
main=next(h for h in a['history']['items']if h['source'].endswith('.mkv'))
assert main['id']==x['history']['items'][0]['id']
for i,j in [(0,1),(2,4),(3,5)]:
 for k in ['inode','device','size','sha256']:assert a['files'][i][k]==a['files'][j][k]
for k in ['source','clone']:
 assert a[k]['pid']!=c[k]['pid']
 for method in ['module_search_media','module_images','module_transfer','module_execute']:assert c[k]['calls'].get(method,0)==0
for name in ['05-three-success-history','06-cold-three-success-history']:
 dom=(b/'auto34-browser'/(name+'.dom.txt')).read_text();assert '1 - 3 / 3' in dom and dom.count('成功')>=3
for name in ['01-auto-preview-failed','02-auto-actual-failed-retained']:
 dom=(b/'auto34-browser'/(name+'.dom.txt')).read_text();assert '插件未识别到媒体信息' in dom and 'TheMovieDb编号' in dom
for call in a['source']['transfer_calls']:
 assert call['kwargs']['mediainfo']['poster_path']=='plugin-poster'
result={'passed':True,'kind':'Actual Linux server and browser actions with synthetic owned files and SDK media','pids':[[d[k]['pid']for k in ['source','clone']]for d in [a,c]],'stable_primary_history_id':main['id'],'success_histories':3,'cold_write_calls':0,'files':c['files']}
(b/'auto34-browser-verdict.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in result.items()if k!='files'})
