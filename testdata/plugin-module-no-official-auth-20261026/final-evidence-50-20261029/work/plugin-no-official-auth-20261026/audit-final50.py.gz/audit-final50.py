import gzip,hashlib,json,re,subprocess
from pathlib import Path
from collections import Counter
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';sha=lambda b:hashlib.sha256(b).hexdigest();errors=[];artifacts=[];manifests=[]
for p in sorted((r/'testdata/plugin-module-no-official-auth-20261026').rglob('manifest.json')):
 d=json.loads(p.read_text());manifests.append({'path':str(p.relative_to(r)),'sha256':sha(p.read_bytes())})
 for a in d.get('artifacts',[]):
  target=r/a['path']
  if not target.is_file():errors.append({'missing':a['path']});continue
  stored=target.read_bytes();raw=gzip.decompress(stored)if target.suffix=='.gz'else stored;rawhash,storedhash=sha(raw),sha(stored)
  if 'stored_sha256'in a:
   if a['stored_sha256']!=storedhash or a['sha256']!=rawhash:errors.append({'manifest':str(p.relative_to(r)),'mismatch':a['path'],'kind':'stored/raw'})
   convention='explicit stored_sha256 and raw sha256'
  elif 'raw_sha256'in a:
   if a['raw_sha256']!=rawhash or a['sha256']!=storedhash:errors.append({'manifest':str(p.relative_to(r)),'mismatch':a['path'],'kind':'raw/stored'})
   convention='explicit raw_sha256 and stored sha256'
  else:
   if a['sha256'] not in [storedhash,rawhash]:errors.append({'manifest':str(p.relative_to(r)),'mismatch':a['path'],'kind':'single hash'})
   convention='stored-only'if a['sha256']==storedhash else'raw-only'
  artifacts.append({'manifest':str(p.relative_to(r)),'path':a['path'],'stored_sha256':storedhash,'raw_sha256':rawhash,'convention':convention})
# Validate every explicit fixed source location in the unique table, not current dirty reference files.
lines=[l for l in (r/'docs/plugin-module-parity-matrix.md').read_text().splitlines()if re.match(r'^\| \d\d ·',l)];sources=[];indices=[];contents={}
for l in lines:
 parts=l.split('|');idx=int(parts[1].strip()[:2]);state=parts[-2].strip();indices.append({'index':idx,'state':state,'source':parts[2].strip(),'target':parts[3].strip(),'difference':parts[4].strip(),'evidence':parts[5].strip()})
 for tree,path,location in re.findall(r'\b([BF])/([^`<>;；\s:]+):(\d+(?:[-–,]\d+)*)',parts[2]):
  key=(tree,path)
  if key not in contents:
   fixed='8a83efeacd3e26b82be495e17d50146e31c96a60'if tree=='B'else'2829e3b08214348f05ff2f5beae644882eccad58';root='/Users/accidia/projects/MoviePilot'+(''if tree=='B'else'-Frontend')
   x=subprocess.run(['git','show',fixed+':'+path],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   if x.returncode:errors.append({'missing_source':path,'index':idx});continue
   contents[key]=x.stdout
  numbers=[int(n)for n in re.findall(r'\d+',location)];valid=all(0<n<=len(contents[key].splitlines())for n in numbers)
  if not valid:errors.append({'invalid_source_line':path+':'+location,'index':idx})
  sources.append({'index':idx,'tree':tree,'path':path,'location':location,'sha256':sha(contents[key]),'valid':valid})
# Current build inputs are still unchanged. Binary cleanup is allowed only after this check.
build=json.loads((w/'platform55r2-result.json').read_text());changed=[]
for b in build['binaries']:
 for path,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():
  p=Path(path)
  if not p.is_file()or sha(p.read_bytes())!=h:changed.append(path)
 binary=w/b['name']
 if binary.is_file():
  if sha(binary.read_bytes())!=b['sha256']:errors.append({'binary_mismatch':b['name']})
 else:
  cleanup=json.loads((w/'final50-local-cleanup.json').read_text())
  recorded=next((x for x in cleanup['removed_binaries'] if Path(x['path']).name==b['name']),None)
  if not recorded or recorded['sha256']!=b['sha256']:errors.append({'missing_cleanup_hash':b['name']})
assert len(indices)==50
out={'artifacts':artifacts,'manifests':manifests,'source_locations':sources,'indices':indices,'errors':errors,'current_build_changed':sorted(set(changed)),'summary':{'manifests':len(manifests),'artifact_records':len(artifacts),'unique_artifacts':len({x['path']for x in artifacts}),'source_locations':len(sources),'states':dict(Counter(x['state']for x in indices))}}
(w/'final50-audit-preliminary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out['summary'],ensure_ascii=False));print('errors',errors,'changed',len(set(changed)));raise SystemExit(bool(errors or changed))
