import gzip,hashlib,json,re
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';errors=[];records=[];cache={}
def values(p):
 if p not in cache:
  stored=(r/p).read_bytes();raw=gzip.decompress(stored)if p.endswith('.gz')else stored;cache[p]=(hashlib.sha256(stored).hexdigest(),hashlib.sha256(raw).hexdigest())
 return cache[p]
def walk(value,doc):
 if isinstance(value,dict):
  p=value.get('path');keys=set(value)&{'sha256','sha256_uncompressed','uncompressed_sha256','raw_sha256','stored_sha256'}
  if isinstance(p,str)and p.startswith('testdata/')and keys:
   if not(r/p).is_file():errors.append({'document':doc,'missing':p})
   else:
    stored,raw=values(p)
    for key in keys:
     expected=value[key]
     if not isinstance(expected,str):continue
     actual=raw if key in ['sha256_uncompressed','uncompressed_sha256','raw_sha256']or key=='sha256'and'stored_sha256'in value else stored
     if expected!=actual and not(key=='sha256' and expected in [stored,raw]):errors.append({'document':doc,'mismatch':p,'key':key})
    records.append({'document':doc,'path':p,'stored_sha256':stored,'raw_sha256':raw})
  for x in value.values():walk(x,doc)
 elif isinstance(value,list):
  for x in value:walk(x,doc)
for p in (r/'docs/validation').rglob('*.json'):
 if 'plugin' in p.name or any(part.startswith('plugin-') for part in p.parts):walk(json.loads(p.read_text()),str(p.relative_to(r)))
rows=[]
for line in (r/'docs/plugin-module-parity-matrix.md').read_text().splitlines():
 if not re.match(r'^\| \d\d ·',line):continue
 cells=line.split('|');idx=int(cells[1].strip()[:2]);state=cells[-2].strip();targets=[];refs=[]
 if state=='按用户要求排除':continue
 for name in re.findall(r'`([^`]+)`',cells[3]):
  if name in ['本表与当前任务说明']:continue
  candidates=[r/name,r/'internal/app'/name,r/'internal'/name,r/'internal/plugins'/name,r/'web/src'/name,r/'web/src/components'/name,r/'web/src/features'/name]
  found=next((str(p.relative_to(r)) for p in candidates if p.exists()),None)
  if not found:errors.append({'index':idx,'target_unresolved':name})
  else:targets.append(found)
 for ref in re.findall(r'(?:validation|testdata)/[a-zA-Z0-9_./-]+',cells[5]):
  p=r/ref if ref.startswith('testdata/')else r/'docs'/ref
  if p.is_file()or p.is_dir():refs.append(str(p.relative_to(r)))
  elif (Path(str(p)+'.gz')).is_file():refs.append(str(Path(str(p)+'.gz').relative_to(r)))
  else:errors.append({'index':idx,'evidence_unresolved':ref})
 rows.append({'index':idx,'state':state,'resolved_targets':targets,'resolved_evidence':refs})
out={'hashed_evidence_records':len(records),'unique_hashed_evidence':len(cache),'records':records,'indices':rows,'errors':errors};(w/'final50-extra.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('evidence records',len(records),'unique',len(cache),'errors',errors);raise SystemExit(bool(errors))
