import hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path.cwd();w=root/'work/plugin-no-official-auth-20261026';magic={b'\x7fELF',b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xce\xfa\xed\xfe',b'\xca\xfe\xba\xbe'}
processes=subprocess.check_output(['ps','-Ao','pid,ppid,args'],text=True).splitlines();active=[x for x in processes if '/work/plugin-no-official-auth-20261026/'in x and 'cleanup-final50.py'not in x and 'exec_command'not in x and '/bin/zsh -lc'not in x];assert not active,active
binaries=[]
for p in sorted(w.iterdir()):
 if not p.is_file()or p.is_symlink():continue
 with p.open('rb')as f:header=f.read(4)
 if header not in magic:continue
 # All selected paths are task-owned ignored build outputs, never source or caches.
 assert subprocess.run(['git','check-ignore','-q',str(p)],cwd=root).returncode==0
 binaries.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});p.unlink()
removed=[]
for name in ['final54-tmp']:
 p=w/name
 if p.exists():shutil.rmtree(p);removed.append(str(p.relative_to(root)))
report={'active_task_processes':active,'removed_binaries':binaries,'removed_test_directories':removed,'remaining_top_level_binaries':[],'bytes_reclaimed':sum(x['bytes']for x in binaries),'preserved':'Source, existing dirty edits, evidence/logs/scripts, default Go/npm caches, and all other work directories.'}
(w/'final50-local-cleanup.json').write_text(json.dumps(report,indent=2)+'\n');print('Removed',len(binaries),'owned build outputs,',round(report['bytes_reclaimed']/1048576,1),'MiB; removed final54 temp data')
