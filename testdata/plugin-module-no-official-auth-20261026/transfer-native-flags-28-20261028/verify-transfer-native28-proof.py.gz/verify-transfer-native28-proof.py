import json,pathlib,sqlite3,hashlib,os
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');state=json.loads((r/'transfer-module28-ui-state.json').read_text())
def read(n):return json.loads((r/('transfer-module28-observed-'+n+'.json')).read_text())
b=read('native-ready');p=read('native-preview');before=read('native-cold-before-execution');actual=read('native-executed');cold=read('native-cold-after-execution')
sources={b['input']['path']}|{v['input']['path']for v in b['related']}
for v in [p,before,actual,cold]:
 assert v['input']==b['input']and [x['input']for x in v['related']]==[x['input']for x in b['related']]
 assert v['target']is None and all(x['target']is None for x in v['related'])
 for role in ['source','clone']:assert v[role]['calls'].get('module_execute',0)==0 and v[role]['calls'].get('module_transfer',0)==0
assert p['native_target']is None and all(v is None for v in p['native_related'])
assert before['native_target']is None and all(v is None for v in before['native_related'])
for name,v in [('actual',actual),('cold',cold)]:
 for source,target in [(v['input'],v['native_target'])]+[(x['input'],target)for x,target in zip(v['related'],v['native_related'])]:
  assert target and all(source[k]==target[k]for k in ['inode','device','size','sha256']),(name,source,target)
for role in ['source','clone']:
 events=actual[role].get('transfer_events')or[]
 assert len(events)==3 and {x['type']for x in events}=={'transfer.complete','transfer.subtitle.complete','transfer.audio.complete'}
 assert {x['data']['fileitem']['path']for x in events}==sources
 assert len({x['data']['transfer_history_id']for x in events})==3
 assert all(x['data']['transferinfo']['need_notify']is False and x['data']['transferinfo']['need_scrape']is False and len(x['data']['transferinfo']['fileitem'])==15 for x in events)
 assert p[role]['pid']!=before[role]['pid']and actual[role]['pid']!=cold[role]['pid']
 assert all(cold[role]['calls'].get(method,0)==0 for method in ['transfer_event','transfer_chain_event','module_storage_parent','module_storage_siblings','module_execute','module_transfer'])
con=sqlite3.connect('file:'+state['data_dir']+'/light-media.db?mode=ro',uri=True)
def records(kind):return [json.loads(v[0])for v in con.execute('SELECT payload FROM records WHERE kind=?',(kind,))]
plans=[p for p in records('import_plan')if any(f['source']==b['input']['path']for f in p['files'])]
previews=[p['id']for p in plans if p['state']=='preview'];assert len(previews)==3
jobs=[(i,s,json.loads(p))for i,s,p in con.execute("SELECT id,state,payload FROM jobs WHERE kind='import'")]
assert not any(p.get('id')in previews for i,s,p in jobs)
imported=[p for p in plans if any(f['source']==b['input']['path']and f['status']=='imported'for f in p['files'])];assert len(imported)==1
owned_jobs=[(i,s)for i,s,p in jobs if p.get('id')==imported[0]['id']];assert len(owned_jobs)==1 and owned_jobs[0][1]=='succeeded'
receipts=[x for x in records('import_receipt')if x['source']in sources];assert len(receipts)==3 and all(x['state']=='published'and not x.get('original_module_started')and not x.get('original_module_result')for x in receipts)
callbacks=[x for x in records('original_transfer_callback')if x['file']['source']in sources];assert len(callbacks)==3
assets=[x for x in records('asset')if x.get('source_path')==b['input']['path']];assert len(assets)==1 and assets[0]['scrape_state']=='skipped'
assert con.execute("SELECT COUNT(*) FROM jobs WHERE kind='scrape'AND json_extract(payload,'$.id')=?",(assets[0]['id'],)).fetchone()[0]==0
meta=next(x for x in records('import_meta')if x.get('original_transfer')and imported[0]['files'][0]['id']in x['original_transfer'])
primary=meta['original_transfer'][imported[0]['files'][0]['id']]
assert all(x['original_transfer']['meta']==primary['meta']and x['original_transfer']['mediainfo']==primary['mediainfo']and len(x['original_fileitem'])==15 for x in meta['sidecars'][imported[0]['files'][0]['id']])
held=json.loads((r/'transfer-module28-held-ui-state.json').read_text());assert held['completed_job']['state']=='succeeded'and held['source_still_exists']and held['target_still_exists']
published=next(x for x in records('import_receipt')if x['source']==held['selected']['source']and x['target']==held['selected']['target'])
for name,snapshot in [('source','source_snapshot'),('target','stage_snapshot')]:
 st=os.stat(held['selected'][name]);v=published[snapshot];assert (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(v['device'],v['inode'],v['size'],v['mod_ns'])
assert not any(x.get('file_id')==held['selected']['file_id']for x in records('transfer_history_hidden'))
proof={'passed':True,'kind':'actual Linux cmd/server + IAB61 synthetic owned native files','preview_plans':len(previews),'preview_jobs':0,'actual_jobs':owned_jobs,'actual_receipts':3,'native_module_calls':0,'native_callbacks':3,'ordinary_events':6,'notification_flags':False,'scrape_flags':False,'scrape_state':'skipped','scrape_jobs':0,'fileitem_fields':15,'related_metadata_inherited':True,'source':b['input'],'target':actual['native_target'],'related':list(zip(b['related'],actual['native_related'])),'cold_pids':[[v[role]['pid']for role in ['source','clone']]for v in [p,before,cold]],'held_real_job':held['completed_job']['id'],'held_source_and_target_preserved':True,'held_history_not_hidden':True}
(r/'transfer-native28-browser-assertions.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)

last=read('native-cold-after-held')
assert last['native_target']==actual['native_target']and last['native_related']==actual['native_related']
assert last['input']==b['input']and [x['input']for x in last['related']]==[x['input']for x in b['related']]
for role in ['source','clone']:
 assert last[role]['pid']!=cold[role]['pid']
 assert all(last[role]['calls'].get(m,0)==0 for m in ['module_execute','module_transfer','transfer_event','transfer_chain_event'])
proof['third_cold_pids']=[last['source']['pid'],last['clone']['pid']]
proof['failed_delete_not_replayed_after_cold']=True
(r/'transfer-native28-browser-assertions.json').write_text(json.dumps(proof,indent=2)+'\n');print({'third_cold_preserved':True,'pids':proof['third_cold_pids']})
