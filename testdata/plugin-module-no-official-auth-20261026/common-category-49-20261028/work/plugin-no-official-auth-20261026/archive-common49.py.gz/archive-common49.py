import gzip,hashlib,json,subprocess
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'common49-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/common-category-49-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest();build=json.loads((w/'platform49-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for p,seconds in [(w/'categories49-related.log','22.806s'),(w/'categories49-race.log','48.266s'),(remote/'common49-cli.log','601.73s'),(remote/'common49-ui.log','375.06s')]:assert seconds in p.read_text()and 'PASS' in p.read_text()
proof=json.loads((remote/'common49-cli-evidence/common-category49-proof.json').read_text());tick=next(x for x in proof if x.get('mode')=='actual-ten-minute-tick');assert 599<=tick['elapsed_seconds']<=620
assert all(x['calls']['module_execute']==1 for x in tick['after'])
browser={n:json.loads((remote/('common49-browser-'+n+'.json')).read_text())for n in ['saved','invalid','restore','manual','cold','final']}
assert browser['saved']['rules']['body']['data']['configuration']['groups'][0]['category']=='分身电影'
assert browser['invalid']['rules']['status']==500
assert browser['restore']['rules']['status']==200
for k in ['source','clone']:
 assert browser['manual'][k]['body']['calls']['module_execute']==1
 assert browser['manual'][k]['body']['pid']!=browser['cold'][k]['body']['pid']
 assert browser['cold']['before'][k]['body']['calls'].get('module_execute',0)==0
 assert browser['cold']['before'][k]['body']['calls'].get('module_page_size',0)==0
 assert browser['final'][k]['body']['calls'].get('module_execute',0)==0
assert browser['final']['rules']['body']['data']['configuration']['groups']==browser['saved']['rules']['body']['data']['configuration']['groups']
assert json.loads((remote/'common49-cleanup.json').read_text())['remaining_test_roots']==[]
f='src/views/setting/AccountSettingRule.vue';fr=subprocess.check_output(['git','show','2829e3b08214348f05ff2f5beae644882eccad58:'+f],cwd='/Users/accidia/projects/MoviePilot-Frontend');assert b"api.get('media/category')"in fr
(w/'common49-browser-verdict.json').write_text(json.dumps({'pass':True,'iab':88,'actual_clock_seconds':tick['elapsed_seconds'],'pids':{k:[browser[n][k]['body']['pid']for n in ['manual','cold']]for k in ['source','clone']},'fixed_frontend':{f:sha(fr)},'saved_group':browser['final']['rules']['body']['data']['configuration']['groups'],'cleanup':True},ensure_ascii=False,indent=2)+'\n')
targets=['internal/app/'+n for n in ['plugin_original_media_categories.go','priority_rules_settings.go','plugin_original_common_scheduler.go','plugin_original_direct_dispatch.go','plugin_original_service_progress.go','runtime.go','plugin_original_common_scheduler_test.go','plugin_original_media_categories_test.go','plugin_module_process_common_categories_test.go','plugin_module_process_services_test.go']]
paths={r/p for p in targets}
for pattern in ['*media-category*','*common-scheduler*']:paths.update((r/'testdata/standard-module-host').glob(pattern))
for pattern in ['common49-*','categories49-*','platform49*.json','build-platform49.py','run-common49.py','archive-common49.py','*platform49*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/chain/__init__.py:298-490,2014-2019 media_category actual None/list/scalar dispatcher','app/api/endpoints/media.py:325-330 falsey -> {}; dict response model rejects nonempty list','src/views/setting/AccountSettingRule.vue:53 actual rule category load','app/scheduler.py:468-472,653-661 common timer 10 minutes;1392-1458 list','app/chain/__init__.py:2039-2043 scheduler_job void wrapper'],'targets':targets,'behavior':['Existing rules GET asks media_category before native policy; None/list/terminal/error behavior follows source; plugin calls run without settings mutex to allow host reads. Classifying a media title is unchanged.','Common scheduler_job registers once per actual server start with 10-minute initial/next interval, uses existing scheduler admission/progress/manual API, and discovers enabled plugin/clone modules at execution. Plugin stop/reload never removes system timer.','Wrapper discards provider result like source; false cuts provider sequence but is not a scheduler failure. Running system row stays in clock order with remaining time, unlike separately extracted running plugin rows.'],'evidence':{'source_category_cases':8,'source_common_cases':5,'real_sdk_seconds':4.314,'related_seconds':22.806,'race_seconds':48.266,'linux_cli_seconds':601.73,'actual_first_clock_seconds':tick['elapsed_seconds'],'linux_browser_gate_seconds':375.06,'browser':'IAB88 real Linux service: clone category select/save; invalid list500 visible error; retry restores saved group; manual source/clone each1; real cold newPIDs and no replay, saved category and timer recovered; uninstall404/ownedTempDir removed.','manifest':str((dest/'manifest.json').relative_to(r)),'build':build},'adaptations':['Source category endpoint is represented in existing /settings/rules response; same dict result/errors consumed by native rule editor. No new category-policy business editor is introduced.','Go service uses existing 100ms scheduler and interval trigger; one system job entry, no workflow/AI extension or new scheduler framework. Source UTC-independent 10-minute duration retained.','SDK tests use a backdated anchor solely to exercise the existing ticker quickly; separate actual Linux process waited600.1878seconds without clock injection.','SDK errors retain Go error diagnostics; arbitrary Python exception tracebacks are not fabricated.'],'remaining':['43: full197methods/199ordinarycallsite applicability audit; identified file detail download/image download_file native entry remains unwired.','50: final scope evidence audit after43 closes.'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-common-category-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';data=json.loads(p.read_text());data['common_category_49_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-common-category-20261028.json'};p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46验收通过，新增43分类/公共服务增量已封存：media_category规则页接入、scheduler_job原版10分钟公共模块入口已补。固定8+5AST/实际SDK4.314s、相关22.806s/race48.266s；main5a6602ae/test178e9e4d的3733/4221输入稳定，Linux601.73s实际等待600.1878秒且来源/分身各1次自动调用；IAB88门375.06s实际分类保存/500错误/重试/公共服务手动执行及冷启新PID0重放保持。详validation/plugin-common-category-20261028.json；owned进程/目录/IAB88/34468已清理。第43最终审计又发现文件详情下载/图片预览尚未经过download_file模块，继续补；197方法/199普通调用及50未完成，无外部阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts; actual10minute tick and browser verified,44/46 unchanged')
