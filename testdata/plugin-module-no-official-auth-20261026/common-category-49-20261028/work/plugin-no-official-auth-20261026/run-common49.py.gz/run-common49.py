import pathlib,os,sys,subprocess,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');os.chdir(r);mode=sys.argv[1];tmp=r/('common49-'+mode+'-tmp');tmp.mkdir(exist_ok=True)
names=['server-platform49-20261027-linux','process-platform49-20261027-linux.test','bluray44-worker-linux']
for n in names:(r/n).chmod(0o700)
print({n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names},flush=True)
env=os.environ|{'TMPDIR':str(tmp),'PLUGIN_PROCESS_SERVER_BINARY':str(r/names[0]),'OWNED_INPUT_PROCESS_FIXTURE_BINARY':str(r/'services38-input-final-linux'),'OWNED_TRANSFER_MODULE_PROCESS_BINARY':str(r/names[2]),'PLUGIN_PROCESS_COMMON_CATEGORY_FIXTURE':'true','PLUGIN_PROCESS_EVENTS36_EVIDENCE_DIR':str(r/('common49-'+mode+'-evidence'))}
if mode=='ui':env['PLUGIN_PROCESS_COMMON_CATEGORY_STATE']=str(r/'common49-ui-state.json')
if mode=='cli':env['PLUGIN_PROCESS_COMMON_WAIT']='true'
with(r/('common49-'+mode+'.log')).open('w')as f:p=subprocess.run([str(r/names[1]),'-test.run=^TestPluginServicesProductionCLI$','-test.v','-test.timeout=35m'],env=env,stdout=f,stderr=subprocess.STDOUT)
print((r/('common49-'+mode+'.log')).read_text()[-3000:]);raise SystemExit(p.returncode)
