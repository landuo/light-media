import hashlib,json,pathlib,sys,urllib.request,http.cookiejar
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module21-ui-state.json').read_text());mode=sys.argv[1];client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(method,path,body=None):
 data=json.dumps(body).encode()if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method))as response:return json.loads(response.read())
request('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
if mode in ['fail','restore','clone']:
 cfg=s['source_config'].copy()
 if mode=='fail':cfg['modules']['transfer']='module_execute';cfg['result']=False
 if mode=='clone':cfg['modules']['transfer']='module_execute';cfg['result']=None
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 if mode in ['restore','clone']:
  other={'enabled':True,'modules':{'transfer':'module_execute'},'result':None}
  if mode=='clone':other['result']={'__plugin_transfer_info':{'success':True,'target_item':{'storage':'local','type':'file','path':s['target']+'/Owned clone preview/ClonePreview.mkv','name':'ClonePreview.mkv'}}}
  assert request('PUT','/api/plugins/'+s['clone'],other)['data']['success']
source=request('GET','/api/v1/plugin/'+s['source']+'/snapshot');clone=request('GET','/api/v1/plugin/'+s['clone']+'/snapshot');plan=s['ui_plan'];input=pathlib.Path(plan['files'][0]['source']);target=pathlib.Path(plan['files'][0]['target'])
def file(p):
 if not p.exists():return None
 st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
proof={'mode':mode,'source':source,'clone':clone,'input':file(input),'target':file(target),'jobs':request('GET','/api/jobs'),'plans':request('GET','/api/import/plans'),'history':request('GET','/api/history/transfers')}
(r/('transfer-module21-observed-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n');print({'mode':mode,'source_pid':source['pid'],'clone_pid':clone['pid'],'source_calls':source['calls'],'clone_calls':clone['calls'],'input':proof['input'],'target':proof['target']})
