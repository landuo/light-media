import hashlib,json,pathlib,sys,urllib.request,http.cookiejar
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'browser-mutation16-ui-state.json').read_text());mode=sys.argv[1];client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(method,path,body=None):
 data=json.dumps(body).encode()if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method))as response:return json.loads(response.read())
request('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
empty={'enabled':True,'modules':{'create_folder':'module_execute','rename_file':'module_execute','delete_file':'module_execute'},'result':None}
if mode in ['fail','restore','clone']:
 config=s['mutation_config'].copy()
 if mode=='fail':config.update(storage_mode='no_effect',result=False)
 if mode=='clone':config=empty
 assert request('PUT','/api/plugins/'+s['source'],config)['data']['success']
 assert request('PUT','/api/plugins/'+s['clone'],s['mutation_config']if mode=='clone'else empty)['data']['success']
source=request('GET','/api/v1/plugin/'+s['source']+'/snapshot');clone=request('GET','/api/v1/plugin/'+s['clone']+'/snapshot');folder=pathlib.Path(s['directory']);entries=[]
for p in sorted(folder.rglob('*')):
 stat=p.stat();entry={'path':str(p.relative_to(folder)),'is_dir':p.is_dir(),'inode':stat.st_ino,'size':stat.st_size}
 if p.is_file():entry['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 entries.append(entry)
proof={'mode':mode,'source':source,'clone':clone,'entries':entries};(r/('browser-mutation16-observed-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n');print({'mode':mode,'source_pid':source['pid'],'clone_pid':clone['pid'],'source_calls':source['calls'],'clone_calls':clone['calls'],'entries':entries})
