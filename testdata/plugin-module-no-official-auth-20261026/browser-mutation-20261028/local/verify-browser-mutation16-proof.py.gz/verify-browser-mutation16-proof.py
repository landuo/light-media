import pathlib,json
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A')
def read(mode):return json.loads((r/('browser-mutation16-observed-'+mode+'.json')).read_text())
def calls(x,role,key):return x[role]['calls'].get(key,0)
def entry(x,name):return next(e for e in x['entries']if e['path']==name)
c,n,f,re,cl,cb,cn,d=[read(n)for n in ['created','renamed','failed-readback','recovered','clone-renamed','cold-before-ui','cold-renamed','deleted']]
assert entry(c,'OwnedUIWriter')['inode']==entry(n,'OwnedUIRenamed')['inode']==entry(cl,'OwnedUICloneRenamed')['inode']
assert calls(n,'source','module_storage_rename')==calls(c,'source','module_storage_rename')+1
assert calls(n,'clone','module_storage_rename')==calls(c,'clone','module_storage_rename')
assert calls(f,'source','module_storage_mkdir')==calls(n,'source','module_storage_mkdir')+1 and f['entries']==n['entries']
assert calls(re,'source','module_storage_mkdir')==calls(f,'source','module_storage_mkdir')+1 and entry(re,'OwnedUIRecovery')['is_dir']
assert calls(cl,'clone','module_storage_rename')==1 and calls(cl,'source','module_execute')==1
for role in ['source','clone']:
 assert cb[role]['pid']!=cl[role]['pid']
 assert calls(cb,role,'module_execute')==calls(cb,role,'module_storage_rename')==calls(cb,role,'module_storage_delete')==0
assert calls(cn,'source','module_execute')==1 and calls(cn,'clone','module_storage_rename')==1
assert entry(re,'OwnedUIRecovery')['inode']==entry(cn,'OwnedUIColdRenamed')['inode']
assert calls(d,'source','module_execute')==3 and calls(d,'clone','module_storage_delete')==2
assert d['entries']==[entry(c,'File10.mkv')]
proof={'passed':True,'kind':'actual Linux cmd/server and SDK plus UI actions recorded by IAB49; readonly owned filesystem/counter observations','checks':12,'source_before_pid':cl['source']['pid'],'clone_before_pid':cl['clone']['pid'],'source_after_pid':cb['source']['pid'],'clone_after_pid':cb['clone']['pid'],'final_preserved_file':d['entries'][0],'after_cold_source_calls':d['source']['calls'],'after_cold_clone_calls':d['clone']['calls']}
(r/'browser-mutation16-browser-assertions.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
(r/'browser-mutation16-ui-state.json.done').touch()
