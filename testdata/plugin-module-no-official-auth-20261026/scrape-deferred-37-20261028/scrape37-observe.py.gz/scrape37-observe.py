import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'scrape37-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
if mode in ['fail','restore']:
 cfg=dict(s['source_config']);cfg['result']=False if mode=='fail'else None
 req('PUT','/api/plugins/'+s['source'],cfg)
def file(p):
 p=pathlib.Path(p)
 if not p.is_file():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'size':st.st_size,'inode':st.st_ino,'device':st.st_dev,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=req('GET','/api/history/transfers?q=ScrapeBatchsuccess')['data']
proof={'mode':mode,'history':h,'source_files':[file(p)for p in s['paths']],'download_files':[file(p)for p in (pathlib.Path(s['source_path']).parents[1]/'source'/'ScrapeBatchsuccess').glob('*.mkv')],'target_files':[file(p)for p in pathlib.Path(s['target']).rglob('*')if p.is_file()],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot')}
# This is the owned test database, read only; never a second running App/store.
db=sqlite3.connect('file:'+str(pathlib.Path(s['data_dir'])/'light-media.db')+'?mode=ro',uri=True)
proof['batches']=[json.loads(x[0])for x in db.execute("SELECT payload FROM records WHERE kind='original_scrape_batch'")]
proof['scrape_jobs']=[dict(zip(['id','state','payload'],x))for x in db.execute("SELECT id,state,CAST(payload AS TEXT) FROM jobs WHERE kind='scrape'")]
for row in proof['scrape_jobs']:row['payload']=json.loads(row['payload'])
db.close()
(r/('scrape37-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'pids':[proof[k]['pid']for k in ['source','clone']],'metadata_events':[sum(e['type']=='metadata.scrape'for e in (proof[k]['transfer_events'] or []))for k in ['source','clone']],'histories':[(x['status'],x['target'])for x in h['items']],'target_files':len(proof['target_files'])})
