import pathlib,os,sys,subprocess,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');mode=sys.argv[1];tmp=r/('scrape37r5-'+mode+'-tmp');tmp.mkdir(exist_ok=True)
names=['server-platform37r5-20261027-linux','process-platform37r5-20261027-linux.test','scrape-batch36-worker-linux']
for n in names:(r/n).chmod(0o700)
print({n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names},flush=True)
env=os.environ|{'TMPDIR':str(tmp),'PLUGIN_PROCESS_SERVER_BINARY':str(r/names[0]),'OWNED_INPUT_PROCESS_FIXTURE_BINARY':str(r/'services38-input-final-linux'),'OWNED_TRANSFER_MODULE_PROCESS_BINARY':str(r/names[2]),'PLUGIN_PROCESS_SCRAPE_BATCH_FIXTURE':'true','PLUGIN_PROCESS_SCRAPE_DEFERRED_FIXTURE':'true','PLUGIN_PROCESS_SCRAPE_LEGACY_FIXTURE':'true','PLUGIN_PROCESS_EVENTS36_EVIDENCE_DIR':str(r/('scrape37r5-'+mode+'-evidence'))}
if mode=='ui':env['PLUGIN_PROCESS_SCRAPE_BATCH_STATE']=str(r/'scrape37r5-ui-state.json')
with(r/('scrape37r5-'+mode+'.log')).open('w')as f:p=subprocess.run([str(r/names[1]),'-test.run=^TestPluginServicesProductionCLI$','-test.v','-test.timeout=45m'],env=env,stdout=f,stderr=subprocess.STDOUT)
print((r/('scrape37r5-'+mode+'.log')).read_text()[-5000:]);raise SystemExit(p.returncode)
