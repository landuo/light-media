import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'scrape37-runtime'
def get(n):return json.loads((r/('scrape37r2-browser-'+n+'.json')).read_text())
i,p,f,cb,s,c=map(get,['initial','preview','failed','cold-before','success','cold-after'])
for d in [p,f,cb]:
 assert not d['target_files'] and d['source_files']==i['source_files'] and d['download_files']==i['download_files']
 assert not d['source']['transfer_events'] and not d['clone']['transfer_events']
assert p['history']==i['history']
assert sum(x['status']=='failed'for x in f['history']['items'])==1
ids={x['id']for x in i['history']['items']}
assert len(ids)==3
for d in [f,cb,s,c]:assert {x['id']for x in d['history']['items']}==ids
assert all(x['status']=='success'for x in s['history']['items'])
assert c['history']==s['history'] and c['target_files']==s['target_files'] and c['source_files']==s['source_files']
assert s['download_files']==i['download_files']==c['download_files'] and len(s['download_files'])==3
assert s['source_files'][0].get('exists') is False
videos=[x for x in s['target_files']if x['path'].endswith('.mkv')];nfos=[x for x in s['target_files']if x['path'].endswith('.nfo')]
assert len(videos)==1 and len(nfos)==3
for k in ['inode','device','size','sha256']:assert videos[0][k]==i['source_files'][0][k]
paths={videos[0]['path']}
for who in ['source','clone']:
 es=[x for x in s[who]['transfer_events']if x['type']=='metadata.scrape'];assert len(es)==1 and set(es[0]['data']['file_list'])==paths
 assert len({d[who]['pid']for d in [i,cb,c]})==3
 for d in [cb,c]:
  assert not d[who].get('transfer_events')
  for method in ['module_execute','module_metadata_nfo','transfer_event']:assert not d[who]['calls'].get(method,0)
bs=[x for x in s['batches']if any(set(t['event']['file_list'])==paths for t in (x['targets']or []))]
assert len(bs)==1 and bs[0]['closed'] and bs[0]['flushed']
js=[x for x in s['scrape_jobs']if set(x['payload'].get('original_metadata_event',{}).get('file_list',[]))==paths]
assert len(js)==1 and js[0]['state']=='succeeded'
clean=[x for x in s['cleanup_jobs']if set(x['payload'].get('original_metadata_event',{}).get('file_list',[]))==paths]
assert len(clean)==1 and clean[0]['state']=='succeeded' and clean[0]['payload']['original_scrape_batch']==bs[0]['id']
assert any(x['new_path']in paths and x['state']=='complete'for x in s['cleanups'])
for n in ['05-success-history-loaded','06-cold-history-loaded']:
 text=(b/'scrape37r2-browser'/(n+'.dom.txt')).read_text();assert '1 - 3 / 3'in text and text.count('成功')>=3
failure=(b/'scrape37r2-browser/02-failure-retained.dom.txt').read_text();assert '文件整理模块运行失败'in failure and 'sql: no rows'not in failure and '总数 1 · 失败 1'in failure
v={'passed':True,'kind':'Actual Linux main and IAB73 managed-file reorganization with owned SDK','history_ids':sorted(ids),'target_files':s['target_files'],'pids':[[d[k]['pid']for k in ['source','clone']]for d in [i,cb,c]],'metadata_events_per_instance':1,'scrape_jobs_per_root':1,'old_video_removed':True,'download_sources_unchanged':3,'cold_write_replay':0,'linux_cli_seconds':2.09,'linux_browser_gate_seconds':452.77}
(b/'scrape37-browser-verdict.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in v.items()if k!='target_files'})
