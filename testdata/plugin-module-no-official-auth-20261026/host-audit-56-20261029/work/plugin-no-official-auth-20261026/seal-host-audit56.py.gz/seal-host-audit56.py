import gzip,hashlib,json
from pathlib import Path
from collections import Counter
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.load(gzip.open(r/'testdata/standard-module-host/modules43-host-call-audit.json.gz'));reverse=json.loads((w/'modules54-resolved-callers.json').read_text());groups=json.loads((w/'modules54-scope-decisions.json').read_text())['groups']
assert len(reverse['source_sha256'])==529 and len(reverse['method_rows'])==231
for g in groups:
 g['source']=sorted(set(g.get('source',[])+[row['source'] for row in reverse['method_rows'] if row['method']in g['methods']]))
 if g['id']=='local_transfer_types':
  g['target']=['internal/app/plugin_original_transfer_types.go','internal/app/directory_manage.go','web/src/features/directory-transfer-types.ts','web/src/components/DirectoryManager.vue'];g['evidence']=['docs/validation/plugin-directory-transfer-types-20261029.json'];g['reason']='普通模块已接既有本地目录卡片。两次顺序查询、交集与首项回填、空/错误/保存/分身/冷恢复已实测；Go既有hardlink/copy/auto执行范围适配见报告。'
 if g['id']=='im_transport':
  g['reason']+=' 固定Web入口虽可达start/finish包装，但ChannelCapabilityManager的Web能力不含PROCESSING_STATUS；edit反馈因Web入口不提供message_id/chat_id先返回。不是因不存在外部provider而跳过合法插件。message_parser/webhook_parser只有独立外部消息接收端使用；delete/send_direct/finalize包装无固定普通宿主调用。'
  g['source']+=['app/schemas/message.py:556-565','app/chain/__init__.py:142-144','app/chain/__init__.py:179-182','app/chain/message.py:955-956','app/api/endpoints/message.py:140-148'];g['evidence']=['testdata/standard-module-host/module-web-guard-source-oracle.json']
 if g['id']=='ai_only_callers':g['scope']='excluded_by_user';g['state']='按用户要求排除'
 elif g['scope']=='existing_host':g['state']='验收通过'
 else:g['state']=None
 if g['id']=='transfer':
  g['evidence']=sorted(set(g['evidence']+[str(p.relative_to(r))for p in (r/'docs/validation').glob('plugin-transfer-*-20261028.json')]+['docs/validation/plugin-download-context-20261028.json']))
 if g['id']=='metadata_system_override':g['evidence']=['testdata/standard-module-host/metadata-module-oracle.json'];g['source']+=['app/chain/media.py:531-552']
 if g['id']=='ordinary_commands':g['reason']=g['reason'].replace('，最终需核对本报告引用的确切清单路径','，报告引用已核对')
 for p in g.get('target',[])+g.get('evidence',[]):assert (r/p.split(':')[0]).is_file(),(g['id'],p)
 g['evidence_sha256']={p:sha(r/p)for p in g.get('evidence',[])}
lookup={}
for g in groups:
 for method in g['methods']:
  assert method not in lookup;lookup[method]=g['id']
assert len(lookup)==197
rows=[]
for old,new in zip(original['source_call_rows'],reverse['method_rows']):
 assert old['source']==new['source'] and old['module_method']==new['method']
 g=next(g for g in groups if g['id']==lookup[new['method']])
 rows.append({**new,'source_signature':old['source_signature'],'module_keywords':old['module_keywords'],'group':g['id'],'scope':g['scope'],'status':g['state'],'target':g['target'],'evidence':g['evidence'],'difference':g['reason']})
indirect={'method':'post_message','source':['app/chain/__init__.py:71','app/chain/__init__.py:1631','app/helper/message.py:750-753'],'behavior':'MessageQueueManager receives ChainBase.run_module as callback and dispatches post_message after original queue/time/channel rules. Static direct run_module inventory does not include this method.','target':['internal/app/plugin_original_notice.go:44-63','internal/app/plugin_notice_delivery.go','internal/app/plugin_original_web_history.go'],'evidence':['docs/validation/plugin-module-no-official-auth-20261026.json','testdata/standard-module-host/evidence/messages42-modules43-true-callers-final-regression-tests.jsonl.gz','docs/validation/plugin-platform-regression-20261029.json'],'status':'验收通过'}
counts=Counter(g['scope']for row in rows for g in groups if g['id']==row['group']);method_counts=Counter({scope:sum(len(g['methods'])for g in groups if g['scope']==scope)for scope in {g['scope']for g in groups}})
audit={'fixed_backend':reverse['fixed_backend'],'fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source_sha256':reverse['source_sha256'],'scope':'Plugin platform and real callers in existing Go host only; no new business systems, workflow, AI, external IM or cloud storage. Boundary rows remain in the full inventory with source evidence, not deleted or claimed as executable target coverage.','direct_calls':231,'distinct_direct_methods':197,'indirect_callbacks':[indirect],'groups':groups,'call_rows':rows,'counts':{'direct_call_scopes':dict(counts),'method_scopes':dict(method_counts),'indirect_existing_host':1},'unresolved':[],'adaptation_boundary':'Generic plugin module declaration/dispatch remains open for ordinary names. Methods with no target business host do not get fabricated routes, placeholders or success stubs. Native-only override metadata_img must not inject plugin dispatch. Original scope draft incorrectly grouped local support_transtype as cloud; corrected and implemented in55.','limitations':['Reverse reachability uses statically resolved class receivers; unresolved receiver candidates are preserved for manual inspection and never counted as runtime proof. Web guards are separately replayed.','Real Linux/browser evidence is version-bound across incremental reports; replay, synthetic external providers and actual host processes are explicitly distinguished. No Python runtime ships with target.']}
path=r/'testdata/standard-module-host/modules56-final-host-audit.json.gz';path.write_bytes(gzip.compress((json.dumps(audit,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))
replay=r/'testdata/standard-module-host/modules56-resolved-callers.json.gz';replay.write_bytes(gzip.compress((w/'modules54-resolved-callers.json').read_bytes(),mtime=0))
# Preserve the audit programs and exact source guard proof, not generated binaries.
dest=r/'testdata/plugin-module-no-official-auth-20261026/host-audit-56-20261029';artifacts=[]
for p in [w/'audit-module-callers54.py',w/'seal-host-audit56.py',r/'testdata/standard-module-host/generate-module-web-guards.py',r/'testdata/standard-module-host/module-web-guard-source-oracle.json',w/'modules56-web-guards.log',path,replay]:
 raw=p.read_bytes();out=dest/p.relative_to(r);out.parent.mkdir(parents=True,exist_ok=True)
 if p.suffix!='.gz':out=Path(str(out)+'.gz');out.write_bytes(gzip.compress(raw,mtime=0))
 else:out.write_bytes(raw)
 artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':hashlib.sha256(gzip.decompress(raw)if p.suffix=='.gz'else raw).hexdigest(),'stored_sha256':sha(out)})
(dest/'manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n')
report={'accepted':True,'index':43,'fixed_backend':reverse['fixed_backend'],'fixed_frontend':audit['fixed_frontend'],'full_audit':str(path.relative_to(r)),'audit_sha256':sha(path),'manifest':str((dest/'manifest.json').relative_to(r)),'counts':audit['counts'],'ordinary_existing_host_methods_with_actual_evidence':69,'source_files_rechecked':529,'direct_calls_rechecked':231,'indirect_callbacks_rechecked':1,'unresolved':[],'scope_decisions':'All197 distinct direct methods and all231 sites retained.68 existing-host methods plus indirectpost_message have source→target→actual evidence. Other methods retain explicit caller/guard/business boundaries under the user instruction to avoid adding other business systems. AI-only callers are separately excluded by user.','regression':'docs/validation/plugin-platform-regression-20261029.json','last_runtime':'docs/validation/plugin-directory-transfer-types-20261029.json','remaining':['50 final evidence/hash/cleanup audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-module-host43-final-20261029.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'method_counts':dict(method_counts),'call_counts':dict(counts),'unresolved':audit['unresolved']},ensure_ascii=False))
