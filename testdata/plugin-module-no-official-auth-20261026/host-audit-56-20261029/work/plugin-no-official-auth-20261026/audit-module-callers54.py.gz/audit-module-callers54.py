"""Read-only pinned AST reverse call audit. Resolved class receivers only;
ambiguous dynamic receivers remain separate evidence, never counted as coverage.
"""
import ast,gzip,hashlib,io,json,pathlib,subprocess,tarfile
r=pathlib.Path.cwd();w=r/'work/plugin-no-official-auth-20261026';fixed='8a83efeacd3e26b82be495e17d50146e31c96a60';b='/Users/accidia/projects/MoviePilot'
tar=tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',fixed,'app'],cwd=b)));files={}
for f in tar.getmembers():
 if f.isfile()and f.name.endswith('.py'):files[f.name]=tar.extractfile(f).read()
trees={p:ast.parse(raw)for p,raw in files.items()};classes={};contexts={};parents={};functions={};edges=[];unresolved=[]
for p,t in trees.items():
 for n in ast.walk(t):
  for child in ast.iter_child_nodes(n):parents[id(child)]=n
  if isinstance(n,ast.ClassDef):classes.setdefault(n.name,[]).append((p,n))
def enclosing(n,typ):
 while id(n)in parents:
  n=parents[id(n)]
  if isinstance(n,typ):return n
 return None
for p,t in trees.items():
 for n in ast.walk(t):
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   c=enclosing(n,ast.ClassDef);key=p+':'+(c.name+'.'if c else'')+n.name;functions[key]=(p,c,n);contexts[id(n)]=key
# Imported class symbols resolve only where source class is unique; classes with
# the same generic names are intentionally left unresolved.
def class_name(n):
 if isinstance(n,ast.Name)and len(classes.get(n.id,[]))==1:return n.id
 return None
def find_method(c,m,seen=None):
 if c not in classes or len(classes[c])!=1:return None
 seen=set()if seen is None else seen
 if c in seen:return None
 seen.add(c);p,n=classes[c][0]
 if any(isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef))and f.name==m for f in n.body):return p+':'+c+'.'+m
 for base in n.bases:
  found=find_method(class_name(base),m,seen)
  if found:return found
 return None
for key,(p,c,fn)in functions.items():
 # Module globals and current function direct assignments; never borrow a
 # same-spelled variable from another endpoint or logger field.
 env={}
 nodes=list(trees[p].body)+list(fn.body)
 if c:
  init=next((x for x in c.body if isinstance(x,ast.FunctionDef)and x.name=='__init__'),None)
  if init:nodes+=list(ast.walk(init))
 nodes+=list(ast.walk(fn))
 for n in nodes:
  if isinstance(n,(ast.Assign,ast.AnnAssign)):
   v=n.value
   target=class_name(v.func)if isinstance(v,ast.Call)else None
   if target:
    for a in n.targets if isinstance(n,ast.Assign)else[n.target]:env[ast.unparse(a)]=target
 if c:env['self']=c.name;env['cls']=c.name
 for n in ast.walk(fn):
  if not isinstance(n,ast.Call)or not isinstance(n.func,ast.Attribute):continue
  receiver=n.func.value
  klass=class_name(receiver.func)if isinstance(receiver,ast.Call)else env.get(ast.unparse(receiver))
  target=find_method(klass,n.func.attr)
  row={'source':p+':'+str(n.lineno),'caller':key,'expression':ast.unparse(n.func)}
  if target:edges.append(row|{'callee':target})
  elif n.func.attr not in ['info','debug','error','warning','items','get','append','extend','send_event','put','format']:
   unresolved.append(row|{'method':n.func.attr})
audit=json.load(gzip.open(r/'testdata/standard-module-host/modules43-host-call-audit.json.gz'));rows=[]
for call in audit['source_call_rows']:
 p,ln=call['source'].rsplit(':',1);ln=int(ln)
 candidates=[(f.end_lineno-f.lineno,k)for k,(path,c,f)in functions.items()if path==p and f.lineno<=ln<=f.end_lineno];owner=min(candidates)[1]
 direct=[x for x in edges if x['callee']==owner]
 # Full reverse reachability, preserving every edge (no sample cutoff).
 seen={owner};front=[owner];reachable=[]
 while front:
  cur=front.pop()
  for x in edges:
   if x['callee']!=cur:continue
   reachable.append(x)
   if x['caller']not in seen:seen.add(x['caller']);front.append(x['caller'])
 rows.append({'method':call['module_method'],'source':call['source'],'owner':owner,'resolved_direct_callers':direct,'resolved_ancestors':reachable,'ambiguous_receiver_candidates':[x for x in unresolved if x['method']==owner.rsplit('.',1)[-1]]})
result={'fixed_backend':fixed,'source_sha256':{p:hashlib.sha256(raw).hexdigest()for p,raw in files.items()},'method_rows':rows,'note':__doc__,'all_resolved_edges':edges}
(w/'modules54-resolved-callers.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('source files',len(files),'call rows',len(rows),'resolved edges',len(edges));
for x in rows:
 if len(x['resolved_direct_callers'])==0 and not x['method'].startswith('download_'):print('no resolved direct caller',x['method'],x['owner'])
