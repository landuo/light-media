package app

import (
	"context"
	"encoding/json"
	"path/filepath"

	"light-media/internal/catalog"
	"light-media/internal/noticetemplate"
	"light-media/internal/releasemeta"
)

// The existing host freezes naming during preview (the pinned handler also
// emits naming events during preview). Persist the real source projections so
// later write events do not replace them with the compact public Media DTO.
type originalTransferFileContext struct {
	Meta  json.RawMessage `json:"meta"`
	Media json.RawMessage `json:"mediainfo"`
}

func (a *App) originalTransferHasHandlers() bool {
	a.pluginOriginalEventsMu.Lock()
	defer a.pluginOriginalEventsMu.Unlock()
	for _, name := range []string{"transfer.rename.build", "transfer.rename", "transfer.intercept", "transfer.overwrite.check", "storage.operation"} {
		if len(a.pluginOriginalChainHandlers[name]) > 0 {
			return true
		}
	}
	for _, name := range []string{"transfer.complete", "transfer.failed", "transfer.subtitle.complete", "transfer.subtitle.failed", "transfer.audio.complete", "transfer.audio.failed", "metadata.scrape"} {
		if len(a.pluginOriginalBroadcast.handlers[name]) > 0 {
			return true
		}
	}
	return false
}

func (a *App) originalTransferContext(ctx context.Context, identity catalog.Media, file PlanFile) (originalTransferFileContext, error) {
	return a.originalTransferContextWithMedia(ctx, identity, file, nil)
}

func (a *App) originalTransferContextWithMedia(ctx context.Context, identity catalog.Media, file PlanFile, resolved json.RawMessage) (originalTransferFileContext, error) {
	var out originalTransferFileContext
	options, err := a.globalRecognitionOptions(ctx)
	if err != nil {
		return out, err
	}
	parser, err := releasemeta.NewMetaInfoParser(releasemeta.MetaInfoEnvironment{Options: options})
	if err != nil {
		return out, err
	}
	meta, err := parser.ParsePath(file.Source, nil)
	if err != nil {
		return out, err
	}
	// Explicit manual identity/episode selection is the existing transfer task's
	// metadata, just as the source clears a single file's end season/episode.
	if identity.MediaType == "tv" {
		meta.Set("type", "电视剧")
		meta.Set("begin_season", file.Season)
		meta.Set("end_season", nil)
		if len(file.Episodes) == 1 {
			meta.Set("begin_episode", file.Episodes[0])
			meta.Set("end_episode", nil)
			meta.Set("total_episode", 1)
		}
	} else {
		meta.Set("type", "电影")
	}
	if file.Part != "" {
		meta.Set("part", file.Part)
	}
	state, err := meta.EncodeState()
	if err != nil {
		return out, err
	}
	fields, err := sourceNoticeMeta(state)
	if err != nil {
		return out, err
	}
	out.Meta, err = json.Marshal(fields)
	if err != nil {
		return out, err
	}
	if len(resolved) == 0 {
		media, err := a.sourceRecognizeTMDBMedia(ctx, identity)
		if err != nil {
			return out, err
		}
		resolved = media.MediaInfo
	}
	out.Media = resolved
	return out, nil
}

// These are the host's existing naming formats expressed as templates. The
// plugin platform supplies the source TemplateHelper context and callback order;
// it does not replace the application's configured naming policy.
const originalNativeMovieNaming = "{{title}}{% if year %} ({{year}}){% else %} (tmdb-{{tmdbid}}){% endif %}/{{title}}{% if year %} ({{year}}){% else %} (tmdb-{{tmdbid}}){% endif %}{% if part %}-{{part}}{% endif %}{{fileExt}}"
const originalNativeTVNaming = "{{title}}{% if year %} ({{year}}){% else %} (tmdb-{{tmdbid}}){% endif %}/Season {{season}}/{{title}} {{season_episode}}{% if part %}-{{part}}{% endif %}{{fileExt}}"

func (a *App) originalTransferNativeRename(ctx context.Context, identity catalog.Media, file PlanFile, base string, source originalTransferFileContext, episodes []catalog.Episode) (string, error) {
	meta, err := decodeSourceJSON(source.Meta)
	if err != nil {
		return "", err
	}
	media, err := decodeSourceJSON(source.Media)
	if err != nil {
		return "", err
	}
	input := noticetemplate.ContextInput{Meta: sourceMap(meta), Media: sourceMap(media), FileExtension: filepath.Ext(file.Source)}
	for _, episode := range episodes {
		raw, err := json.Marshal(episode)
		if err != nil {
			return "", err
		}
		value, err := decodeSourceJSON(raw)
		if err != nil {
			return "", err
		}
		input.Episodes = append(input.Episodes, sourceMap(value))
	}
	variables, err := noticetemplate.BuildContext(input)
	if err != nil {
		return "", err
	}
	template := originalNativeMovieNaming
	if identity.MediaType == "tv" {
		template = originalNativeTVNaming
	}
	item, err := originalLocalFileItem(file.Source)
	if err != nil {
		return "", err
	}
	return a.originalTransferRenamePath(ctx, template, variables, &base, &file.Source, item)
}
