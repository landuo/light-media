package app

import (
	"context"
	"encoding/json"
	"path/filepath"

	"light-media/internal/transferextensions"
)

// The native history is a projection of the committed execution plan/job. Read
// its stable ID after that commit; a preview never emits a completion event.
func (a *App) emitOriginalTransferResult(ctx context.Context, plan ImportPlan, file PlanFile, source originalTransferFileContext, success bool, message string, history any) {
	if len(source.Meta) == 0 || len(source.Media) == 0 {
		return
	}
	classifier, err := a.transferMediaClassifier(ctx)
	if err != nil {
		a.originalTransferEventError(ctx, err)
		return
	}
	item := transferextensions.PathFile(file.Source)
	event := ""
	if media, _ := classifier.Media(item); media {
		event = "transfer"
	} else if classifier.Subtitle(item) {
		event = "transfer.subtitle"
	} else if classifier.Audio(item) {
		event = "transfer.audio"
	}
	if event == "" {
		return
	}
	if success {
		event += ".complete"
	} else {
		event += ".failed"
	}
	fileitem, err := originalLocalFileItem(file.Source)
	if err != nil {
		a.originalTransferEventError(ctx, err)
		return
	}
	var target, dir any
	fileList, newList, failed := []string{}, []string{}, []string{}
	count, size := 0, int64(0)
	var errorMessage any
	if success {
		target, err = originalLocalFileItem(file.Target)
		if err != nil {
			a.originalTransferEventError(ctx, err)
			return
		}
		dir, err = originalLocalFileItem(filepath.Dir(file.Target))
		if err != nil {
			a.originalTransferEventError(ctx, err)
			return
		}
		fileList, newList = []string{file.Source}, []string{file.Target}
		count, size = 1, file.Size
	} else {
		failed = []string{file.Source}
		errorMessage = message
	}
	var downloader, hash any
	if plan.IntentID != "" {
		var intent Intent
		if err := a.Store.Get(ctx, "intent", plan.IntentID, &intent); err == nil {
			if intent.DownloaderID != "" {
				downloader = intent.DownloaderID
			}
			if intent.Hash != "" {
				hash = intent.Hash
			}
		}
	}
	result := map[string]any{"success": success, "fileitem": fileitem, "target_diritem": dir, "target_item": target, "transfer_type": originalTransferType(file.Method),
		"file_count": count, "file_list": fileList, "file_list_new": newList, "total_size": size, "fail_list": failed, "message": errorMessage,
		"need_scrape": success && importBool(plan.Scraping, true), "need_notify": true}
	raw, err := json.Marshal(map[string]any{"fileitem": fileitem, "meta": source.Meta, "mediainfo": source.Media, "transferinfo": result, "downloader": downloader, "download_hash": hash, "transfer_history_id": history})
	if err != nil {
		a.originalTransferEventError(ctx, err)
		return
	}
	a.broadcastOriginalPluginEvent(ctx, event, raw)
}

func (a *App) originalTransferEventError(ctx context.Context, err error) {
	a.reportOriginalPluginExecutionError(ctx, "system", "整理事件数据构造失败", map[string]any{"type": "event", "event_type": "transfer"}, err)
}

func (a *App) emitOriginalNativeTransferResult(ctx context.Context, plan ImportPlan, file PlanFile, meta importMetadata, success bool, message string) {
	source, ok := meta.OriginalTransfer[file.ID]
	if !ok {
		return
	}
	var history any
	if item, err := a.transferHistoryItem(ctx, file.ID); err == nil {
		history = item.ID
	}
	a.emitOriginalTransferResult(ctx, plan, file, source, success, message, history)
	if !success {
		return
	}
	// The existing native host bundles auxiliary materials into its primary
	// history. Emit their distinct ordinary events only after their actual
	// publication/registration, with None for their absent separate history ID.
	for _, sidecar := range meta.Sidecars[file.ID] {
		extra := file
		extra.Source, extra.Target, extra.Size = sidecar.Source, sidecar.Target, sidecar.Snapshot.Size
		projection, err := a.originalTransferContext(ctx, plan.Media, extra)
		if err != nil {
			a.originalTransferEventError(ctx, err)
			continue
		}
		a.emitOriginalTransferResult(ctx, plan, extra, projection, true, "", nil)
	}
}
