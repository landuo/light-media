package app

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"testing"
	"time"

	"light-media/internal/plugins"
	"light-media/internal/plugins/artifacts"
)

func verifyOwnedProductionTransfer(t *testing.T, dir string, request func(string, string, any, int) []byte, success func(string, string, any), stop, start func()) {
	t.Helper()
	worker := os.Getenv("OWNED_TRANSFER_EVENTS_BINARY")
	payload, err := os.ReadFile(worker)
	if err != nil {
		t.Fatal("actual transfer worker required", err)
	}
	raw, err := exec.Command(worker, "--manifest").Output()
	var manifest plugins.Manifest
	if err != nil || json.Unmarshal(raw, &manifest) != nil || manifest.Validate() != nil || manifest.PluginID != "OwnedTransferEvents" {
		t.Fatal("actual transfer worker manifest")
	}
	digest := sha256.Sum256(payload)
	index := artifacts.Index{SchemaVersion: 1, PluginID: manifest.PluginID, CurrentVersion: manifest.Version, Releases: []artifacts.Release{{Version: manifest.Version, Manifest: manifest, Artifacts: []artifacts.Artifact{{Platform: runtime.GOOS + "-" + runtime.GOARCH, Format: "executable", SHA256: hex.EncodeToString(digest[:]), ExecutableSHA256: hex.EncodeToString(digest[:]), Size: int64(len(payload)), HostContract: pluginResourcesSDKContract}}}}}
	repository := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/index":
			_ = json.NewEncoder(w).Encode(index)
		case "/worker":
			_, _ = w.Write(payload)
		default:
			http.NotFound(w, r)
		}
	}))
	defer repository.Close()
	index.Releases[0].Artifacts[0].URL = repository.URL + "/worker"
	success("POST", "/api/plugins/install", map[string]any{"plugin_id": manifest.PluginID, "repo_url": repository.URL + "/index"})
	base := t.TempDir()
	source, target := filepath.Join(base, "source"), filepath.Join(base, "library")
	for _, path := range []string{source, target} {
		if err := os.MkdirAll(path, 0750); err != nil {
			t.Fatal(err)
		}
	}
	var current struct{ Data Settings }
	if json.Unmarshal(request("GET", "/api/settings", nil, 200), &current) != nil {
		t.Fatal("real settings")
	}
	current.Data.AllowedRoots = []string{source}
	current.Data.Roots = []Root{{ID: "owned-transfer-root", Path: target, Kind: "mixed"}}
	request("PUT", "/api/settings", current.Data, 200)
	wire := json.RawMessage(`{"id":123,"title":"Owned transfer","original_title":"Owned Transfer","release_date":"2024-01-01","overview":"owned","genres":[],"credits":{"cast":[],"crew":[]},"external_ids":{},"images":{}}`)
	full, err := sourceTMDBMediaInfo(wire, "movie", "image.tmdb.org", "")
	if err != nil {
		t.Fatal(err)
	}
	configure := func(id, name, mode string, cancel bool) {
		patches := map[string]any{"transfer.rename": map[string]any{"updated": true, "updated_str": name + "/" + name + ".mkv"}}
		if cancel {
			patches["transfer.intercept"] = map[string]any{"cancel": true, "reason": "owned production veto"}
		}
		success("PUT", "/api/plugins/"+id, map[string]any{"enabled": true, "storage": true, "storage_root": base, "storage_mode": mode, "mediainfo": full, "patches": patches})
	}
	read := func(id string) []struct {
		Type string
		Data json.RawMessage
	} { var rows []struct {
		Type string
		Data json.RawMessage
	}; if json.Unmarshal(request("GET", "/api/v1/plugin/"+id+"/observations", nil, 200), &rows) != nil {
		t.Fatal("actual transfer observations")
	}; return rows }
	pid := func(id string) int {
		var state struct{ PID int }
		if json.Unmarshal(request("GET", "/api/v1/plugin/"+id+"/state", nil, 200), &state) != nil || state.PID <= 0 {
			t.Fatal("actual SDK PID")
		}
		return state.PID
	}
	run := func(name, method string, want bool) ImportPlan {
		path := filepath.Join(source, name+".2024.mkv")
		if err := os.WriteFile(path, []byte("owned production transfer bytes"), 0640); err != nil {
			t.Fatal(err)
		}
		var preview struct{ Data ImportPlan }
		if json.Unmarshal(request("POST", "/api/import/preview", ImportRequest{MediaType: "movie", TMDBID: 123, RootID: "owned-transfer-root", Mode: method, Scraping: importFlag(false), Files: []ImportFileRequest{{Path: path}}}, 200), &preview) != nil || len(preview.Data.Files) != 1 || preview.Data.Files[0].Status != "ready" {
			t.Fatal("real transfer preview")
		}
		var execution struct{ Data Job }
		if json.Unmarshal(request("POST", "/api/import/execute", map[string]any{"plan_id": preview.Data.ID}, 200), &execution) != nil || execution.Data.ID == "" {
			t.Fatal("real transfer submission")
		}
		deadline := time.Now().Add(20 * time.Second)
		var actual ImportPlan
		for time.Now().Before(deadline) {
			var plans struct{ Data []ImportPlan }
			if json.Unmarshal(request("GET", "/api/import/plans", nil, 200), &plans) != nil {
				t.Fatal("real import plans")
			}
			for _, plan := range plans.Data {
				if plan.ID == preview.Data.ID {
					actual = plan
				}
			}
			if len(actual.Files) == 1 && (actual.Files[0].Status == "imported" || actual.Files[0].Status == "error") {
				break
			}
			time.Sleep(20 * time.Millisecond)
		}
		if len(actual.Files) != 1 || (actual.Files[0].Status == "imported") != want || !want && actual.Files[0].Status != "error" {
			t.Fatal("actual transfer outcome", actual)
		}
		bytes, readErr := os.ReadFile(actual.Files[0].Target)
		if want && (readErr != nil || string(bytes) != "owned production transfer bytes") || !want && !os.IsNotExist(readErr) {
			t.Fatal("actual transfer target", readErr)
		}
		if bytes, err := os.ReadFile(path); err != nil || string(bytes) != "owned production transfer bytes" {
			t.Fatal("real source retained")
		}
		if !want {
			request("POST", "/api/jobs/"+execution.Data.ID+"/cancel", nil, 200)
		}
		return actual
	}
	configure(manifest.PluginID, "Source", "", false)
	first := run("First", "hardlink", true)
	if first.Files[0].Target != filepath.Join(target, "Source", "Source.mkv") {
		t.Fatal("source rename not consumed")
	}
	configure(manifest.PluginID, "Veto", "", true)
	run("Veto", "copy", false)
	configure(manifest.PluginID, "Lie", "lie", false)
	run("Lie", "hardlink", false)
	configure(manifest.PluginID, "Source", "", false)
	success("POST", "/api/plugins/"+manifest.PluginID+"/clone", map[string]any{"suffix": "Isolated"})
	clone := manifest.PluginID + "isolated"
	configure(clone, "Clone", "", false)
	beforeSource, beforeClone := pid(manifest.PluginID), pid(clone)
	if beforeSource == beforeClone {
		t.Fatal("clone shares SDK process")
	}
	cloned := run("Clone", "copy", true)
	if cloned.Files[0].Target != filepath.Join(target, "Clone", "Clone.mkv") {
		t.Fatal("clone naming or storage was not applied")
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		rows := read(clone)
		if len(rows) > 0 && rows[len(rows)-1].Type == "transfer.complete" {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	sourceRows, cloneRows := read(manifest.PluginID), read(clone)
	copyCalls := 0
	for _, row := range cloneRows {
		if row.Type == "storage.copy" {
			copyCalls++
		}
	}
	if copyCalls != 1 {
		t.Fatal("clone storage object not actually called", copyCalls)
	}
	stop()
	start()
	afterSource, afterClone := pid(manifest.PluginID), pid(clone)
	if afterSource == beforeSource || afterClone == beforeClone || afterSource == afterClone {
		t.Fatal("actual cold SDK isolation")
	}
	if len(read(manifest.PluginID)) != len(sourceRows) || len(read(clone)) != len(cloneRows) {
		t.Fatal("cold startup replayed transfer")
	}
	success("DELETE", "/api/plugins/"+clone, nil)
	request("GET", "/api/v1/plugin/"+clone+"/state", nil, 404)
	configure(manifest.PluginID, "AfterCold", "", false)
	run("AfterCold", "hardlink", true)
	if path := os.Getenv("PLUGIN_PROCESS_TRANSFER_DETAILS"); path != "" {
		raw, _ := json.Marshal(map[string]any{"source_dir": source, "target_dir": target, "plugin": manifest.PluginID, "media_id": 123, "source_pid": afterSource, "clone_previous_pid": beforeClone})
		if os.WriteFile(path, raw, 0600) != nil {
			t.Fatal("transfer browser details")
		}
	}
	if os.Getenv("PLUGIN_PROCESS_SERVICES_BROWSER_STATE") == "" {
		success("DELETE", "/api/plugins/"+manifest.PluginID, nil)
		request("GET", "/api/v1/plugin/"+manifest.PluginID+"/state", nil, 404)
	}
	t.Logf("actual transfer source/clone %d/%d -> %d/%d; real link/copy, veto, false-success rejected; clone storage isolation; no cold replay", beforeSource, beforeClone, afterSource, afterClone)
}
