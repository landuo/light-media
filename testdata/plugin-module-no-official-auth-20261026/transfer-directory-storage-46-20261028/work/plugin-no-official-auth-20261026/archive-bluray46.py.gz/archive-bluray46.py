import gzip,hashlib,json
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';d=r/'testdata/plugin-module-no-official-auth-20261026/transfer-directory-storage-46-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest()
build=json.loads((w/'platform46r3-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 assert all(Path(p).exists()and sha(Path(p).read_bytes())==h for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items())
for n,t in [('bluray46-preflight-r2.log','(7.73s)'),('bluray46-race-r3.log','38.135s'),('bluray46r3-cli-driver.log','(3.47s)'),('bluray46r3-ui-driver.log','(206.32s)')]:assert t in (w/n).read_text() and 'PASS' in (w/n).read_text()
proof={n:json.loads((w/f'bluray46r3-browser-{n}.json').read_text())for n in ['before-cold','cold-cancelled','retry-success','cold-success','deleted']}
for n in ['before-cold','cold-cancelled']:assert proof[n]['job']['data']['job']['state']=='cancelled'and not proof[n]['target_exists']
for n in ['retry-success','cold-success']:
 v=proof[n];assert v['job']['data']['job']['state']=='succeeded'
 for s,t in zip(v['source_files'],v['target_files']):assert(s['inode'],s['device'],s['sha256'],s['size'])==(t['inode'],t['device'],t['sha256'],t['size'])
 assert v['nfo']['size']==62 and v['nfo']['sha256']=='54767c5abe5882fbfb11733ff72fc1fa08f2247b921761d7f5cff61e22ab48f8'
 rows=[h for h in v['history']['data']['items']if h['media']['title']=='UIBluray'];assert len(rows)==1 and rows[0]['size']==19
assert proof['retry-success']['nfo']==proof['cold-success']['nfo']
for k in ['source','clone']:
 assert len({proof[n][k]['pid']for n in ['before-cold','cold-cancelled','cold-success']})==3
 assert all(proof['cold-success'][k]['calls'].get(m,0)==0 for m in ['module_execute','module_transfer','module_metadata_nfo'])
assert proof['deleted']['source_exists']and not proof['deleted']['target_exists']and not proof['deleted']['nfo']['exists']
assert not any(h['media']['title']=='UIBluray'for h in proof['deleted']['history']['data']['items'])
cleanup=json.loads((w/'bluray46r3-browser-cleanup.json').read_text());assert not any(cleanup['paths'].values())
tv=json.loads((w/'bluray46r3-tv-proof.json').read_text());assert tv['pass'] and tv['list_delta']==0 and tv['nfo_delta']==1
for mode in ['cli','ui']:
 for n,state in [('DiscNames','succeeded'),('DiscLate','failed')]:
  v=json.loads((w/f'bluray46r3-{mode}-evidence'/f'directory-storage46-{n}.json').read_text());assert v['job']['state']==state
  if n=='DiscLate':assert v['job']['error_code']=='PLUGIN_TRANSFER_FAILED'and v['job']['attempt']==1
verdict={'pass':True,'iab':86,'pids':{n:[v[k]['pid']for k in ['source','clone']]for n,v in proof.items()},'members':proof['cold-success']['target_files'],'nfo':proof['cold-success']['nfo'],'history_stream_size':19,'cold_replay':0,'cleanup':cleanup,'tv_nfo':tv['file']}
(w/'bluray46r3-browser-verdict.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n')
targets=['internal/app/'+n for n in ['plugin_original_metadata_scrape.go','plugin_original_metadata_tv_directory_test.go','import_run.go','plugin_original_transfer_directory_publish.go','plugin_original_transfer_directory_result.go','plugin_original_transfer_native_flags.go','plugin_original_transfer_events.go','plugin_original_transfer_bluray_storage_test.go','plugin_module_process_transfer_test.go','plugin_module_process_bluray_test.go','jobs.go']]+['cmd/owned-transfer-events-fixture/storage.go']
paths={r/p for p in targets}
for n in ['generate-tv-directory-scrape-oracle.py','tv-directory-scrape-source-oracle.json','generate-transfer-bluray-oracle.py','transfer-bluray-source-oracle.json']:paths.add(r/'testdata/standard-module-host'/n)
for pattern in ['bluray46*','platform46*.json','build-platform46*.py','run-bluray46*.py','archive-bluray46.py','*platform46*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(x for x in p.rglob('*')if x.is_file())
  elif p.suffix in ['.json','.jsonl','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 b=p.read_bytes();out=d/p.relative_to(r);payload=b
 if p.suffix!='.png':out=Path(str(out)+'.gz');payload=gzip.compress(b,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload);artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(b),'stored_sha256':sha(payload)})
(d/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[36,37,43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/modules/filemanager/transhandler.py:transfer_media directory recursive storage.list/FileItem.name and original item; outer exception at617-619 creates fresh failed TransferInfo','app/chain/transfer.py:1087-1207 ordinary callback records and emits failure; AI retry excluded','app/chain/media.py:1035-1154 Blu-ray nonempty list event recursive=False; _handle_tv_directory lists only recursive=True'],'targets':targets,'behavior':['Storage recursion uses provider.name for destination and passes original source FileItem to link/copy; durable sealed member mappings survive cancelled-job cold recovery.','Later provider list exception retains already-published physical prefix, returns new empty failed TransferInfo, emits one failure and ends actual native job with no automatic retry.','TV recursive=False omits list_files and writes one real season.nfo; fixed AST2cases, real SDK, Linux ordinary event endpoint -> host consumer -> metadata_nfo -> actual storage publication.','Browser sees cancelled job, cold retry succeeds, actual hardlinks/NFO and19B history remain after second cold start without replay; target+history deletion preserves source.'],'evidence':{'source_directory_cases':7,'source_disc_name_cases':8,'source_tv_cases':2,'local_real_process_seconds':7.73,'race_seconds':38.135,'linux_cli_seconds':3.47,'linux_browser_seconds':206.32,'browser':verdict,'build':build,'manifest':str((d/'manifest.json').relative_to(r))},'adaptations':['Local path ownership and frozen snapshots remain mandatory; unsafe provider name/path rejected. Original source FileItem is sealed, never logged as plaintext receipt.','Development AST Python is source replay only; product remains all Go. Tests use synthetic bytes, controlled metadata and owned test plugins.','Provider exception text uses existing Go SDK error contract (plugin_operation_failed); no fabricated original Python exception text.','Cold partial-write cancellation test injects a SQL generation change after first published member; not an actual OS crash.','TV production proof explicitly supplies scrape_source=douban to isolate NFO and avoid unrelated image fetching; no claim of image-provider validation.'],'red':['TV root-only list count1 rather than0','Provider.name ignored in physical destination','Original controlled oracle failed to fix list order; explicit directory order now demonstrates two physical effects before late exception with empty result.','65.597s related run uncovered nil-key check affecting ordinary flags; corrected explicit-presence guard.','Linux46 redundant fixture cancel of terminal failure rejected400; Linux46r2 used pre-execution target rather than actual plan.','Mac preflight25.52s exposed actual directory provider exception scheduled retry_wait; fixed explicit failed result mapping; next7.73s passed.'],'remaining':['Non-BDMV-named directory deletion must follow pinned StorageChain parent cleanup instead of blanket rejection.','Ordinary197methods/199calls/81events applicability and whole36/37/43/50 remain open.'],'delivery':{'branch':'dev/plugins-continuation','head':'7fc62635bc4a8f37068a14c2680161df7ccfb5ed','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-transfer-directory-storage-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';s=json.loads(p.read_text());s['directory_storage_46_progress']={'accepted_increment':True,'whole_indices_accepted':False,'evidence':'docs/validation/plugin-transfer-directory-storage-20261028.json','remaining':report['remaining']};p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
paragraph='main46r3 存储目录增量已验收（42/46不变）：7目录/8盘号/2TV固定回放，provider.name目标与原FileItem传递、sealed成员冷恢复、late-list物理前缀及新空失败DTO、TV非递归零list已闭合。真实Mac7.73s/race38.135s；mainf68e9bce/test495dd501，3731/4215输入稳定；Linux3.47s、IAB86门206.32s。LinuxTV实际season.nfo1次且list0；浏览器取消冷启重试、62BNFO/19B历史、再冷零重放、删除目标及记录后源保留。原retry_wait错误已改为普通失败终态，取消保持；各初红保留。详validation/plugin-transfer-directory-storage-20261028.json。服务/临时目录/IAB86/34466已清理。下一项非BDMV命名目录历史删除，再197/199/81普通调用审计。无阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();a=s.index(marker)+len(marker);b=s.index('\n\n',a+2);p.write_text(s[:a]+'\n\n'+paragraph+s[b:])
print('Archived',len(artifacts),'artifacts; final compiler inputs and actual outcomes verified')
