import json,pathlib,http.cookiejar,urllib.request,time,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'bluray46r3-ui-state.json').read_text())
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
root=pathlib.Path(s['input']['paths'][0]).parent/'TVSource46'/'Season 2';stream=root/'BDMV/STREAM/00001.m2ts';stream.parent.mkdir(parents=True);stream.write_bytes(b'owned TV stream')
media=dict(s['source_config']['media_result']);media.update(type='电视剧',title='Owned TV',tmdb_id=900046,scrape_source='douban')
item={'storage':'local','type':'dir','path':str(root)+'/','name':root.name,'basename':root.name,'extension':None,'size':0}
config={'enabled':True,'modules':{'list_files':'module_execute','metadata_nfo':'module_metadata_nfo'},'result':None,'nfo_result':'<season>owned TV metadata</season>'}
proof={'kind':'real Linux main/subprocess/files; synthetic disc and controlled metadata; image scraping skipped through supplied scrape_source','input':{'fileitem':item,'mediainfo':media,'file_list':[str(stream)]}}
try:
 req('PUT','/api/plugins/'+s['source'],config)
 proof['before']=req('GET','/api/v1/plugin/'+s['source']+'/snapshot')
 proof['send']=req('POST','/api/v1/plugin/OwnedInput/input',{'operation':'event.send','input':{'kind':'broadcast','type':'metadata.scrape','data':proof['input']}})
 nfo=root/'season.nfo'
 for _ in range(300):
  if nfo.exists():break
  time.sleep(.05)
 assert nfo.read_bytes()==config['nfo_result'].encode()
 proof['after']=req('GET','/api/v1/plugin/'+s['source']+'/snapshot')
 proof['list_delta']=proof['after']['calls'].get('module_execute',0)-proof['before']['calls'].get('module_execute',0)
 proof['nfo_delta']=proof['after']['calls'].get('module_metadata_nfo',0)-proof['before']['calls'].get('module_metadata_nfo',0)
 assert proof['list_delta']==0 and proof['nfo_delta']==1,proof
 st=nfo.stat();proof['file']={'path':str(nfo),'bytes':nfo.read_text(),'inode':st.st_ino,'size':st.st_size,'sha256':hashlib.sha256(nfo.read_bytes()).hexdigest()}
 proof['pass']=True
finally:
 proof['restore']=req('PUT','/api/plugins/'+s['source'],s['source_config'])
 (r/'bluray46r3-tv-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'pass':proof.get('pass',False),'list_delta':proof.get('list_delta'),'nfo_delta':proof.get('nfo_delta')})
