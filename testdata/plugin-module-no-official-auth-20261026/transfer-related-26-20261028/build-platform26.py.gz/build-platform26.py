import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path.cwd(); out=root/'work/plugin-no-official-auth-20261026'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def front_inputs():
 paths=[root/'web/package.json',root/'web/package-lock.json',root/'web/vite.config.ts']
 for directory in ['web/src','web/tests','web/scripts','testdata/standard-catalog-extra-ui','testdata/standard-clone-suffix']:
  paths += [p for p in (root/directory).rglob('*')if p.is_file() and 'evidence' not in p.parts]
 return {str(p.relative_to(root)):sha(p)for p in sorted(set(paths))if p.exists()}
env=os.environ|{'GOOS':'linux','GOARCH':'amd64','CGO_ENABLED':'0'}
def go_inputs(test):
 command=['go','list','-deps']+(['-test']if test else[])+['-json','./internal/app'if test else'./cmd/server'];text=subprocess.check_output(command,env=env,text=True);decoder=json.JSONDecoder();pos=0;paths={root/'go.mod',root/'go.sum'}
 while pos<len(text):
  while pos<len(text)and text[pos].isspace():pos+=1
  if pos==len(text):break
  package,pos=decoder.raw_decode(text,pos)
  for key in ['GoFiles','CgoFiles','SFiles','HFiles','SysoFiles','EmbedFiles']:
   for name in package.get(key,[]):paths.add(pathlib.Path(package['Dir'])/name)
 return {str(p):sha(p)for p in sorted(paths)if p.is_file()}
results=[]
for name,test,cmd in [('server-platform26-20261027-linux',False,['go','build','-trimpath']),('process-platform26-20261027-linux.test',True,['go','test','-c'])]:
 before=go_inputs(test);(out/(name+'.inputs.json')).write_text(json.dumps(before,indent=2)+'\n');start=time.monotonic()
 command=cmd+['-o',str(out/name),'./internal/app'if test else'./cmd/server']
 with(out/(name+'.build.log')).open('w')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 after=go_inputs(test);changed=[p for p in before.keys()|after.keys()if before.get(p)!=after.get(p)]
 item={'name':name,'sha256':sha(out/name),'command':command,'inputs':len(before),'changed':changed,'elapsed_seconds':round(time.monotonic()-start,2)};results.append(item);print(item,flush=True)
 if changed:raise SystemExit(2)
(out/'platform26-result.json').write_text(json.dumps({'go_version':subprocess.check_output(['go','version'],text=True).strip(),'environment':{k:env[k]for k in ['GOOS','GOARCH','CGO_ENABLED']},'binaries':results},indent=2)+'\n')
