import pathlib,os,sys,subprocess,hashlib,json
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');mode=sys.argv[1];tmp=r/('transfer-module26-'+mode+'-tmp');tmp.mkdir(exist_ok=True)
names=['server-platform26-20261027-linux','process-platform26-20261027-linux.test','transfer-module-platform26-worker-linux']
for n in names:(r/n).chmod(0o700)
print({n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names},flush=True)
env=os.environ|{'TMPDIR':str(tmp),'DEFAULT_SUB':'zh-cn','PLUGIN_PROCESS_TRANSFER_RELATED_UI':'true','PLUGIN_PROCESS_SERVER_BINARY':str(r/names[0]),'OWNED_INPUT_PROCESS_FIXTURE_BINARY':str(r/'services38-input-final-linux'),'OWNED_TRANSFER_MODULE_PROCESS_BINARY':str(r/names[2]),'PLUGIN_PROCESS_TRANSFER_MODULE_FIXTURE':'true','PLUGIN_PROCESS_TRANSFER_RETURNED_TARGET':'true','PLUGIN_PROCESS_EVENTS36_EVIDENCE_DIR':str(r/('transfer-module26-'+mode+'-evidence'))}
if mode=='ui':env['PLUGIN_PROCESS_TRANSFER_MODULE_STATE']=str(r/'transfer-module26-ui-state.json')
with(r/('transfer-module26-'+mode+'.log')).open('w')as f:p=subprocess.run([str(r/names[1]),'-test.run=^TestPluginServicesProductionCLI$','-test.v','-test.timeout=50m'],env=env,stdout=f,stderr=subprocess.STDOUT)
print((r/('transfer-module26-'+mode+'.log')).read_text()[-5000:]);raise SystemExit(p.returncode)
