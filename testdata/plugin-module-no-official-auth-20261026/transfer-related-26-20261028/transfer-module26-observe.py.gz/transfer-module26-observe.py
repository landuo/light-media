import hashlib,json,pathlib,sys,urllib.request,http.cookiejar
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module26-ui-state.json').read_text());mode=sys.argv[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(method,path,body=None):
 data=json.dumps(body).encode()if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method))as response:return json.loads(response.read())
request('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
sources=[s['ui_plan']['files'][0]['source']]+s['related_sources']
if mode in ['fail','restore','clone']:
 cfg=json.loads(json.dumps(s['source_config']))
 if mode in ['fail','clone']:
  cfg['modules']['transfer']='module_execute';cfg.pop('transfer_results',None)
  cfg.pop('build_transfer_info',None);cfg['result']=None
 if mode=='fail':cfg['build_transfer_info']=True;cfg['result']={'success':False,'message':'owned constructor veto','need_scrape':None}
 assert request('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 if mode in ['restore','clone']:
  other={'enabled':True,'modules':{'transfer':'module_execute'},'result':None}
  if mode=='clone':
   other['transfer_results']={path:{'__plugin_transfer_info':{'success':True,'need_scrape':False,'transfer_type':'link','target_item':{'storage':'local','type':'file','path':s['target']+'/Owned clone preview/ClonePreview'+ext,'name':'ClonePreview'+ext}}}for path,ext in zip(sources,['.mkv','.srt','.flac'])}
  assert request('PUT','/api/plugins/'+s['clone'],other)['data']['success']
def file(path):
 p=pathlib.Path(path)
 if not p.exists():return None
 st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
proof={'mode':mode,'source':request('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':request('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'input':file(sources[0]),'target':file(s['expected_module_target']),'related':[{'input':file(src),'target':file(dst)}for src,dst in zip(s['related_sources'],s['expected_related_targets'])],'jobs':request('GET','/api/jobs'),'plans':request('GET','/api/import/plans'),'history':request('GET','/api/history/transfers')}
(r/('transfer-module26-observed-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
print({'mode':mode,'source_pid':proof['source']['pid'],'clone_pid':proof['clone']['pid'],'source_calls':proof['source']['calls'],'clone_calls':proof['clone']['calls'],'target':proof['target'],'related_targets':[x['target']for x in proof['related']]})
