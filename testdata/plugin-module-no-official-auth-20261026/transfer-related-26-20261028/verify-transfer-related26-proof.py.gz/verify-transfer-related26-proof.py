import pathlib,json,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');state=json.loads((r/'transfer-module26-ui-state.json').read_text())
def read(mode):return json.loads((r/('transfer-module26-observed-'+mode+'.json')).read_text())
def count(x,role,method):return x[role]['calls'].get(method,0)
def calls(x,role):return x[role].get('transfer_calls')or[]
def events(x,role):return x[role].get('transfer_events')or[]
b=read('before');names=['source-preview','false-preview','cold-before-ui','cold-recovered-preview','clone-preview','clone-cold-before-ui','clone-cold-preview','actual-execute','existing-target-preview','cold-after-execution'];steps={n:read(n)for n in names}
sources={b['input']['path']}|{x['input']['path']for x in b['related']}
assert len(sources)==3
for name,x in steps.items():
 assert x['input']==b['input'],name
 assert [v['input']for v in x['related']]==[v['input']for v in b['related']],name
 if name not in ['actual-execute','existing-target-preview','cold-after-execution']:
  assert x['target']is None and all(v['target']is None for v in x['related']),name
for name,role in [('source-preview','source'),('false-preview','source'),('cold-recovered-preview','source'),('clone-preview','source'),('clone-preview','clone'),('clone-cold-preview','source'),('clone-cold-preview','clone'),('existing-target-preview','source')]:
 rows=calls(steps[name],role)[-3:];assert len(rows)==3,(name,role)
 assert {v['kwargs']['fileitem']['path']for v in rows}==sources,(name,role)
 assert all(len(v['kwargs'])==14 and v['kwargs']['preview']is True for v in rows),(name,role)
for name in names[:7]:
 for role in ['source','clone']:assert not events(steps[name],role),(name,role)
for before,after in [('false-preview','cold-before-ui'),('clone-preview','clone-cold-before-ui'),('existing-target-preview','cold-after-execution')]:
 for role in ['source','clone']:
  assert steps[before][role]['pid']!=steps[after][role]['pid']
  assert not calls(steps[after],role)and not events(steps[after],role),(after,role)
  for method in ['module_transfer','module_execute','transfer_event']:assert count(steps[after],role,method)==0,(after,role,method)
assert count(steps['source-preview'],'source','module_transfer')-count(b,'source','module_transfer')==3
assert count(steps['source-preview'],'source','transfer_chain_event')-count(b,'source','transfer_chain_event')==6
assert count(steps['false-preview'],'source','module_execute')==3
for name in ['clone-preview','clone-cold-preview']:assert count(steps[name],'clone','module_execute')==3
actual=steps['actual-execute'];baseline=read('restore')
assert count(actual,'source','module_transfer')==3 and count(actual,'clone','module_execute')==3
assert count(actual,'source','transfer_chain_event')-count(baseline,'source','transfer_chain_event')==6
rows=calls(actual,'source')[-3:]
assert {v['kwargs']['fileitem']['path']for v in rows}==sources
assert all(len(v['kwargs'])==14 and v['kwargs']['preview']is False for v in rows)
assert all(v=='storage.operation'for v in actual['source']['transfer_trace'][len(baseline['source']['transfer_trace']or[]):]if v not in ['module_transfer'])
for role in ['source','clone']:
 rows=events(actual,role);assert len(rows)==3,(role,len(rows))
 assert {v['type']for v in rows}=={'transfer.complete','transfer.subtitle.complete','transfer.audio.complete'}
 assert {v['data']['fileitem']['path']for v in rows}==sources
 assert len({v['data']['transfer_history_id']for v in rows})==3
 assert all(v['data']['transfer_history_id']and v['data']['transferinfo']['success']is True for v in rows)
 assert count(steps['existing-target-preview'],role,'transfer_event')==3
for name in ['actual-execute','existing-target-preview','cold-after-execution']:
 x=steps[name]
 for src,dst in [(x['input'],x['target'])]+[(v['input'],v['target'])for v in x['related']]:
  assert dst and dst['inode']==src['inode']and dst['device']==src['device']and dst['size']==src['size']and dst['sha256']==src['sha256'],(name,src,dst)
assert actual['target']==steps['cold-after-execution']['target']and actual['related']==steps['cold-after-execution']['related']
assert not(pathlib.Path(state['target'])/'Owned clone preview').exists()
assert not pathlib.Path(state['ui_plan']['files'][0]['target']).exists()
con=sqlite3.connect('file:'+state['data_dir']+'/light-media.db?mode=ro',uri=True)
def records(kind):return [json.loads(v[0])for v in con.execute('SELECT payload FROM records WHERE kind=?',(kind,))]
owned=[p for p in records('import_plan')if any(f['source']==b['input']['path']for f in p['files'])]
previews=[p['id']for p in owned if p['state']=='preview'];assert len(previews)==7
imported=[p for p in owned if any(f['source']==b['input']['path']and f['status']=='imported'for f in p['files'])];assert len(imported)==1
jobs=[(i,s,json.loads(p))for i,s,p in con.execute("SELECT id,state,payload FROM jobs WHERE kind='import'")];actual_jobs=[(i,s)for i,s,p in jobs if p.get('id')in[p['id']for p in owned]];assert len(actual_jobs)==1 and actual_jobs[0][1]=='succeeded';assert not any(p.get('id')in previews for i,s,p in jobs)
receipts=[v for v in records('import_receipt')if v.get('source')in sources];assert len(receipts)==3 and all(v['state']=='published'for v in receipts)
callbacks=[v for v in records('original_transfer_callback')if v['file']['source']in sources];assert len(callbacks)==3 and all(v['file']['status']=='imported'for v in callbacks)
assets=[v for v in records('asset')if v.get('source_path')in sources];assert len(assets)==1
history=[v for v in actual['history']['data']['items']if v['source']in sources];assert len(history)==3 and all(v['status']=='success'for v in history)
report={'passed':True,'kind':'actual Linux cmd/server/real SDK/owned synthetic files + IAB59','cold_pids':[[steps[n][role]['pid']for role in ['source','clone']]for n in ['false-preview','cold-before-ui','clone-cold-before-ui','cold-after-execution']],'preview_plans':7,'preview_jobs':0,'preview_rows_per_request':3,'actual_job':actual_jobs,'actual_assets':1,'actual_receipts':3,'actual_callbacks':3,'history_rows':3,'source':b['input'],'target':actual['target'],'related':actual['related'],'ordinary_execute_events':6,'executed_plan':imported[0]['id']}
(r/'transfer-related26-browser-assertions.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
(r/'transfer-module26-ui-state.json.done').touch()
