import pathlib,json,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');state=json.loads((r/'transfer-module24-ui-state.json').read_text())
def read(mode):return json.loads((r/('transfer-module24-observed-'+mode+'.json')).read_text())
def call(x,role,method):return x[role]['calls'].get(method,0)
def kwargs(x,role,method):return x[role]['inputs'][method]['kwargs']
b=read('before');steps={m:read(m)for m in ['source-preview','false-preview','cold-before-ui','cold-recovered-preview','clone-preview','clone-cold-before-ui','clone-cold-preview','actual-execute','existing-target-preview','cold-after-execution']}
for name,x in steps.items():
 assert x['input']==b['input'],name
 if name not in ['actual-execute','existing-target-preview','cold-after-execution']:assert x['target']is None,name
for name,role,method in [('source-preview','source','module_transfer'),('false-preview','source','module_execute'),('cold-recovered-preview','source','module_transfer'),('clone-preview','source','module_execute'),('clone-preview','clone','module_execute'),('clone-cold-preview','source','module_execute'),('clone-cold-preview','clone','module_execute'),('existing-target-preview','source','module_transfer')]:
 args=kwargs(steps[name],role,method);assert len(args)==14 and args['preview']is True,(name,role)
for name in ['source-preview','false-preview','cold-before-ui','cold-recovered-preview','clone-preview','clone-cold-before-ui','clone-cold-preview']:
 for role in ['source','clone']:assert call(steps[name],role,'transfer_event')==0,(name,role)
for before,after in [('false-preview','cold-before-ui'),('clone-preview','clone-cold-before-ui'),('existing-target-preview','cold-after-execution')]:
 for role in ['source','clone']:
  assert steps[before][role]['pid']!=steps[after][role]['pid']
  for method in ['module_transfer','module_execute','transfer_event']:assert call(steps[after],role,method)==0,(after,role,method)
assert call(steps['source-preview'],'source','module_transfer')-call(b,'source','module_transfer')==1
assert call(steps['source-preview'],'source','transfer_chain_event')-call(b,'source','transfer_chain_event')==2
assert call(steps['false-preview'],'source','module_execute')==1 and call(steps['false-preview'],'clone','module_execute')==call(b,'clone','module_execute')
for name in ['clone-preview','clone-cold-preview']:
 assert call(steps[name],'clone','module_execute')==1
 assert kwargs(steps[name],'clone','module_execute')['fileitem']['path']==b['input']['path']
actual=steps['actual-execute'];args=kwargs(actual,'source','module_transfer');assert args['preview']is False and len(args)==14 and args['mediainfo']['tmdb_id']==90001799
assert call(actual,'source','transfer_chain_event')-call(read('restore'),'source','transfer_chain_event')==2
assert actual['source']['inputs']['transfer_chain_event']['type']=='storage.operation'
assert call(actual,'source','module_transfer')==1 and call(actual,'clone','module_execute')==1
for role in ['source','clone']:
 assert call(actual,role,'transfer_event')==1
 assert call(steps['existing-target-preview'],role,'transfer_event')==1
 assert actual[role]['inputs']['transfer_event']['type']=='transfer.complete'
for name in ['actual-execute','existing-target-preview','cold-after-execution']:
 x=steps[name];assert x['target']['inode']==x['input']['inode']and x['target']['sha256']==x['input']['sha256']and x['target']['device']==x['input']['device']
assert actual['target']==steps['cold-after-execution']['target']
assert not(pathlib.Path(state['target'])/'Owned clone preview').exists()
con=sqlite3.connect('file:'+state['data_dir']+'/light-media.db?mode=ro',uri=True)
plans=[json.loads(x[0])for x in con.execute("SELECT payload FROM records WHERE kind='import_plan'")];owned=[p for p in plans if any(f['source']==b['input']['path']for f in p['files'])];imported=[p for p in owned if any(f['status']=='imported'for f in p['files'])];assert len(imported)==1
previews=[p['id']for p in owned if p['state']=='preview'];assert len(previews)==7,len(previews)
jobs=[(i,s,json.loads(p))for i,s,p in con.execute("SELECT id,state,payload FROM jobs WHERE kind='import'")];actual_jobs=[(i,s)for i,s,p in jobs if p.get('id')in[p['id']for p in owned]];assert len(actual_jobs)==1 and actual_jobs[0][1]=='succeeded',actual_jobs
assert not any(p.get('id')in previews for i,s,p in jobs)
assets=[json.loads(x[0])for x in con.execute("SELECT payload FROM records WHERE kind='asset'")];assert len([a for a in assets if a.get('source_path')==b['input']['path']])==1
receipts=[json.loads(x[0])for x in con.execute("SELECT payload FROM records WHERE kind='import_receipt'")];assert len([a for a in receipts if a.get('source')==b['input']['path']])==1
assert actual['target']['path']!=state['ui_plan']['files'][0]['target'];assert not pathlib.Path(state['ui_plan']['files'][0]['target']).exists()
report={'passed':True,'kind':'actual Linux cmd/server + real SDK + owned filesystem + IAB57','cold_pids':[[steps[n][role]['pid']for role in ['source','clone']]for n in ['false-preview','cold-before-ui','clone-cold-before-ui','cold-after-execution']],'preview_plans':len(previews),'preview_jobs':0,'actual_job':actual_jobs,'actual_assets':1,'actual_receipts':1,'clone_preview_directory_exists':False,'target':actual['target'],'source':b['input'],'executed_plan':imported[0]['id'],'preview_complete_callbacks':0,'ordinary_execute_complete_callbacks':2}
(r/'transfer-info24-browser-assertions.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
(r/'transfer-module24-ui-state.json.done').touch()
