import pathlib,json,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');state=json.loads((r/'transfer-module19-ui-state.json').read_text())
def read(mode):return json.loads((r/('transfer-module19-observed-'+mode+'.json')).read_text())
def calls(x,role,method):return x[role]['calls'].get(method,0)
b,f,c,s,z=[read(mode)for mode in ['before','failed-readback','cold-before-ui','success','cold-after-success']]
assert b['target']is None and f['target']is None and c['target']is None
assert b['input']==f['input']==c['input']==s['input']==z['input']
assert calls(f,'source','module_execute')==1 and calls(f,'clone','module_execute')==0
failed=[p for p in f['plans']['data']if any(x['source']==f['input']['path']and x['status']=='error'for x in p['files'])];assert len(failed)==1
ids={p['id']for p in failed};failed_jobs=[j for j in f['jobs']['data']if j['kind']=='import'and j['payload'].get('id')in ids];assert len(failed_jobs)==1 and failed_jobs[0]['state']=='failed'
for role in ['source','clone']:
 assert f[role]['pid']!=c[role]['pid'] and s[role]['pid']!=z[role]['pid']
 assert calls(c,role,'module_transfer')==calls(c,role,'module_execute')==0
 assert calls(z,role,'module_transfer')==calls(z,role,'module_execute')==0
assert calls(s,'source','module_transfer')==1 and calls(s,'clone','module_transfer')==0
assert s['target']['inode']==s['input']['inode']and s['target']['device']==s['input']['device']and s['target']['sha256']==s['input']['sha256']
assert s['target']==z['target']
call=s['source']['inputs']['module_transfer'];assert len(call['kwargs'])==14 and call['kwargs']['preview']is False and call['kwargs']['transfer_type']=='link'and call['kwargs']['mediainfo']['tmdb_id']==90001799
for role in ['source','clone']:
 assert calls(s,role,'transfer_event')==1 and s[role]['inputs']['transfer_event']['type']=='transfer.complete'
connection=sqlite3.connect('file:'+state['data_dir']+'/light-media.db?mode=ro',uri=True)
held=connection.execute('SELECT COUNT(*) FROM reservations WHERE intent_id=?',(failed[0]['id'],)).fetchone()[0];assert held==0
success_plans=[p for p in z['plans']['data']if any(x['source']==z['input']['path']and x['status']=='imported'for x in p['files'])];assert len(success_plans)==1
report={'passed':True,'kind':'actual Linux cmd/server+SDK+owned filesystem+IAB52 actions','source_before_pid':f['source']['pid'],'clone_before_pid':f['clone']['pid'],'source_cold_before_write_pid':c['source']['pid'],'clone_cold_before_write_pid':c['clone']['pid'],'source_cold_after_write_pid':z['source']['pid'],'clone_cold_after_write_pid':z['clone']['pid'],'failed_plan':failed[0]['id'],'failed_job':failed_jobs[0]['id'],'failed_job_state':failed_jobs[0]['state'],'held_failed_plan_slots':held,'success_plan':success_plans[0]['id'],'source_writes_after_first_cold':1,'clone_writes':0,'target':s['target'],'input':s['input'],'ordinary_completion_callbacks':2,'second_cold_replayed_writes':0}
(r/'transfer-module19-browser-assertions.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
(r/'transfer-module19-ui-state.json.done').touch()
