import datetime,hashlib,http.cookiejar,json,os,pathlib,sqlite3,sys,urllib.request
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
root=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((root/'composite48-platform10-r2-state.json').read_text());data=pathlib.Path(s['data_dir']);assert data.is_relative_to(root/'composite48-platform10-tmp') and (data/'instance.lock').exists()
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));body=json.dumps({'username':'ui3133-acceptance','password':'owned-ui3133-password'}).encode();client.open(urllib.request.Request(s['origin']+'/api/auth/login',data=body,headers={'Content-Type':'application/json'})).read()
aes=AESGCM((data/'secret.key').read_bytes());db=sqlite3.connect(data/'light-media.db');mode=sys.argv[1]
def aad(kind,pid,key):return json.dumps(['light-media/plugins/v1',kind,pid,key],separators=(',',':')).encode()
if mode=='seed':
 for pid in [s['source_id'],s['clone_id']]:
  value=json.dumps({'marker':'owned composite48 '+pid,'source':'controlled synthetic KV setup; actual UI reset is the action under test'},separators=(',',':')).encode();nonce=os.urandom(12);sealed=nonce+aes.encrypt(nonce,value,aad('data',pid,'composite48-owned-kv'))
  db.execute("INSERT INTO plugin_values(instance_id,kind,item_key,revision,sealed,updated_at) VALUES(?,'data','composite48-owned-kv',1,?,?)",(pid,sealed,datetime.datetime.now(datetime.timezone.utc).isoformat()))
  folder=data/'plugin-data'/pid;folder.mkdir(parents=True,exist_ok=True,mode=0o700);assert folder.resolve().is_relative_to(data);(folder/'composite48-owned.txt').write_text('owned composite48 file for '+pid)
 db.commit()
out={'kind':'actual production HTTP status and authenticated/encrypted owned SQLite observer; seed is controlled synthetic setup, not a claim of SDK SaveData writing','state':s,'plugins':{}}
for pid in [s['source_id'],s['clone_id']]:
 status=json.loads(client.open(s['origin']+'/api/plugins/'+pid+'/api/status').read());rows=[]
 for kind,key,revision,sealed in db.execute('SELECT kind,item_key,revision,sealed FROM plugin_values WHERE instance_id=? ORDER BY kind,item_key',(pid,)):
  plain=json.loads(aes.decrypt(sealed[:12],sealed[12:],aad(kind,pid,key)));rows.append({'kind':kind,'key':key,'revision':revision,'value':plain,'sealed_sha256':hashlib.sha256(sealed).hexdigest()})
 code={str(p.relative_to(data)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (data/'plugin-packages'/pid).rglob('*')if p.is_file()}
 own=data/'plugin-data'/pid/'composite48-owned.txt';out['plugins'][pid]={'status':status,'values':rows,'code_sha256':code,'owned_file_sha256':hashlib.sha256(own.read_bytes()).hexdigest()}
if mode in ['after','cold']:
 before=json.loads((root/'composite48-platform10-observed-seed.json').read_text());source=out['plugins'][s['source_id']];clone=out['plugins'][s['clone_id']];old=before['plugins'][s['clone_id']]
 assert source['status']['version']=='2.0' and source['status']['marker']is None and source['values']==[]
 assert clone['status']['version']=='1.0' and clone['status']['marker']=='clone' and clone['values']==old['values']
 for pid in [s['source_id'],s['clone_id']]:assert out['plugins'][pid]['code_sha256']==before['plugins'][pid]['code_sha256'] and out['plugins'][pid]['owned_file_sha256']==before['plugins'][pid]['owned_file_sha256']
 if mode=='after':assert all(clone['status'][k]==old['status'][k]for k in ['version','marker','nonce','init_count'])
(root/('composite48-platform10-observed-'+mode+'.json')).write_text(json.dumps(out,indent=2)+'\n');print({'mode':mode,'plugins':{k:{'version':v['status']['version'],'marker':v['status']['marker'],'nonce':v['status']['nonce'],'init_count':v['status']['init_count'],'kv_config_rows':len(v['values']),'code_files':len(v['code_sha256'])}for k,v in out['plugins'].items()}})
