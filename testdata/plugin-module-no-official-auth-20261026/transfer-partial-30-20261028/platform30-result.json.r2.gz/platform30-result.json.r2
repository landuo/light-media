{
  "go_version": "go version go1.26.2 darwin/arm64",
  "environment": {
    "GOOS": "linux",
    "GOARCH": "amd64",
    "CGO_ENABLED": "0"
  },
  "binaries": [
    {
      "name": "server-platform30-20261027-linux",
      "sha256": "ac1f55ba8ecbcee345a84091f0350e40d2a1d672ef59a75487629d897b228631",
      "command": [
        "go",
        "build",
        "-trimpath",
        "-o",
        "/Users/accidia/projects/light-media/work/plugin-no-official-auth-20261026/server-platform30-20261027-linux",
        "./cmd/server"
      ],
      "inputs": 3713,
      "changed": [],
      "elapsed_seconds": 3.79
    },
    {
      "name": "process-platform30-20261027-linux.test",
      "sha256": "6bc5971af6e31bb5c70de59abfc3fe5ea52bc23d173d4ac4fe606301b421eb0c",
      "command": [
        "go",
        "test",
        "-c",
        "-o",
        "/Users/accidia/projects/light-media/work/plugin-no-official-auth-20261026/process-platform30-20261027-linux.test",
        "./internal/app"
      ],
      "inputs": 4170,
      "changed": [],
      "elapsed_seconds": 7.83
    }
  ]
}
