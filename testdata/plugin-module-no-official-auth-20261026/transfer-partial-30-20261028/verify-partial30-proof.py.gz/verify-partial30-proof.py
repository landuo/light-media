import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026')
a=json.loads((b/'partial30-browser-summary-executed.json').read_text());c=json.loads((b/'partial30-browser-summary-cold.json').read_text())
assert a['history']['total']==c['history']['total']==3
assert a['history']==c['history']
assert a['files']==c['files']
assert [a[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[3,2]
assert [c[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[0,0]
assert all(a[k]['pid']!=c[k]['pid']for k in ['source','clone'])
for d in [a,c]:
 assert len(d['active_plans'])==1 and len(d['job_details'])==1
 detail=d['job_details'][0];assert detail['job']['state']=='failed'
 result=detail['transfer'];assert result['total']==3 and result['failed']==1
 assert [i['status']for i in result['items']]==['success','failed','success']
 files={f['path']:f for f in d['files']}
 for i in result['items']:
  if i['status']=='success':
   assert {k:files[i['source']][k]for k in ['inode','device','size','sha256']}=={k:files[i['target']][k]for k in ['inode','device','size','sha256']}
  else:assert i['error']=='owned browser subtitle rejection' and not i.get('target')
dom=(b/'partial30-browser/05-partial-correct-summary-bottom.dom.txt').read_text();assert '总数 3 · 失败 1' in dom
cold=(b/'partial30-browser/06-cold-three-independent-histories.dom.txt').read_text();assert '1 - 3 / 3' in cold and '失败' in cold and '成功' in cold
proof={'passed':True,'pids':[[d[k]['pid']for k in ['source','clone']]for d in [a,c]],'history_count':3,'success':2,'failed':1,'post_cold_sdk_calls':0,'files':c['files'],'main_sha256':'9c08d77cd416432d6f6fe16f8c82a06e71334f6d7711e7100ba67dfc87e8ae62','test_sha256':'61e262e137f69985ce2ad4bbb1e7707c299c91a12bfb2cf6daadf8e14ca75b20','ui_driver_sha256':'6bc5971af6e31bb5c70de59abfc3fe5ea52bc23d173d4ac4fe606301b421eb0c'}
(b/'partial30-browser-verdict.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps(proof,ensure_ascii=False))
