import copy,hashlib,http.cookiejar,json,pathlib,sys,urllib.request
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module30-ui-state.json').read_text());mode=sys.argv[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(method,path,body=None):
 data=json.dumps(body).encode() if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method)) as response:return json.loads(response.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
active=r/'partial30-browser-active.json'
if active.exists():s.update(json.loads(active.read_text()))
if mode=='prepare-summary':
 name='OwnedUIPartialSummary';identity=90009799
 paths=[str(pathlib.Path(s['directory'])/(name+'.2024'+ext))for ext in ['.mkv','.zh.srt','.flac']]
 for path in paths:pathlib.Path(path).write_bytes(('owned summary '+pathlib.Path(path).suffix).encode())
 def media(v):
  if isinstance(v,dict):return {k:media(x)for k,x in v.items()}
  if isinstance(v,list):return [media(x)for x in v]
  if isinstance(v,int)and v==90001799:return identity
  if isinstance(v,str):return v.replace('Owned high-level UI',name).replace('90001799',str(identity))
  return v
 s['source_config']['media_result']=media(s['source_config']['media_result'])
 s['ui_plan']['files'][0]['source']=paths[0];s['related_sources']=paths[1:];s['active_name']=name
 active.write_text(json.dumps({k:s[k]for k in ['source_config','ui_plan','related_sources','active_name']},indent=2)+'\n')
if mode in ['prepare','prepare-summary']:
 cfg=copy.deepcopy(s['source_config']);cfg['modules']['transfer']='module_execute';cfg['result']=None
 cfg.pop('build_transfer_info',None);cfg['transfer_results']={s['related_sources'][0]:{'__plugin_transfer_info':{'success':False,'message':'owned browser subtitle rejection'}}}
 cfg['modules'].pop('list_files',None);cfg['modules'].pop('get_parent_item',None)
 assert req('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert req('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{'transfer':'module_execute'},'result':None})['data']['success']
 print('prepared per-subtitle rejection, source None -> clone None -> native for other files')
def file(path):
 p=pathlib.Path(path)
 if not p.is_file():return {'path':path,'exists':False}
 st=p.stat();return {'path':path,'exists':True,'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
history=req('GET','/api/history/transfers?q='+s.get('active_name','OwnedUITransfer'))['data']
proof={'mode':mode,'history':history,'plans':req('GET','/api/import/plans')['data'],'jobs':req('GET','/api/jobs')['data'],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'files':[file(p)for p in [s['ui_plan']['files'][0]['source']]+s['related_sources']+list({x['target']for x in history['items'] if x['target']})]}
plans=[p for p in proof['plans']if any(f['source']==s['ui_plan']['files'][0]['source']for f in p['files'])]
ids={p['id']for p in plans}
proof['active_plans']=plans
proof['job_details']=[req('GET','/api/jobs/'+j['id'])['data']for j in proof['jobs']if j.get('kind')=='import' and j.get('payload',{}).get('id')in ids]
(r/('partial30-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'histories':history['total'],'source_pid':proof['source']['pid'],'clone_pid':proof['clone']['pid'],'source_transfer':proof['source']['calls'].get('module_execute',0),'clone_transfer':proof['clone']['calls'].get('module_execute',0)})
