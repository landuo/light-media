import hashlib,json,pathlib,sys,urllib.request,http.cookiejar
root=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((root/'browser-storage15-ui-state.json').read_text());mode=sys.argv[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(method,path,body=None):
 raw=json.dumps(body).encode()if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=raw,headers={'Content-Type':'application/json'},method=method))as response:return json.loads(response.read())
request('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
if mode in ['fail','native','restore']:
 config=s['source_config'].copy()
 if mode=='fail':config['result']=False
 if mode=='native':config['result']=None
 out=request('PUT','/api/plugins/'+s['source'],config);assert out['data']['success']
source=request('GET','/api/v1/plugin/'+s['source']+'/snapshot');clone=request('GET','/api/v1/plugin/'+s['clone']+'/snapshot');p=pathlib.Path(s['directory'])/'File10.mkv';proof={'mode':mode,'source':source,'clone':clone,'actual_file':{'path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}
(root/('browser-storage15-observed-'+mode+'.json')).write_text(json.dumps(proof,indent=2)+'\n');print({'mode':mode,'source_pid':source['pid'],'clone_pid':clone['pid'],'source_module_calls':source['calls'].get('module_execute',0),'clone_module_calls':clone['calls'].get('module_execute',0),'native_file_size':p.stat().st_size})
