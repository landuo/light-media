import gzip,hashlib,json,pathlib,subprocess
r=pathlib.Path.cwd();w=r/'work/plugin-no-official-auth-20261026';p=r/'testdata/plugin-module-no-official-auth-20261026/events36-37-scope-audit.json';a=json.loads(p.read_text());inventory=r/a['source_inventory'];v=json.loads(inventory.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
checks={}
for path,h in v['source_sha256'].items():
 b=subprocess.check_output(['git','-C','/Users/accidia/projects/MoviePilot','show',v['source_commit']+':'+path]);assert sha(b)==h;checks[path]=h
assert len(v['calls'])==len(a['annotations'])==92
assert 'PASS\nok' in (w/'events48-final-core-regression.log').read_text()
(w/'events48-audit-before.json').write_bytes(p.read_bytes())
reports={n:'docs/validation/'+f for n,f in {9:'plugin-history-ordinary-directory-20261028.json',56:'plugin-transfer-event-identity-20261028.json',62:'plugin-transfer-scrape-batch-20261028.json',63:'plugin-transfer-scrape-deferred-20261028.json',64:'plugin-transfer-directory-storage-20261028.json',75:'plugin-transfer-bluray-20261028.json',76:'plugin-transfer-directory-storage-20261028.json',78:'plugin-transfer-naming-20261028.json'}.items()}
for x in a['annotations']:
 i=x['source_call_index'];source=v['calls'][i];assert x['source_call']==f"{source['path']}:{source['line']}"
 x['fixed_source_sha256']=checks[source['path']]
 # Normalize preexisting symbol/comment references without discarding them.
 x['target_symbols']=x['target']
 x['target']=[s.split(':',1)[0].split(' (',1)[0]for s in x['target']]
 assert all((r/t).is_file()for t in x['target'])
 if 56<=i<=65 or 75<=i<=79:
  refs=['docs/validation/plugin-transfer-event-identity-20261028.json','docs/validation/plugin-transfer-bluray-20261028.json','docs/validation/plugin-transfer-bluray-scrape-20261028.json','docs/validation/plugin-transfer-directory-storage-20261028.json','docs/validation/plugin-history-ordinary-directory-20261028.json']
  if i in [62,63]:refs+=['docs/validation/plugin-transfer-scrape-batch-20261028.json','docs/validation/plugin-transfer-scrape-deferred-20261028.json']
  x['evidence']=list(dict.fromkeys(x['evidence']+refs));x['remaining']=[]
  x['conclusion']='Applicable native media/subtitle/audio tasks, directory-as-one-task, full completion/failure callback DTO, provider naming/list order/late exception, mutable rename/intercept/overwrite/storage selection, batch and deferred metadata are implemented and verified by the version-bound reports below. Movie Blu-ray and TV root-only metadata, partial effects, false results, clone isolation, browser actions and cold no-replay are covered. Static call count is not an execution count; excluded workflow/AI and absent independent business hosts are not claimed as executed.'
 if i==9:
  x['evidence'].append(reports[9]);x['conclusion']+=' Fixed successful retained-directory source event is now separately represented by a sealed retained fact, preserving physical state and exact src/hash event; native downloader removal remains delete_file=False.'
 if i in [48,49]:
  x['conclusion']=x['conclusion'].replace('Catalog unknown-key ingress is a separate existing-host gap.','Existing catalog unknown-key ingress is independently implemented and verified through platform8 main/browser; it does not add foreign-key subscription storage.')
  x['evidence']=['testdata/plugin-module-no-official-auth-20261026/platform8-runtime/manifest.json','testdata/standard-catalog-modules/opaque-source-oracle.json'];x['target']+=['internal/app/plugin_original_catalog_opaque.go']
 if i in reports:x['evidence']=list(dict.fromkeys(x['evidence']+[reports[i]]))
 assert all((r/e).is_file()for e in x['evidence'])
for c in a['consumers']:
 if c['handler']=='scrape_metadata_event':
  c['evidence']+='; docs/validation/plugin-transfer-scrape-batch-20261028.json; docs/validation/plugin-transfer-scrape-deferred-20261028.json; docs/validation/plugin-transfer-bluray-scrape-20261028.json; docs/validation/plugin-transfer-directory-storage-20261028.json'
  c['conclusion']+=' Subsequent actual main36/37/45/46 verify batching/deferred cleanup, movie directory NFO, TV recursive=False, prepared-write recovery and zero cold replay.'
a['precise_current_gaps']=[]
a['audit_updated']='2026-10-28: all44 fixed source hashes rechecked;92 producer sites and10 ordinary registered consumers reconciled with version-bound evidence through main47; current actual SDK core regression12.852s. No new independent business host is inferred.'
a['closed_increments'].append({'id':'directory_and_metadata_final_20261028','evidence':list(dict.fromkeys(reports.values())),'whole_indices_accepted':True,'indices':[36,37],'current_core_regression':'docs/validation/plugin-events-final-20261028.json'})
p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
d=r/'testdata/plugin-module-no-official-auth-20261026/events-final-48-20261028';d.mkdir(parents=True,exist_ok=True)
paths=[p,inventory,w/'events48-final-core-regression.log',w/'events48-audit-before.json',w/'reconcile-events48.py']
for n in ['plugin_original_event_queue.go','plugin_original_event_registry.go','plugin_original_chain_event.go','plugin_original_mutable_event.go','plugin_original_core_event_consumers.go']:paths.append(r/'internal/app'/n)
artifacts=[]
for path in paths:
 b=path.read_bytes();out=d/path.relative_to(r);out=pathlib.Path(str(out)+'.gz');out.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(b,mtime=0);out.write_bytes(packed);artifacts.append({'original':str(path.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(b),'stored_sha256':sha(packed)})
(d/'manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n')
report={'accepted_indices':[36,37],'whole_plugin_module_complete':False,'fixed_backend':v['source_commit'],'fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source_hashes_verified':checks,'source_calls':92,'ordinary_source_calls':81,'excluded_source_calls':11,'ordinary_registered_consumers':10,'mapping':str(p.relative_to(r)),'mapping_sha256':sha(p.read_bytes()),'evidence_manifest':str((d/'manifest.json').relative_to(r)),'current_sdk_core_regression_seconds':12.852,'actual_host_evidence':'Every applicable producer/consumer in mapping references fixed source, real target and version-bound SDK/Linux/browser evidence; latest directory/source-retained increment main2201c87d has Linux4.33s/IAB87 317.77s. No report is relabelled as having run on a different binary.','scope_adaptations':['AI/workflow11sites excluded by user; their ordinary event types from other producers remain.','CookieCloud/reset-all-sites, foreign-key subscription storage, external IM transports/webhook parser, auxiliary multiuser/media-server login producers have no corresponding native operation; do not add those independent systems. Ordinary event registration and native equivalents remain.','ModuleReload rebuilds existing command registry; no Python ModuleManager. Native subscription create/precheck remains; no standalone metadata-refresh subscription business is added.','Go event DTO/object identity, UUID and native durable task adaptations remain explicitly recorded in individual reports.'],'remaining_indices':[43,50],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-events-final-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';s=json.loads(p.read_text());assert isinstance(s['accepted_indices'],list);s['accepted_indices']=sorted(set(s['accepted_indices'])|{36,37});s['events_final_48']={'accepted_indices':[36,37],'evidence':'docs/validation/plugin-events-final-20261028.json'};s['complete']=False;p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/plugin-module-parity-matrix.md';s=p.read_text();lines=s.splitlines()
for j,line in enumerate(lines):
 if line.startswith('| 36 ')or line.startswith('| 37 '):
  cells=line.split('|');cells[-2]=' 验收通过 ';cells[-3]=' 44份固定源SHA/92调用/10普通消费者逐条复核，适用宿主的源码→目标→Linux/浏览器证据见 `testdata/plugin-module-no-official-auth-20261026/events36-37-scope-audit.json` 与 `validation/plugin-events-final-20261028.json`。最终SDK核心回归12.852s；目录/metadata批次与普通删除事件由main36–47实机增量闭合，全部旧初红保留。仅范围内事件平台与既有宿主认领通过，未新建独立业务宿主。 ';cells[-4]=' 普通广播/同步可变Chain的注册、顺序、异常后mutation、启停/重载类身份、来源/分身隔离及宿主输入/输出/副作用已按固定源实现。工作流/AI排除；缺少独立业务宿主的生产方保留源码适用性记录，不伪造执行。必要Go DTO/UUID/持久恢复适配见对应报告。 ';lines[j]='|'.join(cells)
p.write_text('\n'.join(lines)+'\n')
paragraph='44/46验收通过：36/37普通事件最终审计完成，固定44份源码SHA一致、92调用逐条保留（81普通/11用户排除）、10普通消费者有真实宿主证据；当前SDK核心回归12.852s通过，main36–47目录、批次/延期metadata、retained源事件等缺口均有独立版本实机/浏览器封存。详validation/plugin-events-final-20261028.json；没有将静态调用数当执行次数，也未新建CookieCloud/IM/多用户等业务宿主。main47已有85份封存，服务/目录/浏览器已清理。剩余43全197方法/199普通调用适用性与50结论审计；正在核具体宿主可达性并替换过期通用候选位置。无外部阻塞，未提交推送部署。'
for n,m in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();a=s.index(m)+len(m);b=s.index('\n\n',a+2);p.write_text(s[:a]+'\n\n'+paragraph+s[b:])
print('44/46: fixed hashes and all evidence paths verified;36/37 accepted,43/50 remain')
