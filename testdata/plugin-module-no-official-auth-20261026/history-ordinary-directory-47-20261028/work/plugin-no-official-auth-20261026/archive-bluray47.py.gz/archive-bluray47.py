import gzip,hashlib,json
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';d=r/'testdata/plugin-module-no-official-auth-20261026/history-ordinary-directory-47-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest()
build=json.loads((w/'platform47-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 assert all(Path(p).exists()and sha(Path(p).read_bytes())==h for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items())
for n,t in [('directory47-preflight.log','(9.87s)'),('directory47-race.log','60.268s'),('bluray47-cli-driver.log','(4.33s)'),('bluray47-ui-driver.log','(317.77s)')]:assert t in (w/n).read_text() and 'PASS' in (w/n).read_text()
proof={n:json.loads((w/f'bluray47-browser-{n}.json').read_text())for n in ['before-cold','cold-cancelled','retry-success','cold-success','deleted']}
for n in ['before-cold','cold-cancelled']:assert proof[n]['job']['data']['job']['state']=='cancelled'and not proof[n]['target_exists']
for n in ['retry-success','cold-success']:
 v=proof[n];assert v['job']['data']['job']['state']=='succeeded'
 for s,t in zip(v['source_files'],v['target_files']):assert(s['inode'],s['device'],s['sha256'],s['size'])==(t['inode'],t['device'],t['sha256'],t['size'])
 assert v['nfo']['size']==62 and v['nfo']['sha256']=='54767c5abe5882fbfb11733ff72fc1fa08f2247b921761d7f5cff61e22ab48f8'
 rows=[h for h in v['history']['data']['items']if h['media']['title']=='UIBluray'];assert len(rows)==1 and rows[0]['size']==19
assert proof['retry-success']['nfo']==proof['cold-success']['nfo']
for k in ['source','clone']:
 assert len({proof[n][k]['pid']for n in ['before-cold','cold-cancelled','cold-success']})==3
 assert all(proof['cold-success'][k]['calls'].get(m,0)==0 for m in ['module_execute','module_transfer','module_metadata_nfo'])
assert proof['deleted']['source_exists']and not proof['deleted']['target_exists']and not proof['deleted']['nfo']['exists']
assert not any(h['media']['title']=='UIBluray'for h in proof['deleted']['history']['data']['items'])
cleanup=json.loads((w/'bluray47-browser-cleanup.json').read_text());assert not any(cleanup['paths'].values())
named={k:json.loads((w/f'bluray47-named-{k}.json').read_text())for k in ['before','after','cold','cold-final']}
for k in ['after','cold','cold-final']:
 assert named[k]['members']==named['before']['members'] and named[k]['source_members']==named['before']['source_members']
 assert not any(h['source']==named[k]['source']for h in named[k]['history']['data']['items'])
for mode in ['cli','ui']:
 for n,exists in [('DiscNoMedia',False),('DiscKeepSource',True)]:
  v=json.loads((w/f'bluray47-{mode}-evidence'/f'directory-history47-{n}.json').read_text());assert v['source_exists'] and v['target_exists']==exists
  if n=='DiscKeepSource':assert any(x['Type']=='downloadfile.deleted'and 'DiscKeepSource' in x['Data']['src']for x in v['clone'])
verdict={'pass':True,'iab':87,'pids':{n:[v[k]['pid']for k in ['source','clone']]for n,v in proof.items()},'named_retained_members':named['cold-final']['members'],'movie_nfo':proof['cold-success']['nfo'],'cleanup':cleanup}
(w/'bluray47-browser-verdict.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n')
targets=['internal/app/'+n for n in ['asset_manage.go','history_delete.go','history_auxiliary.go','core_download_file_deleted.go','plugin_original_history_delete.go','plugin_original_history_parent.go','plugin_original_history_directory_test.go','plugin_original_transfer_bluray_history_test.go','plugin_module_process_transfer_test.go']]+['cmd/owned-transfer-events-fixture/main.go']
paths={r/p for p in targets}
paths.update((r/'testdata/standard-module-host').glob('*history-ordinary-directory*'))
for pattern in ['directory47*','bluray47*','platform47*.json','build-platform47*.py','run-bluray47*.py','archive-bluray47.py','*platform47*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(x for x in p.rglob('*')if x.is_file())
  elif p.suffix in ['.json','.jsonl','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 b=p.read_bytes();out=d/p.relative_to(r);payload=b
 if p.suffix!='.png':out=Path(str(out)+'.gz');payload=gzip.compress(b,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload);artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(b),'stored_sha256':sha(payload)})
(d/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[36,37,43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/chain/storage.py:171-235 directory is_bluray test then ordinary any_files identity-False cleanup; associated root stop; get_parent_item after actual deletion','app/api/endpoints/history.py:222-260 target false ignored; source false fails; source true including retained directory publishes DownloadFileDeleted then deletes history','app/chain/download.py:1808-1827 nonempty hash may remove downloader task with delete_file=False'],'targets':targets,'behavior':['Ordinary non-Blu-ray directories remain when any_files is not exact False; configuration roots stop before any_files. Empty-of-media directories invoke delete_file then continue with their parent.','Explicit retained source/target journal state never claims physical deletion; target asset/managed_file stays when file is retained.','Successful retained source produces ordinary downloadfile.deleted with original src/hash. Sealed source fact distinguishes retained-directory success; existing ownership/accepted hash checks remain. New optional fact field omits false to preserve legacy MAC serialization.','Real Linux ordinary media directory retained and history hidden through browser; original inode/size/hash still same after two cold starts.','Real Linux API configured-media-extensions exclude synthetic m2ts => named directory physically deleted; source kept. Source retained by test get_file_item false => history deleted and ordinary event observed in actual clone.','Existing browser cancelled Blu-ray retry/cold/NFO/history/target-delete behavior remains verified on same main.'],'evidence':{'fixed_storage_cases':4,'local_related_seconds':17.570,'race_seconds':60.268,'local_real_process_seconds':9.87,'linux_cli_seconds':4.33,'linux_browser_seconds':317.77,'browser':verdict,'build':build,'manifest':str((d/'manifest.json').relative_to(r))},'adaptations':['Existing local path/snapshot/downloader ownership protections remain. No new business system or Python runtime.','Controlled media extensions and false get_file_item are explicit test inputs to exercise original branches; synthetic files/test plugins run in a real Linux service.','The ordinary source event name is preserved even when the source directory remains, as the fixed endpoint does. Private receipt records retained state rather than pretending physical deletion.'],'red':['Actual ordinary-directory SDK rejected before any_files.','First integrated source-retained test rejected by previous Deleted-only source fact guard; fixed distinct retained success and cold verified.','First browser named history action correctly rejected root removed by next independent acceptance fixture. Restored the same owned original root in test settings; next browser action passed. Product root guard unchanged. Screenshot and root restoration evidence retained.'],'remaining':['Whole36/37/43/50 await ordinary197methods/199directcalls/81events applicability audit and any uncovered actual host gaps.'],'delivery':{'branch':'dev/plugins-continuation','head':'7fc62635bc4a8f37068a14c2680161df7ccfb5ed','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-history-ordinary-directory-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';v=json.loads(p.read_text());v['ordinary_directory_47_progress']={'accepted_increment':True,'whole_indices_accepted':False,'evidence':'docs/validation/plugin-history-ordinary-directory-20261028.json','remaining':report['remaining']};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
paragraph='main47 普通目录历史清理增量已验收（42/46不变）：固定StorageChain四条及history源/目标返回分支已核；any_files精确False、配置根保留、空媒体目录清理、retained源/目标持久状态与原普通DownloadFileDeleted已实现。旧事实MAC保持；SDK/cold关联17.570s、race60.268s、真实Mac9.87s；main2201c87d/test49b17ec9，3731/4216输入稳定；Linux4.33s、IAB87门317.77s。实际目录删除/源保留事件、浏览器命名目录含媒体保留但历史移除及两次冷恢复inode/hash不变、蓝光取消重试/NFO/19B/目标删除均通过。首浏览器测试根被后一个夹具替换正确拒绝；恢复同owned根后通过，守卫未改。详validation/plugin-history-ordinary-directory-20261028.json。服务/目录/IAB87/34467已清理。下一步197/199/81普通宿主适用性审计及真实缺口，不新增业务系统。无阻塞，未提交推送部署。'
for n,m in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();a=s.index(m)+len(m);b=s.index('\n\n',a+2);p.write_text(s[:a]+'\n\n'+paragraph+s[b:])
print('Archived',len(artifacts),'artifacts; final inputs and Linux/browser facts verified')
