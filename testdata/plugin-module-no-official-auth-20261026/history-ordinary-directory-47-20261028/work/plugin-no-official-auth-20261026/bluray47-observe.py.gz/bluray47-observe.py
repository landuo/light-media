import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'bluray47-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
def file(p):
 p=pathlib.Path(p)
 if not p.is_file():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'size':st.st_size,'inode':st.st_ino,'device':st.st_dev,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
source=s['input']['paths'][0];target=s['target']
proof={'mode':mode,'job':req('GET','/api/jobs/'+s['job']['id']),'history':req('GET','/api/history/transfers'),'source_files':[file(str(pathlib.Path(source)/n))for n in ['BDMV/STREAM/00001.m2ts','BDMV/index.bdmv']],'target_files':[file(str(pathlib.Path(target)/n))for n in ['BDMV/STREAM/00001.m2ts','BDMV/index.bdmv']],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'nfo':file(str(pathlib.Path(target)/(pathlib.Path(target).name+'.nfo'))),'jobs':req('GET','/api/jobs'),'source_exists':pathlib.Path(source).exists(),'target_exists':pathlib.Path(target).exists()}
(r/('bluray47-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'job':proof['job']['data']['job']['state'],'pids':[proof[k]['pid']for k in ['source','clone']],'target_exists':proof['target_exists']})
