import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'bluray47-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
def file(p):
 p=pathlib.Path(p)
 if not p.is_file():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'size':st.st_size,'inode':st.st_ino,'device':st.st_dev,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
e=json.loads((r/'bluray47-ui-evidence/directory-storage46-DiscNames.json').read_text());target=pathlib.Path(e['physical'][0]['target']).parents[3];source=pathlib.Path(e['physical'][0]['source']).parents[3]
settings=req('GET','/api/settings')['data'];before=json.loads(json.dumps(settings));assert target.is_dir()and source.is_dir()
assert not any(x['id']=='owned-transfer-root'for x in settings['roots'])
settings['roots'].append({'id':'owned-transfer-root','kind':'mixed','path':str(target)})
settings['allowed_roots'].append(str(source));response=req('PUT','/api/settings',settings)
(r/'bluray47-named-root-restoration.json').write_text(json.dumps({'reason':'previous independent CLI helper root was replaced by Blu-ray helper; restore that same owned root for history action; do not alter product guard','before':before,'after':req('GET','/api/settings')['data'],'response':response},ensure_ascii=False,indent=2)+'\n');print({'root':str(target),'source':str(source),'restored':True})
