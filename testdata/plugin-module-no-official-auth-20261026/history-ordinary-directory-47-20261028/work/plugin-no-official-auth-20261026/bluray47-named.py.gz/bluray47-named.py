import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'bluray47-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
def file(p):
 p=pathlib.Path(p)
 if not p.is_file():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'size':st.st_size,'inode':st.st_ino,'device':st.st_dev,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
e=json.loads((r/'bluray47-ui-evidence/directory-storage46-DiscNames.json').read_text());target=str(pathlib.Path(e['physical'][0]['target']).parents[2]);source=str(pathlib.Path(e['physical'][0]['source']).parents[2])
proof={'mode':mode,'source':source,'target':target,'members':[file(p['target'])for p in e['physical']],'source_members':[file(p['source'])for p in e['physical']],'history':req('GET','/api/history/transfers')}
rows=[h for h in proof['history']['data']['items']if h['source']==source]
assert len(rows)==(1 if mode=='before'else 0)
assert all(v['exists']if 'exists'in v else True for v in proof['members'])
(r/('bluray47-named-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print({'mode':mode,'history_rows':len(rows),'target_preserved':pathlib.Path(target).exists()})
