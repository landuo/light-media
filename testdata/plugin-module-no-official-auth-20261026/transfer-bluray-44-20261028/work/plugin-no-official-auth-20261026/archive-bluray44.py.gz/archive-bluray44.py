import gzip,hashlib,json,re
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';d=r/'testdata/plugin-module-no-official-auth-20261026/transfer-bluray-44-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest()
build=json.loads((w/'platform44r3-result.json').read_text())
for binary in build['binaries']:
 assert sha((w/binary['name']).read_bytes())==binary['sha256']
 inputs=json.loads((w/(binary['name']+'.inputs.json')).read_text())
 assert all(Path(p).exists()and sha(Path(p).read_bytes())==h for p,h in inputs.items())
assert 'ok  \tlight-media/internal/app\t101.907s' in (w/'bluray44-race-r3.log').read_text()
assert 'PASS: TestPluginServicesProductionCLI (1.86s)' in (w/'bluray44r3-cli-driver.log').read_text()
assert 'PASS: TestPluginServicesProductionCLI (226.21s)' in (w/'bluray44r3-ui-driver.log').read_text()
proof={n:json.loads((w/f'bluray44r3-browser-{n}.json').read_text())for n in ['before-cold','cold-cancelled','retry-success','cold-success','deleted']}
for n in ['before-cold','cold-cancelled']:
 assert proof[n]['job']['data']['job']['state']=='cancelled'and not proof[n]['target_exists']
for n in ['retry-success','cold-success']:
 v=proof[n];assert v['job']['data']['job']['state']=='succeeded'and v['target_exists']
 for s,t in zip(v['source_files'],v['target_files']):assert (s['inode'],s['device'],s['sha256'],s['size'])==(t['inode'],t['device'],t['sha256'],t['size'])
 rows=[h for h in v['history']['data']['items']if h['media']['title']=='UIBluray'];assert len(rows)==1 and rows[0]['size']==19
for k in ['source','clone']:
 assert len({proof[n][k]['pid']for n in ['before-cold','cold-cancelled','cold-success']})==3
 for n in ['retry-success','cold-success']:assert proof[n][k]['calls'].get('module_execute',0)==0 and proof[n][k]['calls'].get('module_transfer',0)==0
assert proof['deleted']['source_exists']and not proof['deleted']['target_exists']
assert not any(h['media']['title']=='UIBluray'for h in proof['deleted']['history']['data']['items'])
verdict={'pass':True,'iab':84,'pids':{n:[v[k]['pid']for k in ['source','clone']]for n,v in proof.items()},'members':proof['cold-success']['target_files'],'history_stream_size':19,'physical_total_size':37,'cold_transfer_replay':0,'cleanup':'IAB83/84 closed, SSH34463/34464 stopped; final gate uninstall/API404; owned app/source/target paths checked absent after completion'}
(w/'bluray44r3-browser-verdict.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n')
targets=['internal/app/'+n for n in ['types.go','import_fs.go','import_plan.go','import_run.go','import_reorganize.go','organize_manual.go','transfer_history.go','history_delete.go','history_auxiliary.go','asset_manage.go','plugin_original_history_delete.go','plugin_original_history_directory.go','plugin_original_history_parent.go','plugin_original_history_reorganize.go','plugin_original_browser_mutation.go','plugin_original_metadata_storage.go','plugin_original_transfer_callback.go','plugin_original_transfer_collection.go','plugin_original_transfer_context.go','plugin_original_transfer_directory.go','plugin_original_transfer_events.go','plugin_original_transfer_intercept.go','plugin_original_transfer_module.go','plugin_module_process_bluray_test.go','plugin_module_process_services_test.go']]
targets+=['cmd/owned-module-override/main.go','cmd/owned-module-override/directory.go','cmd/owned-transfer-events-fixture/storage.go']
paths={r/p for p in targets}
for pattern in ['plugin_original_transfer_bluray*.go','plugin_original_transfer_directory_*.go']:
 paths.update((r/'internal/app').glob(pattern))
paths.update((r/'testdata/standard-module-host').glob('*bluray*'))
for pattern in ['bluray44*','platform44*.json','build-platform44*.py','run-bluray44*.py','archive-bluray44.py','*platform44*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(x for x in p.rglob('*')if x.is_file())
  elif p.suffix in ['.json','.jsonl','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 b=p.read_bytes();out=d/p.relative_to(r);payload=b
 if p.suffix!='.png':out=Path(str(out)+'.gz');payload=gzip.compress(b,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload);artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(b),'stored_sha256':sha(payload)})
(d/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[36,37,43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/modules/filemanager/transhandler.py:216-313,890-1008: directory as one task, STREAM size, counters zero, recursion order, partial prefix and intercept after root creation','app/chain/storage.py:148-159,171-235: Blu-ray recognition and directory history deletion, repeated missing-self checks','app/db/transferhistory_oper.py:227-302: persist source FileItem','src/views/reorganize/TransferHistoryView.vue:99,1051,1138: source FileItem size or zero'],'targets':targets,'behavior':['Whole-directory frozen member authority and one transfer module invocation; source/clone native fallback and terminal copy with returned target','Per-file existing guarded publication and selected-storage traversal in original order; empty children omitted; partial failures preserve successful prefix','Directory intercept sees null meta/empty options after target root exists; source changes and foreign target members rejected','Original TV Season/Disc naming without invented episode; directory ordinary completion/failure result fields','Cancellation resumes native member receipts after cold reinitialization without provider replay; independently verified plugin copy bytes and hardlink inodes','History target/source/both deletion and explicit reorganize reuse existing ownership and sealed storage deletion journal; SQL completion failure cold recovery','History shows STREAM bytes independently of full native tree authority; raw Source FileItems preserved for callbacks'],'evidence':{'source':'6 fixed TransHandler AST directory cases + 8 disc names; 2 StorageChain AST deletion cases; fixed backend/frontend size source excerpts','local_seconds':16.206,'race_seconds':101.907,'linux_cli_seconds':1.86,'linux_browser_seconds':226.21,'browser':verdict,'build':build,'manifest':str((d/'manifest.json').relative_to(r))},'necessary_adaptations':['Local Go native directory snapshots bind all members and refuse symlinks/unknown target members, preserving existing native ownership safety. Aggregate tree size is authority only; frontend history uses Source STREAM size.','Physical files publish through existing staged receipts, with per-member and parent recovery; copied content is checked before asset registration. Source recursive order and successful prefix are retained.','No Python runtime: Python AST oracle scripts are development evidence only. No workflow/AI/authentication subsystem added.'],'red':['First directory preview rejected trailing-slash FileItem paths; corrected before final validation.','Linux main44 rejected a terminal provider directory preview with trailing slash; corrected and rebuilt.','Fixed source reinspection replaced pre-enumerating all files with recursive publication in provider order; actual selected storage late-list failure now retains the prior two files.','IAB83 exposed history total-tree bytes (37) instead of STREAM bytes (19); final main44r3/IAB84 verifies 19.','Acceptance-only fixture corrections: directory provider FileItem.Type, list FileItem argument, existing test login, cold initializeOriginalPlugins; red logs retained.'],'limits':['Tests use synthetic discs/metadata and owned SDK plugins; production Linux cmd/server, files/SQLite, actual subprocesses, browser clicks and cold restarts are real.','This increment explicitly disables scraping. Directory scraping and managed tree authority after metadata writes require further validation.','Custom storage FileItem name/path differences and exact late-list failure DTO fields remain audit items; no whole directory/module completion claim.','Whole36/37/43/50 and complete ordinary method/event applicability audit remain open.'],'delivery':{'branch':'dev/plugins-continuation','head':'7fc62635bc4a8f37068a14c2680161df7ccfb5ed','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-transfer-bluray-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';s=json.loads(p.read_text());s['transfer_bluray_44_increment']={'accepted_increment':True,'whole_indices_accepted':False,'evidence':'docs/validation/plugin-transfer-bluray-20261028.json','remaining':report['limits'][-3:]};p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
paragraph='main44r3 蓝光目录执行/历史增量已验收（42/46不变）：6个固定目录AST分支/8盘号、2目录删除AST及前端大小源码已核；实际SDK目录单任务、原生硬链接/复制、分身终止返回目标、部分失败/拦截/冷恢复、TV盘号与目录历史删除/重整均通过。最终本地16.206s/race101.907s；main5b719fad/test77c5c107、3730/4212编译输入稳定；Linux1.86s/IAB84门226.21s实测取消冷启重试、19+18B两成员同inode、历史仅19B STREAM、第二次冷启零transfer重放、目标目录删除且源保留。首次Linux预览尾斜杠、IAB83发现37B历史口径及递归提前枚举差异均已修。详validation/plugin-transfer-bluray-20261028.json；IAB83/84、34463/34464、进程及自建临时目录已清理。下一项：目录刮削后的管理快照、存储name/path差异与late-list失败DTO，再做197/199/81普通宿主最终审计。无外部阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();a=s.index(marker)+len(marker);b=s.index('\n\n',a+2);s=s[:a]+'\n\n'+paragraph+s[b:];p.write_text(s)
print('Archived',len(artifacts),'artifacts; final compiler inputs unchanged; real browser facts asserted')
