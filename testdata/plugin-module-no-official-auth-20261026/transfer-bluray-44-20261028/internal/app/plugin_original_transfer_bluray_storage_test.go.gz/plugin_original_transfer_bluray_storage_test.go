package app

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestOriginalTransferBluraySelectedStorage(t *testing.T) {
	for _, mode := range []string{"", "late-list-error"} {
		t.Run(mode, func(t *testing.T) {
			a, sourceRoot, target := importTestApp(t)
			importFixture(t, a, "movie")
			path := filepath.Join(sourceRoot, "Owned.2024.BluRay")
			importWrite(t, filepath.Join(path, "BDMV", "STREAM", "00001.m2ts"), []byte("owned stream"))
			importWrite(t, filepath.Join(path, "BDMV", "index.bdmv"), []byte("owned index"))
			if err := os.Mkdir(filepath.Join(path, "CERTIFICATE"), 0750); err != nil {
				t.Fatal(err)
			}
			full, err := sourceTMDBMediaInfo(json.RawMessage(`{"id":123,"title":"Owned","original_title":"Owned","release_date":"2024-01-01","genres":[],"credits":{"cast":[],"crew":[]},"external_ids":{}}`), "movie", "image.tmdb.org", "")
			if err != nil {
				t.Fatal(err)
			}
			id := installOwnedTransferObserver(t, a, nil, nil, map[string]any{"storage": true, "storage_root": filepath.Dir(sourceRoot), "storage_mode": mode, "mediainfo": full})
			ctx := context.Background()
			out, err := a.manualOrganize(ctx, manualOrganizeRequest{Paths: []string{path}, TargetPath: target, Mode: "hardlink", MediaType: "movie", TMDBID: 123, Scraping: importFlag(false)})
			if err != nil || out.Submitted != 1 {
				t.Fatal(out, err)
			}
			var plan ImportPlan
			if err := a.Store.Get(ctx, "import_plan", out.Items[0].PlanID, &plan); err != nil {
				t.Fatal(err)
			}
			job := overwriteStart(t, a, plan)
			err = a.runImport(ctx, job, plan.ID, nil)
			if (err == nil) != (mode == "") {
				t.Fatal("selected directory storage", mode, err)
			}
			for _, name := range []string{"BDMV/STREAM/00001.m2ts", "BDMV/index.bdmv"} {
				s, e := os.Stat(filepath.Join(path, name))
				d, e2 := os.Stat(filepath.Join(plan.Files[0].Target, name))
				if e != nil || e2 != nil || !os.SameFile(s, d) {
					t.Fatal("source retains published prefix before later listing failure", name, e, e2, err)
				}
			}
			a.wg.Wait()
			response := ownedInputAPI(t, a, "GET", "/api/v1/plugin/"+id+"/observations", "")
			var calls []struct {
				Type string
				Data json.RawMessage
			}
			if response.Code != 200 || json.Unmarshal(response.Body.Bytes(), &calls) != nil {
				t.Fatal("SDK trace")
			}
			lastLink, certificateList := -1, -1
			for i, call := range calls {
				if call.Type == "storage.link" {
					lastLink = i
				}
				if call.Type == "storage.list" {
					var v struct{ FileItem struct{ Path string } }
					if json.Unmarshal(call.Data, &v) == nil && filepath.Base(filepath.Clean(v.FileItem.Path)) == "CERTIFICATE" {
						certificateList = i
					}
				}
			}
			if lastLink < 0 || certificateList <= lastLink {
				t.Fatal("fixed recursion publishes before listing next directory", lastLink, certificateList)
			}
		})
	}
}
