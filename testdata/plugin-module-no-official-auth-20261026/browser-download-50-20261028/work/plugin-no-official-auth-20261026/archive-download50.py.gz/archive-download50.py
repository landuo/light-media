import gzip,hashlib,json,subprocess
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'download50-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/browser-download-50-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest();build=json.loads((w/'platform50-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for p,seconds in [(w/'download50-related.log','20.503s'),(w/'download50-race.log','63.123s'),(remote/'download50-cli.log','1.83s'),(remote/'download50-ui.log','312.29s')]:assert seconds in p.read_text()and 'PASS' in p.read_text()
browser={n:json.loads((remote/('download50-browser-'+n+'.json')).read_text())for n in ['before','false','failed','restored','cold','final']}
assert browser['failed']['source']['body']['calls']['module_execute']==browser['false']['source']['body']['calls']['module_execute']+1
assert browser['failed']['clone']['body']['calls']['module_execute']==browser['false']['clone']['body']['calls']['module_execute']
for k in ['source','clone']:
 assert browser['cold'][k]['body']['pid']!=browser['restored'][k]['body']['pid']
 assert browser['cold'][k]['body']['calls'].get('module_execute',0)==0
 assert browser['final'][k]['body']['calls']['module_execute']==1
assert all(v['files']==browser['before']['files']for v in browser.values())
assert json.loads((remote/'download50-cleanup.json').read_text())['remaining_test_roots']==[]
proof=json.loads((w/'download50-browser/download-proof.json').read_text());assert proof['sha256']==browser['before']['files']['override_path']['sha256']
targets=['internal/app/'+n for n in ['plugin_original_browser_download.go','file_content.go','plugin_original_browser_download_test.go','plugin_module_process_browser_download_test.go','plugin_module_process_services_test.go']]
paths={r/p for p in targets}
for pattern in ['*browser-download*']:paths.update((r/'testdata/standard-module-host').glob(pattern))
for pattern in ['download50-*','platform50*.json','build-platform50.py','run-download50.py','archive-download50.py','*platform50*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','source':['app/chain/storage.py download_file','app/modules/filemanager/__init__.py download_file','app/modules/filemanager/storages/local.py download','app/api/endpoints/storage.py download,image'],'targets':targets,'behavior':['Existing authenticated file detail/image GET invokes download_file with full FileItem and path:null; source/clone ordering, None/list/scalar/exception and native return follow fixed dispatcher.','Actual returned local bytes drive both browser image and download; stopped/removed modules disappear and native content resumes.','Existing path/root/symlink/regular-file guards apply to requested and returned paths.'],'evidence':{'source_cases':16,'source_boundary':'fixed AST; Starlette1.3.1 response adapter explicitly development-only','actual_sdk_seconds':2.351,'related_seconds':20.503,'race_seconds':63.123,'linux_cli_seconds':1.83,'linux_browser_gate_seconds':312.29,'browser':'IAB89: Native.png73B preview decodes clone2x3; download81B hash equals override; sourceFalse500 produces broken0x0 image after reload, clone not called; restore2x3; cold changedPIDs0replay then2x3 eachone; files unchanged; uninstall404/native73B restored.','manifest':str((dest/'manifest.json').relative_to(r)),'build':build},'adaptations':['Go IPC serializes Python Path as an absolute UTF8 JSON string. No Python runtime dependency.','Existing GET file content route is shared by image and download, retains requested filename, content type, Range and auth. Source POST download falsey returns Response(success=False) while image returns500; native GET returns500 for falsey to avoid downloading a success-status error payload.','Existing allowed-root and no-symlink regular-file safety boundary remains; plugin override may return another allowed file but cannot expand access.','No frontend changes: browser memory cache can reuse old same-URL image until reload; cache hit not counted as module execution. Actual refresh/retry and server counters are separately captured.'],'failures_explained':['Initial SDK oracle test converted JSON null to an empty Go string/path; corrected fixture mapping only, original production path check was correct.','First SSH runner invocation preceded upload completion and exited missing script; subsequent launch after completed upload passed, no server failure.'],'remaining':['43:197methods/199ordinarycallsite final host applicability and coverage reconciliation','50:final scope evidence audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-browser-download-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';data=json.loads(p.read_text());data['browser_download_50_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-browser-download-20261028.json'};p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46验收通过，43文件下载/图片增量已封存：既有files/content接download_file普通模块，原生/来源/分身返回和异常来自16条固定AST对照；实际SDK2.351s、关联20.503s/race63.123s，main93734d99/test941265e0的3734/4224输入稳定。Linux1.83s/IAB89门312.29s实际73B请求预览分身2×3、下载81B哈希一致，False500/0×0→恢复→冷启新PID0重放→再次2×3；卸载404恢复原生73B、文件未变。详validation/plugin-browser-download-20261028.json，Path序列化/原生GET错误合同/允许目录/浏览器缓存适配已记录，owned目录进程/IAB89/34469已清理。继续43的197方法/199普通调用最终对应审计，再做50；无外部阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts;44/46 unchanged')
