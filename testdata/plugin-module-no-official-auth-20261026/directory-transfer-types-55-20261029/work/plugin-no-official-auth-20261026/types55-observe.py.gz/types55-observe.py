import json,pathlib,http.cookiejar,urllib.request,urllib.error,sys
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'types55-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 try:
  with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return {'status':x.status,'body':json.loads(x.read())}
 except urllib.error.HTTPError as e:return {'status':e.code,'body':json.loads(e.read())}
assert req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})['status']==200
before={k:req('GET','/api/v1/plugin/'+s[k]+'/snapshot')for k in ['source','clone']}
if mode in ['invalid','restore','empty']:
 cfg=json.loads(json.dumps(s['source_config']))
 if mode=='invalid':cfg['result']=9
 if mode=='empty':cfg['result']=False
 assert req('PUT','/api/plugins/'+s['source'],cfg)['body']['data']['success']
proof={'mode':mode,'before':before,'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'directories':req('GET','/api/directories/manage')}
(r/('types55-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'pids':[proof[k]['body']['pid']for k in ['source','clone']],'calls':[proof[k]['body']['calls']for k in ['source','clone']]})
