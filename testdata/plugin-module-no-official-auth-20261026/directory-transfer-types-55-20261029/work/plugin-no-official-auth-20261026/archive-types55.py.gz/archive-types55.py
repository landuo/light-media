import gzip,hashlib,json,re
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'types55-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/directory-transfer-types-55-20261029';sha=lambda b:hashlib.sha256(b).hexdigest()
build=json.loads((w/'platform55r2-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for name,seconds in [('types55r2-cli.log','1.64s'),('types55r2-ui.log','242.55s')]:assert 'PASS' in (remote/name).read_text()and seconds in (remote/name).read_text()
assert 'pass 556' in (w/'types55-web-all-final.log').read_text()and 'fail 0' in (w/'types55-web-all-final.log').read_text()
assert 'ok  \tlight-media/internal/app\t19.726s' in (w/'types55-race.log').read_text()
browser={n:json.loads((remote/('types55r2-browser-'+n+'.json')).read_text())for n in ['before','saved','failed','recovered','empty-rejected','cold','final']}
for n in ['saved','empty-rejected','cold','final']:assert browser[n]['directories']['body']['data']['directories'][0]['config']['mode']=='copy'
for k in ['source','clone']:
 count=lambda n:browser[n][k]['body']['calls'].get('module_execute',0)
 assert count('saved')-count('before')==4
 assert count('cold')==0 and count('final')==2
 assert browser['cold'][k]['body']['pid']!=browser['saved'][k]['body']['pid']
 assert count('recovered')-count('failed')==2
assert browser['failed']['source']['body']['calls']['module_execute']==6 and browser['failed']['clone']['body']['calls']['module_execute']==5
assert json.loads((w/'types55-cleanup.json').read_text())['remaining_test_roots']==[]
targets=['internal/app/plugin_original_transfer_types.go','internal/app/directory_manage.go','web/src/components/DirectoryManager.vue','web/src/features/directory-transfer-types.ts','internal/app/plugin_original_transfer_types_test.go','internal/app/plugin_module_process_transfer_types_test.go','internal/app/plugin_module_process_services_test.go','web/tests/directory-transfer-types.test.mjs','web/tests/directory-overwrite.test.mjs']
paths={r/p for p in targets};paths.update((r/'testdata/standard-module-host').glob('*transfer-types*'))
for pattern in ['types55*','platform55*.json','build-platform55*.py','run-types55*.py','archive-types55.py','*platform55*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.jsonl','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/chain/storage.py:142-146','app/api/endpoints/storage.py:270-285','app/schemas/file.py:83','app/modules/filemanager/storages/local.py:24-29','src/components/cards/DirectoryCard.vue:129-175'],'targets':targets,'behavior':['Ordinary support_transtype goes source→clone→native by fixed None/list/scalar semantics, including invalid truthy DTO status500; preserve returned dictionary insertion order.','Each directory card performs two sequential local queries, intersects source keys with destination, preserves source labels/order, retains valid selection or defers first available selection to nextTick; empty intersection clears, failure leaves current selection.'],'evidence':{'source_cases':10,'source_ui_cases':6,'actual_sdk_http_seconds':2.980,'frontend_full_tests':556,'race_seconds':19.726,'linux_cli_seconds':1.64,'linux_browser_gate_seconds':242.55,'browser':'IAB93: source None→clone copy/link; persisted auto becomes first copy and actual Save persists copy. Initial+post-save queries each add2 source/clone calls. Source9 returns500 and skips clone; visible error→retry restores two queries. SourceFalse clears options; Save rejected, persisted copy retained. New PIDs1140103/1140110→1144959/1144965 have0 calls before reload, then2 each, restored copy. Uninstall both→404 and native dictionary restored.','build':build,'manifest':str((dest/'manifest.json').relative_to(r))},'adaptations':['Existing Go organizer supports hardlink/copy/auto; native dictionary therefore link/copy/auto, not fixed local copy/move/link/softlink. UI maps link→hardlink and only offers existing executable modes. Raw plugin response is not filtered; no new move/symlink business system.','Target authenticated /api/directories/transfer-types replaces source storage/transtype/local; source query storage remains exactly local. Linux/local-only scope does not introduce cloud storage parameters.','Empty selection cannot save an enabled target directory because its older native API defaults empty mode to hardlink; explicit UI rejection prevents silently changing source empty behavior. Visible retry augments original console-only error handling.','Owned SDK fixtures plus synthetic empty directories; no user media or external provider. Python is development oracle/observer only.'],'failures_explained':['First Linux fixture expected plugin-style data.success from ordinary directory save, whose actual response contains data.directories. Fixed assertion now checks persisted mode through that DTO; production binary unchanged.','Four overwrite frontend fixtures lacked the new real helper import and assumed the last request was always PUT. Bound actual helper and locate PUT explicitly; all prior policy assertions retained; final556pass.'],'remaining':['43 complete caller/guard applicability audit','50 final evidence audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-directory-transfer-types-20261029.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';d=json.loads(p.read_text());d['directory_transfer_types_55_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-directory-transfer-types-20261029.json'};p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46；main55目录support_transtype增量已封存。10固定B回放/6固定F回放、真实SDK/HTTP2.980s、相关race19.726s、556前端均通过。main73add6db/test654d318a的3746/4242输入稳定；Linux1.64s/IAB93门242.55s验证每卡两次顺序调用、来源None/分身copy→link首项回填及实际保存、9错误跳过分身/重试恢复、False空状态阻止隐式硬链接保存、冷PID零调用后页面各调用2次、卸载原生恢复。保留Go硬链接/复制/auto适配，详validation/plugin-directory-transfer-types-20261029.json。main54平台初跑371通过后超时，补跑40通过及2项修复通过：旧夹具已刷新；公开通知投影校验已补，站点事件测试补入固定SiteUpdated创建后刷新前缀。完整197方法/231直调+1间接守卫审计继续，Web PROCESSING_STATUS固定能力表为false，不据逆向可达性误接外部IM。43/50仍未完成；owned服务/目录/IAB93/34473已清理，未提交推送部署。'
for name,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/name;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts;44/46 unchanged')
