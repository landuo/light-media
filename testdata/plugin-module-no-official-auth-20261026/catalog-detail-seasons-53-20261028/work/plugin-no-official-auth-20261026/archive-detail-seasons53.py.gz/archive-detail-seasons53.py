import gzip,hashlib,json
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'seasons53-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/catalog-detail-seasons-53-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest();build=json.loads((w/'platform53-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for p,seconds in [(remote/'seasons53-cli.log','2.09s'),(remote/'seasons53-ui.log','470.66s')]:assert seconds in p.read_text()and 'PASS' in p.read_text()
assert 'pass 13' in (w/'detail-seasons53-web-tests-final.log').read_text()
for p,h in json.loads((w/'detail-seasons53-web-inputs.json').read_text()).items():assert sha((r/p).read_bytes())==h,p
browser={n:json.loads((remote/('seasons53-browser-'+n+'.json')).read_text())for n in ['initial-error','selected','empty-loaded','cold','final']}
for k in ['source','clone']:
 assert browser['cold'][k]['body']['pid']!=browser['selected'][k]['body']['pid']
 for m in ['module_search_media','module_episodes']:assert browser['cold'][k]['body']['calls'].get(m,0)==0
assert browser['final']['source']['body']['calls']['module_search_media']==1
assert browser['final']['source']['body']['calls']['module_episodes']==1
x=browser['selected']['source']['body']['inputs']['module_episodes'];x=json.loads(x)if isinstance(x,str)else x;assert x['kwargs']['season']==2,x
assert json.loads((w/'seasons53-cleanup.json').read_text())['remaining_test_roots']==[]
targets=['web/src/features/subscriptions.ts','web/src/components/Catalog.vue','web/src/components/Subscriptions.vue','web/tests/subscriptions.test.mjs','internal/app/plugin_module_process_catalog_seasons_test.go'];paths={r/p for p in targets};paths.update((r/'testdata/standard-catalog-modules').glob('*detail_seasons*'));paths.update((r/'testdata/standard-catalog-modules').glob('*detail-seasons*'))
for pattern in ['seasons53*','detail-seasons53*','platform53*.json','build-platform53.py','run-seasons53.py','archive-detail-seasons53.py','*platform53*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['src/views/discover/MediaDetailView.vue:273-280','app/schemas/context.py:139','src/components/dialog/SubscribeEditDialog.vue'],'targets':targets,'behavior':['Use recognized original_media.season_info for the existing detail selector and subscription total, retaining raw dictionaries; sort numbered seasons ascending, zero last exactly as fixed computed function.','Null and empty original season_info stay empty; only older native records without original season_info use compact seasons. No second seasons-module call from detail.'],'evidence':{'source_frontend_cases':6,'frontend_tests':13,'web_build':'vue-tsc and production build passed','linux_cli_seconds':2.09,'linux_browser_gate_seconds':470.66,'browser':'IAB92 source plugin raw order0,2,1 rendered1,2,0 with3/8/1 counts; select2 -> actual async_tmdb_episodes season2 -> subscription form season2,total8. Source episode False returned500 and disabled subscription; actual retry after valid empty tuple restored. Null original seasons shows no data; restore + real cold has new PIDs, zero recognition/episodes, browser then exactly1 each and sorted rows restored. No subscription submission.','build':build,'manifest':str((dest/'manifest.json').relative_to(r))},'adaptations':['Retain existing target VSelect and subscription form rather than adding the entire source media detail business page; plugin fields and sorting match fixed source.','Original raw MediaInfo and compact target fields coexist; UI reads authoritative raw seasons where available. Old record compatibility remains.','Provider is an owned Go SDK plugin; no live external media provider involved.'],'failures_explained':['First UI fixture assumed episode False was an empty result. Fixed-source episode oracle specifies500, and UI correctly refused subscription. Changed only owned fixture config through authenticated PUT to explicit empty tuple; retained initial error snapshot and source expectation.','First login selector used macOS accessibility label rather than actual DOM duplicated label; refreshed DOM and selected exact existing label.'],'remaining':['43:197 method/231 direct call source audit and boundary classification','50:final evidence audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-catalog-detail-seasons-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';d=json.loads(p.read_text());d['catalog_detail_seasons_53_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-catalog-detail-seasons-20261028.json'};p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46；main53详情季数据已封存：使用插件MediaInfo.season_info，按固定F排序1/2/0，null不回退；6源函数回放/13最终前端及构建通过。main658171bb/test0f467b69的3745/4239输入稳定；Linux2.09s/IAB92门470.66s验证选第2季实际单集kwargs season2及订阅总集数8、False单集错误禁用/空元组恢复、null空列表、冷PID1092641/1092654→1099840/1099848零重放后各调用1次。详validation/plugin-catalog-detail-seasons-20261028.json；进程/owned目录/IAB92/34472清理完成。完整固定B全529文件重扫仍231直调+1间接回调，保留197方法索引；当前生成带类接收者的逆向调用证据，避免logger.info等同名误判。43适用边界与50尚待，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts;44/46 unchanged')
