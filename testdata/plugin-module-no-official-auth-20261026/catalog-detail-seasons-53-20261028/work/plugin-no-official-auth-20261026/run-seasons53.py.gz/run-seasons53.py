import pathlib,os,sys,subprocess,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');os.chdir(r);mode=sys.argv[1];tmp=r/('seasons53-'+mode+'-tmp');tmp.mkdir(exist_ok=True)
names=['server-platform53-20261027-linux','process-platform53-20261027-linux.test','bluray44-worker-linux']
for n in names:(r/n).chmod(0o700)
print({n:hashlib.sha256((r/n).read_bytes()).hexdigest()for n in names},flush=True)
env=os.environ|{'TMPDIR':str(tmp),'PLUGIN_PROCESS_SERVER_BINARY':str(r/names[0]),'OWNED_INPUT_PROCESS_FIXTURE_BINARY':str(r/'services38-input-final-linux'),'OWNED_TRANSFER_MODULE_PROCESS_BINARY':str(r/names[2]),'PLUGIN_PROCESS_CATALOG_SEASONS_FIXTURE':'true','PLUGIN_PROCESS_CATALOG_DETAIL_SEASONS':'true','PLUGIN_PROCESS_EVENTS36_EVIDENCE_DIR':str(r/('seasons53-'+mode+'-evidence'))}
if mode=='ui':env['PLUGIN_PROCESS_CATALOG_SEASONS_STATE']=str(r/'seasons53-ui-state.json')
with(r/('seasons53-'+mode+'.log')).open('w')as f:p=subprocess.run([str(r/names[1]),'-test.run=^TestPluginServicesProductionCLI$','-test.v','-test.timeout=35m'],env=env,stdout=f,stderr=subprocess.STDOUT)
print((r/('seasons53-'+mode+'.log')).read_text()[-3000:]);raise SystemExit(p.returncode)
