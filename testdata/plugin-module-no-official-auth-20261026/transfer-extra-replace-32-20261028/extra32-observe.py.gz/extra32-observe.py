import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,sqlite3
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module32-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
source=pathlib.Path(s['directory'])/'browser32/SingleExtraSubtitle.2024.zh.srt'
def mapped(v):
 if isinstance(v,dict):return {k:mapped(x)for k,x in v.items()}
 if isinstance(v,list):return [mapped(x)for x in v]
 if v==90001799:return 90009810
 if isinstance(v,str):return v.replace('Owned high-level UI','SingleExtraSubtitle')
 return v
if mode=='prepare':
 source.parent.mkdir(exist_ok=True);assert not source.exists();source.write_bytes(b'owned browser replacement subtitle 32')
 cfg=mapped(s['source_config']);cfg['modules']={'recognize_media':'module_search_media','transfer':'module_execute'};cfg['result']=None
 for k in ['transfer_results','transfer_targets','build_transfer_info']:cfg.pop(k,None)
 assert req('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert req('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{'transfer':'module_execute'},'result':None})['data']['success']
def file(p):
 p=pathlib.Path(p)
 if not p.is_file():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'exists':True,'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=req('GET','/api/history/transfers?q=SingleExtraSubtitle')['data'];prior=next(i for i in h['items']if '/replacement/'in i['source']);target=prior['target'];plans=req('GET','/api/import/plans')['data']
db=sqlite3.connect('file:'+s['data_dir']+'/light-media.db?mode=ro',uri=True)
assets=[json.loads(x[0])for x in db.execute("SELECT payload FROM records WHERE kind='asset'")if json.loads(x[0]).get('media',{}).get('id')==90009810]
owned=[json.loads(x[0])for x in db.execute("SELECT payload FROM records WHERE kind='managed_file' AND json_extract(payload,'$.path')=?",(target,))];db.close()
proof={'mode':mode,'history':h,'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'plans':[p for p in plans if any(f['source']==str(source)for f in p['files'])],'video_assets':assets,'target_owner':owned,'files':[file(source),file(prior['source']),file(target),file(pathlib.Path(s['target'])/'SingleExtraSubtitle (2024)/SingleExtraSubtitle (2024).mkv')],'target':target}
(r/('extra32-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'histories':h['total'],'source_pid':proof['source']['pid'],'clone_pid':proof['clone']['pid'],'calls':[proof[k]['calls'].get('module_execute',0)for k in ['source','clone']],'owned':[(x['kind'],x['asset_id'])for x in owned]})
