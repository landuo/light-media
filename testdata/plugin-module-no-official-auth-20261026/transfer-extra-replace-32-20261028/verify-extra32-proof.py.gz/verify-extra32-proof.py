import pathlib,json
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'extra32-runtime'
def read(n):return json.loads((r/('extra32-browser-'+n+'.json')).read_text())
p,v,a,c=[read(n)for n in ['prepare','preview','executed','cold']]
assert p['history']==v['history'] and p['files']==v['files'] and p['target_owner']==v['target_owner']
assert p['history']['total']==2 and a['history']['total']==c['history']['total']==3
assert a['history']==c['history'] and a['files']==c['files'] and a['target_owner']==c['target_owner']
assert not a['video_assets'] and not c['video_assets'] and not a['files'][3]['exists']
for k in ['inode','device','size','sha256']:
 assert p['files'][1][k]==p['files'][2][k]
 assert a['files'][0][k]==a['files'][2][k]
 assert p['files'][1][k]==a['files'][1][k]
assert p['files'][2]['inode']!=a['files'][2]['inode']
assert p['target_owner'][0]['asset_id']!=a['target_owner'][0]['asset_id']
assert all(a[k]['pid']!=c[k]['pid']for k in ['source','clone'])
assert [a[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[2,2]
assert [c[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[0,0]
assert '总数 1 · 失败 0' in (b/'extra32-browser/01-preview-existing-extra.dom.txt').read_text()
assert '1 - 1 / 1' in (b/'extra32-browser/02-cold-replacement-success.dom.txt').read_text()
result={'passed':True,'preview_preserves_old_file_and_owner':True,'old_source_preserved':True,'new_target_is_actual_hardlink':True,'no_video_asset_or_main_file':True,'pids':[[d[k]['pid']for k in ['source','clone']]for d in [a,c]],'old_target_inode':p['files'][2]['inode'],'new_target_inode':a['files'][2]['inode'],'cold_write_calls':0,'files':c['files']}
(b/'extra32-browser-verdict.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in result.items()if k!='files'})
