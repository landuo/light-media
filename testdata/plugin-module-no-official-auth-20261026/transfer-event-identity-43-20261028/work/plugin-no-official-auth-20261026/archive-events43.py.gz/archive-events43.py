from pathlib import Path
import json,hashlib,gzip
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';d=r/'testdata/plugin-module-no-official-auth-20261026/transfer-event-identity-43-20261028';d.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
build=json.loads((w/'platform43r2-result.json').read_text())
for b in build['binaries']:
 inputs=json.loads((w/(b['name']+'.inputs.json')).read_text());assert all(sha(Path(p).read_bytes())==v for p,v in inputs.items())
for name in ['completed43r2-cli.log','completed43r2-ui.log','events43-local.log','events43-race.log']:
 s=(w/name).read_text();assert ('PASS' in s or 'ok  ' in s)and'FAIL'not in s,name
v={n:json.loads((w/f'completed43r2-browser-{n}.json').read_text())for n in ['before-cold','cold-cancelled','retry-success','cold-success']}
assert all(v[n]['job']['data']['job']['state']=='cancelled'for n in ['before-cold','cold-cancelled'])
assert not v['cold-cancelled']['target_file']['exists']
for n in ['retry-success','cold-success']:
 a=v[n];assert a['job']['data']['job']['state']=='succeeded';assert a['source_file']['inode']==a['target_file']['inode'];assert a['target_file']['size']==22;assert len(a['journal']['writes'])==2
 for k in ['source','clone']:assert a[k]['calls'].get('module_execute',0)==0
for k in ['source','clone']:
 assert len({v[n][k]['pid']for n in ['before-cold','cold-cancelled','cold-success']})==3
 assert v['cold-success'][k]['calls'].get('module_storage_parent',0)==0
verdict={'pass':True,'pids':{n:[a[k]['pid']for k in ['source','clone']]for n,a in v.items()},'same_inode':v['cold-success']['target_file']['inode'],'source_target_sha256':v['cold-success']['target_file']['sha256'],'tag_writes':2,'cold_no_plugin_replay':True,'iab':82,'cleanup':'IAB82 closed; tunnel34462 stopped; Linux gate completed with uninstall/API404; data and source/target paths checked absent'}
(w/'completed43r2-browser-verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
targets=['internal/app/plugin_original_transfer_events.go','internal/app/plugin_original_transfer_completed_test.go','internal/app/plugin_original_transfer_event_identity_test.go','internal/app/plugin_original_modules_test.go','internal/app/plugin_module_process_transfer_completed_test.go','testdata/standard-module-host/transfer-event-identity-source-oracle.json']
paths={r/p for p in targets}
for pattern in ['*completed43*','platform43*.json','platform43*.log','events43*.log','build-platform43*.py','archive-events43.py']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(x for x in p.rglob('*')if x.is_file())
  else:paths.add(p)
artifacts=[]
for p in sorted(paths):
 b=p.read_bytes();out=d/p.relative_to(r);payload=b
 if p.suffix!='.png':out=Path(str(out)+'.gz');payload=gzip.compress(b,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload);artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(b),'stored_sha256':sha(payload)})
(d/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[36,37,43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','source':['app/chain/download.py:919-955: module returned downloader frozen in history','app/chain/transfer.py:3487-3515: task inherits history identity when either explicit field is absent','app/chain/transfer.py:1153-1189,1267-1303: six callbacks use task.downloader'],'target':'internal/app/plugin_original_transfer_events.go:emitOriginalTransferResult','change':'Use encrypted accepted download context OriginalDownloader, retaining frozen name or JSON null; never use requested automatic selector or native internal ID. Legacy history without a source projection resolves configured display name. Missing legacy setting yields null. Context integrity failure aborts the projection and reports the existing event error.','evidence':{'source':'5 AST history-selection cases and 6 exact callback dictionaries','sdk':'11 actual import SDK scenarios; frozen name on success and failed callback, explicit null, legacy configured-name fallback','local_seconds':6.760,'race_seconds':35.828,'linux_cli_seconds':2.13,'linux_browser_seconds':163.62,'browser':verdict,'build':build,'manifest':str((d/'manifest.json').relative_to(r))},'red':'First Linux test 1.71s failed because fixture compared the cumulative event journal with only the latest scenario expectation; corrected to compare each actual before/after delta. Runtime binary unchanged.','limits':['No frontend changes; real browser retries and cold persistence verified against the new main.','All fixture intents and byte files are synthetic setup; SDK invocation, production cmd/server, native HTTP/files/SQLite, browser and process restarts are real.','Whole36/37/43/50, bluray unit publication and final ordinary host applicability audit remain open.'],'delivery':{'branch':'dev/plugins-continuation','head':'7fc62635bc4a8f37068a14c2680161df7ccfb5ed','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-transfer-event-identity-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';s=json.loads(p.read_text());s['transfer_event_identity_43_increment']={'accepted_increment':True,'whole_indices_accepted':False,'evidence':'docs/validation/plugin-transfer-event-identity-20261028.json','remaining':'36/37/43/50; bluray unit publication and ordinary host applicability audit'};p.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
paragraph='main43r2 整理事件下载器身份增量已验收（42/46不变）：固定5例历史身份选择与6类callback字典已核，读取既有加密下载上下文的实际返回名称/null，旧记录才解析配置名称，停止向插件暴露内部ID。11场实际SDK整理6.760s/race35.828s；main10cc8184/testb4c12da0、3724/4197编译输入稳定；Linux2.13s/IAB82门163.62s通过来源/分身事件字段与取消冷启重试、22B同inode、四成功历史及第二次冷启零重放。首Linux夹具累计事件比较错误已修，主程序未变。详validation/plugin-transfer-event-identity-20261028.json；IAB82、34462、进程及自建目录已清理。下一项：蓝光目录作为单个插件任务的实际发布及197/199/81宿主最终适用性审计。无外部阻塞，未提交推送部署。'
for filename,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/filename;s=p.read_text();s=s.replace(marker+'\n',marker+'\n\n'+paragraph+'\n',1);p.write_text(s)
print('Archived',len(artifacts),'artifacts; inputs unchanged; observed browser facts asserted')
