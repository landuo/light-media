from pathlib import Path
import hashlib,json,gzip
root=Path.cwd();work=root/'work/plugin-no-official-auth-20261026';dest=root/'testdata/plugin-module-no-official-auth-20261026/transfer-completed-42-20261028';dest.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
build=json.loads((work/'platform42r3-result.json').read_text())
for binary in build['binaries']:
    inputs=json.loads((work/(binary['name']+'.inputs.json')).read_text())
    changed=[p for p,h in inputs.items()if sha(Path(p).read_bytes())!=h]
    assert not changed,changed
for name in ['completed42r3-cli.log','completed42r3-ui.log','completed42r3-related.log','completed42r3-race.log','completed42r2-race.log']:
    text=(work/name).read_text();assert ('PASS' in text or 'ok  ' in text) and 'FAIL' not in text,name
assert 'FAIL' in (work/'completed42-ui-red.log').read_text()
verdict=json.loads((work/'completed42r3-browser-verdict.json').read_text());assert verdict['pass']
targets=['internal/app/plugin_original_transfer_completed.go','internal/app/plugin_original_transfer_completed_test.go','internal/app/plugin_module_process_transfer_completed_test.go','internal/app/plugin_module_process_services_test.go','internal/app/job_completion.go','internal/app/search_download.go','internal/app/import_run.go','internal/app/plugin_original_transfer_module.go','internal/app/plugin_original_transfer_target.go']
paths={root/p for p in targets+['testdata/standard-module-host/generate-transfer-completed-oracle.py','testdata/standard-module-host/transfer-completed-source-oracle.json']}
for pattern in ['*completed42*','*platform42*.json','*platform42*.log','build-platform42*.py']:
    for p in work.glob(pattern):
        if p.is_dir():paths.update(x for x in p.rglob('*')if x.is_file())
        elif p.is_file():paths.add(p)
artifacts=[]
for p in sorted(paths):
    rel=p.relative_to(root);data=p.read_bytes();out=dest/rel
    payload=data
    if p.suffix not in ['.png','.jpg','.gz']:out=Path(str(out)+'.gz');payload=gzip.compress(data,mtime=0)
    out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(payload)
    artifacts.append(dict(path=str(out.relative_to(root)),original=str(rel),sha256=sha(data),stored_sha256=sha(payload),size=len(data)))
manifest={'kind':'Pinned source AST replay; real Go SDK with owned qB/TR HTTP peers; real Linux cmd/server and IAB81; synthetic downloaded intent setup and 22-byte files explicitly distinguished','whole_indices_accepted':False,'binaries':build['binaries'],'worker_sha256':'9a1d5c5c35982625a59002d8148c6f2a14ff5b728c82a6e190d9f92b9aa83990','artifacts':artifacts}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
report={
 'accepted_increment':True,'complete':False,'indices':[36,37,43],
 'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60',
 'mapping':[
  {'source':['app/chain/transfer.py:661-673,1338,1427-1474,1888,3679','app/chain/__init__.py:1402-1424,1478-1484'],
   'behavior':'After physical callbacks, require every registered task to be finished (failed also counts), query the whole torrent using string hashs plus downloader name and status=None/include_all_tags=False; empty/unknown/incomplete progress suppresses marking. Recheck tasks after the query before calling transfer_completed. Retry completed but untagged history without republishing files.',
   'target':targets[:1]+['internal/app/job_completion.go:finishJob','internal/app/search_download.go:pollDownloads'],
   'evidence':['transfer-completed-source-oracle.json:11 source guard cases','TestOriginalTransferCompletedFixedSourceProgress','TestOriginalTransferCompletedActualImportSDK','TestOriginalTransferCompletedPendingAndNewTask','completed42r3-cli-evidence/completed42-cli.json','completed42r3-browser-verdict.json']},
  {'source':['app/modules/qbittorrent/__init__.py:455-465','app/modules/transmission/__init__.py:454-472','app/modules/qbittorrent/qbittorrent.py:336-347','app/modules/transmission/transmission.py:168-201'],
   'behavior':'None/list continues into the native provider; False or another scalar ends dispatch. QB adds the organized tag; TR reads/trims existing labels and writes their union with the tag. Protocol write errors are logged and swallowed by the source helper, without SystemError. Source wrapper ignores the native helper return value.',
   'target':['internal/app/plugin_original_transfer_completed.go:originalTransferDownloaderModule','internal/download/native.go:SetTorrentTags'],
   'evidence':['transfer-completed-source-oracle.json:4 native wrappers +4 actual protocol helpers','TestOriginalTransferCompletedActualImportSDK:11 scenarios including SDK list/tuple, native partial/failure/restore and TR duplicate labels','Linux source False/clone False/None native tag cases']},
  {'source':['app/chain/transfer.py:1630-1635,1697-1770','existing target generation/cancellation and recoverable publication contract'],
   'behavior':'Known native cancellation after plugin fallback is a stopped execution, not a frozen physical failure. Resume the existing native publisher under the new job generation; keep the prior plugin decision and all ownership guards. Unknown plugin results and explicit plugin refusal remain frozen.',
   'target':['internal/app/import_run.go:OriginalNativeInterrupted','internal/app/plugin_original_transfer_module.go:originalTransferModulePublish','internal/app/plugin_original_transfer_target.go:transitionOriginalTransferTargetAt'],
   'evidence':['IAB79 failed retry with no target (red)','TestOriginalTransferCompletedCancelledNativeResume','IAB80 and IAB81 cancelled -> actual cold restart -> UI retry -> real same-inode hardlink -> second cold restart with zero invocation replay']}
 ],
 'results':{'final_build':build,'related_seconds':6.823,'final_focused_race_seconds':23.517,'unchanged_cancellation_target_and_module_regression_race_seconds':106.768,'linux_cli_seconds':2.11,'linux_browser_gate_seconds':238.07,'browser':verdict,'older_versions':{'main42':'76bb98cb: CLI2.06s pass, IAB79/240.15s failed cancellation retry; not current success evidence','main42r2':'2e3eecc1: CLI2.17s, IAB80/383.34s pass; protocol catch/label refinement is only in r3'}},
 'failures_fixed':[{'evidence':'completed42-ui-red.log; completed42-browser-after-retry.json','cause':'Cancelled native fallback was frozen as failed TransferInfo and generated a physical failure callback, so retry returned the old cancellation.','fix':'Persist only the known native interruption flag, resume native publication without replaying plugins, and do not emit a physical callback from an invalidated execution.'},{'evidence':'completed42-local-r1.log','cause':'Test setup changed an already sealed preview to add intent identity. Production rejected the changed authority correctly.','fix':'Generate a fresh real preview with intent identity; do not weaken the plan seal.'}],
 'adaptations':[
  'Native persistent jobs replace the source in-memory job view. Check existing nonterminal import jobs by their owned torrent hash; cancelled jobs correspond to removed source tasks. One native grouped job waits for committed callbacks of its selected files before the completion check.',
  'Download selection uses the configured native downloader ID internally, then passes its source-facing name to both ordinary module wrappers. Only configured enabled peers with an unchanged destination snapshot and actual task ownership can receive native tag writes.',
  'TR native ownership read failure stops mutation rather than overwriting unknown labels; source protocol helper can proceed after returning an empty tag list. This retains the existing target ownership guard.',
  'TR set iteration order is undefined in Python; Go preserves first occurrence after trimming/deduplication. Compare label sets for wire order neutrality.',
  'Post-commit completion runs before broadcasting the closed scrape batch; the existing transaction commits tasks and prepares the native scrape job before external HTTP effects. File/history ownership remains transactional.',
  'Downloaded intents and byte fixtures are explicit synthetic setup. SDK/Main invocations, HTTP protocol effects, file links, SQLite state, browser actions and cold processes are real. No real user download, external metadata account or old MoviePilot service is used.',
  'Python is only a test-time fixed-source oracle; runtime remains Go. Existing frontend bundle is unchanged and covered by each actual compiler embed input manifest.'
 ],
 'limits':['Whole36/37/43/50 remain open. Directory-unit/bluray, source event downloader-name fields and final 197-method/199-call/81-event host applicability audit are not claimed.','TR/error wire paths are real SDK+owned protocol replay; the production Linux/browser workflow uses the owned qB peer.'],
 'evidence_manifest':str((dest/'manifest.json').relative_to(root)),
 'cleanup':{'iab79_80_81_closed':True,'tunnels34459_34460_34461_stopped':True,'final_source_clone_uninstalled_api404':True,'final_test_process_completed':True,'owned_data_removed':json.loads((work/'completed42-cleanup.json').read_text())},
 'delivery':{'branch':'dev/plugins-continuation','head':'7fc62635bc4a8f37068a14c2680161df7ccfb5ed','uncommitted':True,'pushed':False,'deployed':False}}
(root/'docs/validation/plugin-transfer-completed-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
central=root/'docs/validation/plugin-module-no-official-auth-20261026.json';state=json.loads(central.read_text());state['transfer_completed_42_increment']={'accepted_increment':True,'whole_indices_accepted':False,'evidence':'docs/validation/plugin-transfer-completed-20261028.json','remaining':'36/37/43/50; ordinary event downloader-name fields, bluray and full ordinary host applicability audit'};central.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
print('archived',len(artifacts),'artifacts; final source/compiler inputs unchanged')
