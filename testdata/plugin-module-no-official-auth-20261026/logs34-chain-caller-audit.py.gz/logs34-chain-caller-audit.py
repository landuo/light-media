"""Exact pinned caller/log/event methods; owned frames/registry/message sink only."""
import ast,hashlib,inspect,json,logging,pathlib,queue,sys,threading,time,traceback,types,uuid
from enum import Enum
from typing import *
root=pathlib.Path('/Users/accidia/projects/MoviePilot')
log=(root/'app/log.py').read_text(); event=(root/'app/core/event.py').read_text()
def methods(text,owner,names,filename,namespace):
 tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==owner)
 nodes=[n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
 assert len(nodes)==len(names),(owner,[n.name for n in nodes])
 new=ast.ClassDef(name=owner,bases=[],keywords=[],body=nodes,decorator_list=[])
 module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),new],type_ignores=[])
 exec(compile(ast.fix_missing_locations(module),filename,'exec'),namespace)
 return namespace[owner]
records=[]
class Console:
 def error(self,*args):pass
class Consoles(dict):
 def get(self,*args):return Console()
ns=dict(logging=logging,Path=pathlib.Path,sys=sys,LoggerManager=None,log_settings=types.SimpleNamespace(DEBUG=False,LOG_LEVEL='ERROR',LOG_PATH=pathlib.Path('/owned/logs')))
L=methods(log,'LoggerManager',['__get_caller','__get_log_level','logger','error','debug'],'/owned/app/log.py',ns)
L._lock=threading.RLock();logger=L();logger._loggers=Consoles();logger._default_log_file='moviepilot.log';logger._file_handler=types.SimpleNamespace(write_log=lambda level,message,file_path:records.append(dict(level=level,filename=str(file_path),kind='handler' if message.endswith('owned receiver before failure') else 'host_error')))
class ChainEventType(Enum):Owned='owned.chain'
class EventType(Enum):SystemError='system.error'
en=dict(logger=logger,inspect=inspect,time=time,traceback=traceback,uuid=uuid,EventType=EventType,ChainEventType=ChainEventType,DEFAULT_EVENT_PRIORITY=10)
tree=ast.parse(event);event_class=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Event')
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),event_class],type_ignores=[])),'/owned/app/core/event.py','exec'),en)
M=methods(event,'EventManager',['send_event','__trigger_chain_event','__dispatch_chain_event','__safe_invoke_handler','__invoke_handler_by_type_sync','__parse_handler_names','__is_handler_enabled','__get_handler_identifier','__get_class_from_callable','__log_event_lifecycle','__handle_event_error','__trigger_broadcast_event'],'/owned/app/core/event.py',en)
receiver_ns=dict(__name__='app.plugins.ownedreceiver',logger=logger)
exec(compile('class OwnedReceiver:\n name="owned receiver"\n def fail(self,event):\n  logger.error("owned receiver before failure")\n  raise RuntimeError("owned failure")\n','/owned/app/plugins/ownedreceiver/__init__.py','exec'),receiver_ns)
receiver=receiver_ns['OwnedReceiver']()
plugin_stub=types.ModuleType('app.core.plugin');plugin_stub.PluginManager=lambda:types.SimpleNamespace(get_plugin_ids=lambda:['OwnedReceiver'],running_plugins={'OwnedReceiver':receiver})
module_stub=types.ModuleType('app.core.module');module_stub.ModuleManager=lambda:types.SimpleNamespace(get_module_ids=lambda:[])
messages=[];message_stub=types.ModuleType('app.helper.message');message_stub.MessageHelper=lambda:types.SimpleNamespace(put=lambda **kwargs:messages.append(kwargs))
for module in [plugin_stub,module_stub,message_stub]:sys.modules[module.__name__]=module
manager=M();manager._EventManager__chain_subscribers={ChainEventType.Owned:{'owned_receiver':(10,receiver.fail)}};manager._EventManager__disabled_handlers=set();manager._EventManager__disabled_classes=set();manager._EventManager__event_queue=queue.PriorityQueue()
cases=[]
for label,filename,expected in [('sender','/owned/app/plugins/ownedsender/__init__.py','ownedsender'),('clone_sender','/owned/app/plugins/ownedsenderclone/__init__.py','ownedsenderclone'),('native','/owned/app/main.py',None)]:
 caller={};exec(compile('def send(manager,kind):\n return manager.send_event(kind,{"owned":True})\n',filename,'exec'),caller)
 before=len(records);result=caller['send'](manager,ChainEventType.Owned);actual=records[before:]
 expected_host='/owned/logs/plugins/'+expected+'.log' if expected else '/owned/logs/moviepilot.log'
 assert [r['filename'] for r in actual]==['/owned/logs/plugins/ownedreceiver.log',expected_host],actual
 assert result is not None
 cases.append(dict(case=label,caller_filename=filename,records=actual,error_continues=True))
assert len(messages)==3
print(json.dumps(dict(commit='8a83efeacd3e26b82be495e17d50146e31c96a60',sha256={'app/log.py':hashlib.sha256(log.encode()).hexdigest(),'app/core/event.py':hashlib.sha256(event.encode()).hexdigest()},kind='actual pinned caller/logger/synchronous event dispatch AST with owned compiled frames, registry and notification queue; no running original service',cases=cases,source_system_error_notifications=len(messages)),ensure_ascii=False,indent=2))
