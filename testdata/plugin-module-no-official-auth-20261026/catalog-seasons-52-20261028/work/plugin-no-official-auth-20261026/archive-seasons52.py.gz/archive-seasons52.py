import gzip,hashlib,json
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'seasons52-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/catalog-seasons-52-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest();build=json.loads((w/'platform52r2-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for p,seconds in [(w/'seasons52r2-related.log','36.071s'),(w/'seasons52r2-race.log','6.078s'),(remote/'seasons52r2-cli.log','2.08s'),(remote/'seasons52r2-ui.log','529.02s')]:assert seconds in p.read_text()and ('PASS' in p.read_text()or 'ok  ' in p.read_text())
for p,h in json.loads((w/'seasons52-web-inputs.json').read_text()).items():assert sha((r/p).read_bytes())==h,p
browser={n:json.loads((remote/('seasons52r2-browser-'+n+'.json')).read_text())for n in ['loaded','invalid','failed','restore','restored','cold','final']}
method='module_execute'
assert browser['failed']['source']['body']['calls'][method]==browser['invalid']['source']['body']['calls'][method]+1
assert browser['failed']['clone']['body']['calls'][method]==browser['invalid']['clone']['body']['calls'][method]
for k in ['source','clone']:
 assert browser['cold'][k]['body']['pid']!=browser['restored'][k]['body']['pid']
 assert browser['cold'][k]['body']['calls'].get(method,0)==0
 assert browser['final'][k]['body']['calls'][method]==1
assert browser['restored']['source']['body']['calls']['module_search_media']==browser['failed']['source']['body']['calls']['module_search_media']
assert json.loads((w/'seasons52r2-cleanup.json').read_text())['remaining_test_roots']==[]
targets=['internal/app/'+n for n in ['plugin_original_catalog_seasons.go','http.go','plugin_original_catalog_seasons_test.go','plugin_module_process_catalog_seasons_test.go','plugin_module_process_services_test.go']]+['web/src/components/'+n for n in ['MultiSeasonSubscribe.vue','Subscriptions.vue']]
paths={r/p for p in targets};paths.update((r/'testdata/standard-catalog-modules').glob('*seasons*'))
for pattern in ['seasons52*','platform52*.json','build-platform52*.py','run-seasons52*.py','archive-seasons52.py','*platform52*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.log','.py','.txt'] or 'before-http' in p.name:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/modules/themoviedb/__init__.py:1340-1352','app/chain/tmdb.py:216-230','app/api/endpoints/tmdb.py:70-83','app/api/endpoints/media.py:360-420','app/schemas/tmdb.py:TmdbSeason','src/components/dialog/SubscribeSeasonDialog.vue:95-110'],'targets':targets,'behavior':['Multi-season dialog fetches ordinary async_tmdb_seasons on opening. Native cache is inside fallback; source/clone None/list accumulation, false terminal, tuple conversion and exception continuation retained.','Exact seven nullable TmdbSeason fields preserve missing/null versus explicit empty string. Native missing/null season numbers filtered; zero remains.','The selection entry stays available for a TV series even when native recognition only has one season, allowing plugin-added seasons. Error remains in dialog with retry and disabled confirmation.'],'evidence':{'source_cases':12,'actual_sdk_initial_seconds':3.697,'final_all_catalog_seconds':36.071,'final_seasons_race_seconds':6.078,'web_tests':12,'web_build':'vue-tsc and production build passed','linux_cli_cases':9,'linux_cli_seconds':2.08,'linux_browser_gate_seconds':529.02,'browser':'IAB91 actual clone season2/season0/native1 ordering and 8/1/3 counts, selecting clone raises selected count to2; source9 fails with disabled confirmation while clone is not called; retry restores3 rows without new recognition; actual cold newPIDs0replay then browser calls each source/clone once; uninstall404 restores native only. No subscription submitted in this module-list acceptance.','manifest':str((dest/'manifest.json').relative_to(r)),'build':build},'adaptations':['Existing native /catalog/seasons route and response data envelope used; original module name/kwargs and DTO maintained.','Provider evidence uses controlled existing raw source-detail cache; SDK/main/browser are real processes. No live TMDB service claim.','Native source-detail cache is read as ProviderInfo.seasons to preserve full source DTO instead of lossy compact SeasonSummary.','Existing target selected-season editor and explicit retry remain; no external business writes from fixture.'],'failures_explained':['Initial compile collided with existing season projection name; renamed new helper only.','Initial actual Linux main52 found absent native fields became empty strings through compact SeasonSummary. Fixed production fallback to raw ProviderInfo and added real HTTP missing/null/explicit-empty regression; retained both red CLI/UI outputs.','Broader catalog regression requires existing catalog-opaque worker with four event handlers; final related run used that fixture.'],'remaining':['43:full197 method/199 ordinary source-call audit','50:final scope evidence audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-catalog-seasons-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';data=json.loads(p.read_text());data['catalog_seasons_52_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-catalog-seasons-20261028.json'};p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46；43选季增量main52r2已封存：普通async_tmdb_seasons→native原始缓存，完整7字段DTO保留null/空串区别；多季入口支持插件新季与第0季。固定12例、最终相关36.071s/race6.078s、12前端及构建通过；mainb586db58/teste2653f19的3745/4239输入稳定。Linux9例2.08s/IAB91门529.02s证实2→0→1顺序、选季、坏返回禁用确认、原窗重试不重识别、冷PID1072370/1072377→1081084/1081090零重放，卸载404恢复native。首轮Linux缺失字段误成空串已修且红证据保留，详validation/plugin-catalog-seasons-20261028.json。owned目录/进程/IAB91/34471已清理。继续43的197/199完整调用审计和50，无外部阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts;44/46 unchanged')
