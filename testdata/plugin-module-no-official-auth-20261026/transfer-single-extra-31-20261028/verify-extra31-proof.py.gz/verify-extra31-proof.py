import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'extra31-runtime'
def get(name):return json.loads((r/('extra31-browser-'+name+'.json')).read_text())
before,preview,failed,success,hpreview,hsuccess,audio,cold,physical=[get(n)for n in ['before','preview-failed','failed','subtitle-success','history-preview','history-success','audio-success','cold','final-physical']]
assert before['history']['total']==preview['history']['total']==0
assert failed['history']['total']==success['history']['total']==hpreview['history']['total']==hsuccess['history']['total']==1
history_id=failed['history']['items'][0]['id'];assert all(d['history']['items'][0]['id']==history_id for d in [success,hpreview,hsuccess])
assert failed['history']['items'][0]['status']=='failed' and failed['history']['items'][0]['error']=='owned single subtitle rejection'
assert all(d['history']['items'][0]['status']=='success'for d in [success,hpreview,hsuccess])
assert hpreview['history']==success['history'] and hpreview['files']==success['files']
assert hsuccess['history']['items'][0]['target']!=success['history']['items'][0]['target']
assert audio['history']==cold['history']==physical['history'] and audio['history']['total']==2
assert audio['files']==cold['files']==physical['files']
assert not physical['retired_subtitle']['exists'] and not physical['untransferred_main']['exists']
assert not physical['video_assets'] and not physical['asset_slots'] and not physical['reservations']
assert all(audio[k]['pid']!=cold[k]['pid']for k in ['source','clone'])
assert [audio[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[8,6]
assert [cold[k]['calls'].get('module_execute',0)for k in ['source','clone']]==[0,0]
for d in [success,hsuccess,audio,cold]:
 f={i['path']:i for i in d['files']}
 for h in d['history']['items']:
  assert h['status']=='success'
  assert {k:f[h['source']][k]for k in ['inode','device','size','sha256']}=={k:f[h['target']][k]for k in ['inode','device','size','sha256']}
 for p in d['active_plans']:assert len(p['files'])==1 and p['files'][0]['material_kind'] in ['subtitle','audio']
for name,count in [('01-preview-rejected-min10','总数 1 · 失败 1'),('02-actual-failure','总数 1 · 失败 1'),('03-preview-only-subtitle','总数 1 · 失败 0'),('07-audio-preview','总数 1 · 失败 0'),('08-cold-two-independent-histories','1 - 2 / 2')]:assert count in (b/'extra31-browser'/(name+'.dom.txt')).read_text()
result={'passed':True,'kind':'actual Linux browser/HTTP/SDK/filesystem/readonly SQLite observations','stable_subtitle_history_id':history_id,'pids':[[d[k]['pid']for k in ['source','clone']]for d in [audio,cold]],'independent_history_count':2,'post_cold_sdk_transfer_calls':0,'files':cold['files'],'min_filesize_mb':10,'no_main_publication_or_false_video_inventory':True}
(b/'extra31-browser-verdict.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='files'},ensure_ascii=False))
