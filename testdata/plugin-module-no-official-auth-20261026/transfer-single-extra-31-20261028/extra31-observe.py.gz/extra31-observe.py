import copy,hashlib,http.cookiejar,json,pathlib,sys,urllib.request
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module31-ui-state.json').read_text());mode=sys.argv[1]
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(method,path,body=None):
 data=json.dumps(body).encode() if body is not None else None
 with client.open(urllib.request.Request(s['origin']+path,data=data,headers={'Content-Type':'application/json'},method=method)) as response:return json.loads(response.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
active=r/'extra31-browser-active.json'
if active.exists():s.update(json.loads(active.read_text()))
s['active_name']='OwnedUITransfer'
if mode in ['prepare-failure','restore']:
 cfg=copy.deepcopy(s['source_config']);cfg['modules']={'recognize_media':'module_search_media','transfer':'module_execute'};cfg['result']=None
 cfg.pop('build_transfer_info',None);cfg.pop('transfer_results',None);cfg.pop('transfer_targets',None)
 if mode=='prepare-failure':cfg['transfer_results']={s['related_sources'][0]:{'__plugin_transfer_info':{'success':False,'message':'owned single subtitle rejection'}}}
 assert req('PUT','/api/plugins/'+s['source'],cfg)['data']['success']
 assert req('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{'transfer':'module_execute'},'result':None})['data']['success']
 print('prepared standalone '+mode)
def file(path):
 p=pathlib.Path(path)
 if not p.is_file():return {'path':path,'exists':False}
 st=p.stat();return {'path':path,'exists':True,'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
history=req('GET','/api/history/transfers?q='+s.get('active_name','OwnedUITransfer'))['data']
proof={'mode':mode,'history':history,'plans':req('GET','/api/import/plans')['data'],'jobs':req('GET','/api/jobs')['data'],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'files':[file(p)for p in [s['ui_plan']['files'][0]['source']]+s['related_sources']+list({x['target']for x in history['items'] if x['target']})]}
plans=[p for p in proof['plans']if any(f['source']in s['related_sources']for f in p['files'])]
ids={p['id']for p in plans}
proof['active_plans']=plans
proof['job_details']=[req('GET','/api/jobs/'+j['id'])['data']for j in proof['jobs']if j.get('kind')=='import' and j.get('payload',{}).get('id')in ids]
(r/('extra31-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'histories':history['total'],'source_pid':proof['source']['pid'],'clone_pid':proof['clone']['pid'],'source_transfer':proof['source']['calls'].get('module_execute',0),'clone_transfer':proof['clone']['calls'].get('module_execute',0)})

if mode=='final-physical':
 import sqlite3
 old=json.loads((r/'extra31-browser-subtitle-success.json').read_text())['history']['items'][0]['target']
 proof['retired_subtitle']=file(old)
 proof['untransferred_main']=file(s['ui_plan']['files'][0]['target'])
 db=sqlite3.connect('file:'+s['data_dir']+'/light-media.db?mode=ro',uri=True)
 proof['video_assets']=[json.loads(row[0])for row in db.execute("SELECT payload FROM records WHERE kind='asset'") if json.loads(row[0]).get('media',{}).get('id')==90001799]
 proof['asset_slots']=list(db.execute("SELECT * FROM asset_slots WHERE media_key LIKE '%90001799%'"))
 proof['reservations']=list(db.execute("SELECT * FROM reservations WHERE media_key LIKE '%90001799%'"))
 db.close()
 assert not proof['retired_subtitle']['exists'] and not proof['untransferred_main']['exists']
 assert not proof['video_assets'] and not proof['asset_slots'] and not proof['reservations']
 (r/('extra31-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
 print('old subtitle removed; main absent; no video inventory or reservation')
