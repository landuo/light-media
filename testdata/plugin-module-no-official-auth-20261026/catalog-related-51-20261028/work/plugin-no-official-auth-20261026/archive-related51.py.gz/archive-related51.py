import gzip,hashlib,json,subprocess
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';remote=w/'related51-remote';dest=r/'testdata/plugin-module-no-official-auth-20261026/catalog-related-51-20261028'
sha=lambda b:hashlib.sha256(b).hexdigest();build=json.loads((w/'platform51-result.json').read_text())
for b in build['binaries']:
 assert sha((w/b['name']).read_bytes())==b['sha256']
 for p,h in json.loads((w/(b['name']+'.inputs.json')).read_text()).items():assert Path(p).is_file()and sha(Path(p).read_bytes())==h,p
for p,seconds in [(w/'related51-related-r2.log','32.493s'),(w/'related51-race.log','5.757s'),(remote/'related51-cli.log','2.17s'),(remote/'related51-ui.log','245.08s')]:assert seconds in p.read_text()and ('PASS' in p.read_text()or 'ok  ' in p.read_text())
for p,h in json.loads((w/'related51-web-inputs.json').read_text()).items():assert sha((r/p).read_bytes())==h,p
browser={n:json.loads((remote/('related51-browser-'+n+'.json')).read_text())for n in ['loaded','invalid','failed','restore','restored','cold','final']}
for method in ['module_execute','module_page_size']:
 assert browser['failed']['source']['body']['calls'][method]==browser['invalid']['source']['body']['calls'][method]+1
 assert browser['failed']['clone']['body']['calls'][method]==browser['invalid']['clone']['body']['calls'][method]
 for k in ['source','clone']:
  assert browser['cold'][k]['body']['pid']!=browser['restored'][k]['body']['pid']
  assert browser['cold'][k]['body']['calls'].get(method,0)==0
  assert browser['final'][k]['body']['calls'][method]==1
  assert json.loads(browser['final'][k]['body']['inputs'][method])['kwargs']['tmdbid']==120 if isinstance(browser['final'][k]['body']['inputs'][method],str) else browser['final'][k]['body']['inputs'][method]['kwargs']['tmdbid']==120
assert browser['restored']['source']['body']['calls']['module_search_media']==browser['failed']['source']['body']['calls']['module_search_media']
assert json.loads((remote/'related51-cleanup.json').read_text())['remaining_test_roots']==[]
targets=['internal/app/'+n for n in ['plugin_original_catalog_related.go','http.go','plugin_original_catalog_related_test.go','plugin_module_process_catalog_related_test.go','plugin_module_process_services_test.go']]+['web/src/components/'+n for n in ['Catalog.vue','ExploreDetail.vue','CatalogRelated.vue']]
paths={r/p for p in targets}
paths.update((r/'testdata/standard-catalog-modules').glob('*related*'))
for pattern in ['related51-*','platform51*.json','build-platform51.py','run-related51.py','archive-related51.py','*platform51*.inputs.json']:
 for p in w.glob(pattern):
  if p.is_dir():paths.update(q for q in p.rglob('*')if q.is_file())
  elif p.suffix in ['.json','.log','.py','.txt']:paths.add(p)
artifacts=[]
for p in sorted(paths):
 raw=p.read_bytes();out=dest/p.relative_to(r);stored=raw
 if p.suffix!='.png':out=Path(str(out)+'.gz');stored=gzip.compress(raw,mtime=0)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(stored);artifacts.append(dict(original=str(p.relative_to(r)),path=str(out.relative_to(r)),sha256=sha(raw),stored_sha256=sha(stored)))
(dest/'manifest.json').write_text(json.dumps({'build':build,'artifacts':artifacts},indent=2)+'\n')
report={'accepted_increment':True,'whole_indices_accepted':False,'indices':[43],'fixed_backend':'8a83efeacd3e26b82be495e17d50146e31c96a60','fixed_frontend':'2829e3b08214348f05ff2f5beae644882eccad58','source':['app/chain/tmdb.py:262-285','app/chain/douban.py:194-221','app/chain/bangumi.py:81-93','app/api/endpoints/tmdb.py:108-171','app/api/endpoints/douban.py:45-85','app/api/endpoints/bangumi.py:13-52','src/views/discover/MediaDetailView.vue:1032-1085','src/views/discover/PersonCardSlideView.vue:29-55','src/views/discover/MediaCardSlideView.vue'],'targets':targets,'behavior':['Two independent lazy related requests after recognition, selected by resolved tmdb_id then douban_id then bangumi_id, not requested route source.','Native cache is inside module fallback. Source/clone None/list accumulation, false cutoff, exception continuation, invalid result and Bangumi final20 slice preserve source behavior. Douban credits False raises response validation unlike TMDB empty list.','Both native Catalog and ExploreDetail use existing media cards and actor buttons; one section error does not remove hero or successful sibling. Stop/reload/uninstall use existing runtime.'],'evidence':{'source_cases':16,'actual_sdk_seconds':4.673,'related_seconds':32.493,'race_seconds':5.757,'web_tests':24,'web_build':'vue-tsc and production build passed','linux_cli_seconds':2.17,'linux_browser_gate_seconds':245.08,'browser':'IAB90 actual clone/native list order; two explicit errors retain hero; separate retry restores each without re-recognition; actual cold newPIDs0replay, existing browser session on douban999 route uses recognizedTMDB120 and source+clone once per section; uninstall404 restores native actor.','manifest':str((dest/'manifest.json').relative_to(r)),'build':build},'adaptations':['Existing native cached catalog data remains the concrete provider for fallback; controlled cache seeds are synthetic provider evidence, actual server/SDK/browser are Linux real execution. No remote-provider availability claim.','Existing detail views now call native /catalog/detail/credits and recommendations rather than source per-provider URLs; exact module names and kwargs are retained.','Existing explicit retry behavior retained; source lazy cards log errors and retry on reactivation. No main detail failure on related errors.','Existing compact native CastMember is projected to full source MediaPerson defaults; plugin raw returned models preserve source DTO fields. Native cache may not contain source-specific fields that existing host never fetched.','Fixed source frontend has no AniList-related card; existing native AniList rendering remains without adding an independent AniList related business subsystem.'],'failures_explained':['Source AST harness initially lacked BaseModel binding; fixed harness only.','First broad catalog regression selected transfer fixture without four catalog event handlers. Reran unchanged production code with existing catalog-opaque worker; all related catalog tests passed.'],'remaining':['43:existing selection dialog seasons bypass async_tmdb_seasons; continue source+host audit,197methods/199ordinarycalls','50:final scope evidence audit'],'delivery':{'branch':'dev/plugins-continuation','committed':False,'pushed':False,'deployed':False}}
(r/'docs/validation/plugin-catalog-related-20261028.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
p=r/'docs/validation/plugin-module-no-official-auth-20261026.json';data=json.loads(p.read_text());data['catalog_related_51_increment']={'accepted_increment':True,'whole_indices_accepted':False,'report':'docs/validation/plugin-catalog-related-20261028.json'};data['remaining']=[x for x in data['remaining']if x.get('index')not in [36,37]];p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
paragraph='44/46；43详情演员/推荐增量已封存：独立懒加载按识别TMDB→豆瓣→Bangumi ID取普通模块，缓存位于fallback内。固定16例/实际SDK4.673s、相关32.493s/race5.757s、24前端/构建通过；main2ba78846/testb51df378的3744/4236输入与前端清单稳定。Linux2.17s/IAB90门245.08s证实clone→native顺序、双错误保详情、分别重试不重识别、冷PID1043511/1043523→1048123/1048129且0重放；豆瓣999入口使用识别TMDB120，卸载404恢复native。详validation/plugin-catalog-related-20261028.json，owned目录/进程/IAB90/34470已清理。第43发现选季直接使用native seasons尚未经过async_tmdb_seasons，继续补接；197/199最终审计与50未完成，无外部阻塞，未提交推送部署。'
for n,marker in [('docs/plugin-module-continuation-20261025.md','### 2026-10-28 当前续接点'),('docs/plugin-module-parity-matrix.md','## 当前执行点')]:
 p=r/n;s=p.read_text();i=s.index(marker)+len(marker);j=s.index('\n\n',i)+2;k=s.index('\n\n',j);p.write_text(s[:j]+paragraph+s[k:])
print('Archived',len(artifacts),'artifacts;44/46 unchanged')
