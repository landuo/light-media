import json,pathlib,http.cookiejar,urllib.request,sys,hashlib
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module33-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
h=req('GET','/api/history/transfers?q=SingleMainRetry')['data'];assert h['total']==1 and h['items'][0]['status']=='success'
def file(p):
 p=pathlib.Path(p);st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
proof={'mode':mode,'history':h,'files':[file(h['items'][0][k])for k in ['source','target']],'plans':[p for p in req('GET','/api/import/plans')['data']if any(f['source']==h['items'][0]['source']for f in p['files'])],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot')}
(r/('retry33-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print({'mode':mode,'pids':[proof[k]['pid']for k in ['source','clone']],'calls':[proof[k]['calls'].get('module_execute',0)for k in ['source','clone']],'plan_states':[p['state']for p in proof['plans']]})
