import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'retry33-runtime'
a=json.loads((r/'retry33-browser-before.json').read_text());c=json.loads((r/'retry33-browser-cold.json').read_text())
assert a['history']==c['history'] and a['files']==c['files'] and a['plans']==c['plans']
assert a['history']['total']==1 and a['history']['items'][0]['status']=='success'
assert {p['state']for p in a['plans']}=={'preview','partial','complete'}
completed=next(p for p in a['plans']if p['state']=='complete');failed=next(p for p in a['plans']if p['state']=='partial')
assert completed['id']!=failed['id'] and completed['files'][0]['id']!=failed['files'][0]['id']
assert a['history']['items'][0]['plan_id']==completed['id']
for k in ['inode','device','size','sha256']:assert a['files'][0][k]==a['files'][1][k]
for k in ['source','clone']:assert a[k]['pid']!=c[k]['pid'] and c[k]['calls'].get('module_execute',0)==0
for name in ['01-actual-retry-result','02-cold-stable-main-history']:
 dom=(b/'retry33-browser'/(name+'.dom.txt')).read_text();assert '1 - 1 / 1' in dom and '成功' in dom and 'SingleMainRetry' in dom
result={'passed':True,'kind':'Browser observation of actual production-HTTP retry result, not a dedicated retry button','pids':[[d[k]['pid']for k in ['source','clone']]for d in [a,c]],'history_id':a['history']['items'][0]['id'],'failed_plan':failed['id'],'new_successful_plan':completed['id'],'cold_write_calls':0,'files':c['files']}
(b/'retry33-browser-verdict.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in result.items()if k!='files'})
