import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'reorganize35-runtime'
def read(n):return json.loads((r/('reorganize35r2-browser-'+n+'.json')).read_text())
s,x,c1,p,a,c=map(read,['setup','rejected','cold-before-retry','preview','complete','cold-reloaded'])
for d in [x,c1,p]:
 assert d['history']==s['history'] and d['files']==s['files']
 assert len([v for v in d['plans']if v['state']=='complete'])==1
assert x['source']['calls']['module_storage_delete']==1 and x['clone']['calls'].get('module_storage_delete',0)==0
assert a['files'][1].get('exists')is False
for i in [0,2,3,4,5]:assert a['files'][i]==s['files'][i]
assert a['history']['total']==3 and all(x['status']=='success'for x in a['history']['items'])
assert {x['id']for x in a['history']['items']}=={x['id']for x in s['history']['items']}
sources={x['path']:x for x in a['files']if x.get('exists')is not False}
for h,n in zip(a['history']['items'],a['new_files']):
 assert h['target']==n['path'] and n['path'].startswith(a['destination']+'/')
 for k in ['inode','device','size','sha256']:assert sources[h['source']][k]==n[k]
for d in [c1,c]:
 for who in ['source','clone']:
  for method in ['module_storage_delete','module_transfer','module_execute','transfer_event','module_search_media']:assert d[who]['calls'].get(method,0)==0
for who in ['source','clone']:
 assert len({d[who]['pid']for d in [s,c1,c]})==3
 assert a[who]['calls']['module_storage_delete']==1
 assert len(a[who]['transfer_events'])==3
 assert {e['data']['transferinfo']['target_item']['path']for e in a[who]['transfer_events']}=={h['target']for h in a['history']['items']}
assert c['history']==a['history'] and c['files']==a['files'] and c['new_files']==a['new_files']
for name in ['05-three-success-with-targets','06-cold-three-success-with-targets']:
 d=(b/'reorganize35r2-browser'/(name+'.dom.txt')).read_text();assert '1 - 3 / 3' in d and d.count('成功')>=3 and d.count('history-browser-again')>=3
assert '旧整理目标删除失败，未开始新的整理' in (b/'reorganize35r2-browser/03-delete-false-retained-form.dom.txt').read_text()
verdict={'passed':True,'kind':'Actual Linux host and IAB70, owned synthetic SDK media and local hardlink files','pids':[[d[k]['pid']for k in ['source','clone']]for d in [s,c1,c]],'history_ids':[h['id']for h in a['history']['items']],'native_history_targets':[h['target']for h in a['history']['items']],'old_files':a['files'],'new_files':a['new_files'],'cold_write_replay':0}
(b/'reorganize35-browser-verdict.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in verdict.items()if k not in ['old_files','new_files','native_history_targets']})
