import json,pathlib,http.cookiejar,urllib.request,sys,hashlib,time
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'transfer-module35-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
dest=pathlib.Path(s['target'])/'history-browser-again';dest.mkdir(exist_ok=True)
if mode=='setup':
 cfg=dict(s['source_config']);cfg['modules']={k:v for k,v in cfg['modules'].items()if k not in ['list_files','get_parent_item']}
 req('PUT','/api/plugins/'+s['source'],cfg)
 out=req('POST','/api/files/organize',{'paths':[s['ui_plan']['files'][0]['source']],'target_path':s['target'],'mode':'hardlink','scraping':False})['data'];assert out['submitted']==1,out
 job=out['items'][0]['job_id']
 for i in range(100):
  detail=req('GET','/api/jobs/'+job)['data']
  if detail['job']['state']in['succeeded','failed']:break
  time.sleep(.1)
 assert detail['job']['state']=='succeeded',detail
if mode in ['fail','restore']:
 cfg=dict(s['source_config']);cfg['modules']={'recognize_media':'module_search_media','obtain_images':'module_images','delete_file':'module_storage_delete'}
 cfg['result']=False if mode=='fail'else None;cfg['storage_root']=s['target'];cfg['storage_mode']='no_effect'
 req('PUT','/api/plugins/'+s['source'],cfg)
 req('PUT','/api/plugins/'+s['clone'],{'enabled':True,'modules':{'delete_file':'module_storage_delete'},'storage_root':s['target'],'storage_mode':'effect','result':True})
def file(p):
 if not p:return {"path":p,"exists":False,"absent_history_target":True}
 p=pathlib.Path(p)
 if not p.exists():return {'path':str(p),'exists':False}
 st=p.stat();return {'path':str(p),'inode':st.st_ino,'device':st.st_dev,'size':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
h=req('GET','/api/history/transfers?q=OwnedUITransfer')['data']
proof={'mode':mode,'history':h,'files':[file(p)for p in [s['ui_plan']['files'][0]['source'],s['expected_module_target']]+s['related_sources']+s['expected_related_targets']],'new_files':[file(x['target'])for x in h['items']],'destination':str(dest),'plans':[p for p in req('GET','/api/import/plans')['data']if any('OwnedUITransfer' in f['source']for f in p['files'])],'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot')}
(r/('reorganize35-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print({'mode':mode,'origin':s['origin'],'destination':str(dest),'pids':[proof[k]['pid']for k in ['source','clone']],'calls':[proof[k]['calls']for k in ['source','clone']],'histories':[(x['id'],x['status'],x['target'])for x in h['items']]})
