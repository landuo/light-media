import json,pathlib
b=pathlib.Path('work/plugin-no-official-auth-20261026');r=b/'scrape36-runtime'
def get(n):return json.loads((r/('scrape36-browser-'+n+'.json')).read_text())
p,f,cb,s,c=map(get,['preview','failed','cold-before','success','cold-after'])
for d in [p,f,cb]:assert len(d['target_files'])==0
assert len(f['history']['items'])==3 and all(x['status']=='failed'for x in f['history']['items'])
assert len(s['history']['items'])==3 and all(x['status']=='success'for x in s['history']['items'])
assert {x['id']for x in f['history']['items']}=={x['id']for x in s['history']['items']}
assert c['history']==s['history'] and c['target_files']==s['target_files'] and c['source_files']==s['source_files']
assert len(s['target_files'])==8
for h in s['history']['items']:
 src=next(x for x in s['source_files']if x['path']==h['source']);dst=next(x for x in s['target_files']if x['path']==h['target'])
 for k in ['inode','device','size','sha256']:assert src[k]==dst[k]
paths={x['target']for x in s['history']['items']}
for who in ['source','clone']:
 es=[x for x in s[who]['transfer_events']if x['type']=='metadata.scrape'];assert len(es)==1 and set(es[0]['data']['file_list'])==paths
 assert len(es[0]['data']['file_list'])==3 and es[0]['data']['overwrite'] is False
 assert len({d[who]['pid']for d in [p,cb,c]})==3
 for d in [cb,c]:
  assert not d[who].get('transfer_events')
  for method in ['module_execute','module_metadata_nfo','transfer_event']:assert not d[who]['calls'].get(method,0)
bs=[x for x in s['batches']if any(set(t['event']['file_list'])==paths for t in (x['targets']or []))]
assert len(bs)==1 and bs[0]['closed'] and bs[0]['flushed'] and len(bs[0]['targets'][0]['assets'])==3
js=[x for x in s['scrape_jobs']if set(x['payload'].get('original_metadata_event',{}).get('file_list',[]))==paths]
assert len(js)==1 and js[0]['state']=='succeeded'
for n in ['04-success-history','06-cold-history-loaded']:
 text=(b/'scrape36-browser'/(n+'.dom.txt')).read_text();assert '1 - 3 / 3'in text and text.count('成功')>=3
v={'passed':True,'kind':'Actual Linux main, local hardlinks and owned SDK, IAB71','history_ids':[x['id']for x in s['history']['items']],'target_files':s['target_files'],'pids':[[d[k]['pid']for k in ['source','clone']]for d in [p,cb,c]],'metadata_events_per_instance':1,'scrape_jobs_per_root':1,'cold_write_replay':0,'linux_cli_seconds':2.03,'linux_browser_gate_seconds':695.90}
(b/'scrape36-browser-verdict.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in v.items()if k!='target_files'})
