import gzip,hashlib,json
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';dest=r/'testdata/plugin-module-no-official-auth-20261026/platform-regression-54-20261029';sha=lambda b:hashlib.sha256(b).hexdigest()
def load(name):
 out=[]
 for line in (w/('final54-'+name+'.jsonl')).read_text().splitlines():
  try:out.append(json.loads(line))
  except:pass
 return out
passed=lambda rows:{x['Test'] for x in rows if x.get('Test')and '/'not in x['Test']and x['Action']=='pass'}
a,b,c=map(load,['platform','followup','repair']);roots=set(json.loads((w/'final54-platform-command.json').read_text())['command'][4][4:-2].split('|'));covered=passed(a)|passed(b)|passed(c)
assert not roots-covered
assert json.loads((w/'final54-repair-result.json').read_text())['exit_code']==0
assert json.loads((w/'final54-input-check.json').read_text())['changed']==[]
artifacts=[];paths=set()
for pattern in ['final54*']:
 for p in w.glob(pattern):
  if p.is_file()and p.suffix in ['.json','.jsonl','.log','.py']:paths.add(p)
paths.add(w/'run-final54.py');paths.add(w/'archive-final54.py')
for name in ['internal/app/plugin_notice_v2_proof.go','internal/app/plugin_original_web_history_proof_test.go','internal/app/plugin_standard_business_events_additional_test.go','cmd/owned-frontend-fixture/main.go','cmd/owned-transfer-events-fixture/main.go']:paths.add(r/name)
for p in sorted(paths):
 raw=p.read_bytes();out=Path(str(dest/p.relative_to(r))+'.gz');out.parent.mkdir(parents=True,exist_ok=True);stored=gzip.compress(raw,mtime=0);out.write_bytes(stored);artifacts.append({'original':str(p.relative_to(r)),'path':str(out.relative_to(r)),'sha256':sha(raw),'stored_sha256':sha(stored)})
(dest/'manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n')
report={'accepted_regression':True,'whole_module_accepted':False,'manifest':str((dest/'manifest.json').relative_to(r)),'evidence_type':'actual local App/HTTP/SQLite and separate Go SDK workers; not browser or Linux-process acceptance by itself','source_expected':'Each existing test refers to fixed source or sealed oracle; no assertion weakened to match implementation.','results':{'catalog':{'roots':len(passed(load('catalog'))),'seconds':59.546},'platform':{'selected_roots':len(roots),'initial_passed':len(passed(a)),'first_timeout_seconds':602.831,'followup_passed':len(passed(b)),'followup_seconds':61.919,'remaining_repair_roots':sorted(roots-(passed(a)|passed(b))),'repair_related_passed':len(passed(c)),'repair_seconds':12.863,'uncovered':sorted(roots-covered)},'sdk':{'root_tests':len(passed(load('sdk'))),'seconds':18.758,'test_skips':[x['Test']for x in load('sdk')if x.get('Test')and x['Action']=='skip'],'note':'internal/sourcejson has no standalone test files; consumers above exercise it.'},'frontend':{'tests':549,'seconds':6.081924,'superseded_by':'directory-transfer-types55 final556 frontend tests'}},'fixes':[{'location':'cmd/owned-frontend-fixture; cmd/owned-transfer-events-fixture','cause':'Broad regression inherited outdated fixtures without current Unicode and audio/directory storage behavior.','fix':'Rebuilt these exact existing fixture sources into new binaries; retained original failures and hash bindings; affected tests passed with production code unchanged.'},{'location':'internal/app/plugin_notice_v2_proof.go','cause':'Encrypted core history was authenticated but redacted public notification fields could be modified without invalidating the stored receipt.','fix':'Validate the immutable redacted projection while permitting independent Read state. Existing tamper test and related tests/race now pass.'},{'location':'internal/app/plugin_standard_business_events_additional_test.go','cause':'Old test omitted the fixed SiteUpdated consumer refresh introduced and independently accepted earlier.','fix':'Assert creation contributes exactly one numeric SiteRefreshed; explicit batch adds one numeric and one wildcard; rerunning same job adds none. No production event changed.'}],'binding':'Initial catalog/platform/sdk commands bind to final54-inputs and unchanged input check. Followup only refreshes fixture binaries. Repair binds the two listed changed files; types55 final Linux build includes the repaired production file. Historical evidence is not relabeled as a final full-suite rerun.'}
(r/'docs/validation/plugin-platform-regression-20261029.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(len(artifacts),'artifacts, all',len(roots),'selected platform roots covered; source-linked repair retained')
