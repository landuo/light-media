import hashlib,json,os,re,subprocess,time
from pathlib import Path
r=Path.cwd();w=r/'work/plugin-no-official-auth-20261026';env=os.environ|json.loads((w/'download-context-current-environment.json').read_text());env['TMPDIR']=str(w/'final54-tmp');Path(env['TMPDIR']).mkdir(exist_ok=True)
paths=[p for d in ['internal','cmd','testdata/standard-catalog-modules']for p in (r/d).rglob('*')if p.is_file()and p.suffix in ['.go','.json','.py','.mjs']]+[r/'go.mod',r/'go.sum'];snapshot={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths};(w/'final54-inputs.json').write_text(json.dumps(snapshot,indent=2)+'\n');results=[]
names={'catalog':[],'platform':[]}
for p in sorted((r/'internal/app').glob('*_test.go')):
 if p.name.startswith(('plugin_original','plugin_organization','plugin_standard','plugin_module_scope')):
  names['catalog'if p.name.startswith('plugin_original_catalog')else'platform']+=re.findall(r'^func (Test\w+)\(t \*testing.T\)',p.read_text(),re.M)
for group in ['catalog','platform','sdk']:
 worker=w/('catalog-opaque-worker-local'if group=='catalog'else'bluray44-worker-local');env['OWNED_MODULE_OVERRIDE_BINARY']=str(worker)
 cmd=['go','test','./internal/app','-run','^(?:'+'|'.join(sorted(set(names[group])))+')$','-count=1','-json']if group!='sdk'else['go','test','./internal/plugins','./internal/plugins/artifacts','./internal/plugins/schedule','./internal/sourcejson','./internal/networkproxy','-count=1','-json']
 record={'group':group,'command':cmd,'selected_roots':len(set(names.get(group,[]))),'fixture':str(worker),'fixture_sha256':hashlib.sha256(worker.read_bytes()).hexdigest()};(w/('final54-'+group+'-command.json')).write_text(json.dumps(record,indent=2)+'\n')
 start=time.monotonic()
 with(w/('final54-'+group+'.jsonl')).open('w')as f:code=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 record.update(exit_code=code,seconds=round(time.monotonic()-start,3));results.append(record);(w/'final54-results.json').write_text(json.dumps(results,indent=2)+'\n');print(group,code,record['seconds'],flush=True)
 # Preserve failures and still execute independent groups, do not reinterpret skips.
changed=[p for p,h in snapshot.items()if not (r/p).is_file()or hashlib.sha256((r/p).read_bytes()).hexdigest()!=h];(w/'final54-input-check.json').write_text(json.dumps({'changed':changed})+'\n');raise SystemExit(1 if changed or any(x['exit_code']for x in results)else 0)
