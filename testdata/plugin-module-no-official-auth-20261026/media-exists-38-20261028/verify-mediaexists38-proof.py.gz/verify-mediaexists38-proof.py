from pathlib import Path
import json
root=Path('work/plugin-no-official-auth-20261026');p=root/'mediaexists38-runtime'
def read(n):return json.loads((p/('mediaexists38-browser-'+n+'.json')).read_text())
initial,false0,false1,invalid0,invalid1,retry,cold0,cold1=map(read,['initial','false','false-after','invalid','invalid-after','retry-after','cold-before','cold-after'])
def sub(v):
 assert len(v['subscriptions']['items'])==1
 return v['subscriptions']['items'][0]
identity=sub(initial)['id']
for v in [initial,false0,false1,invalid0,invalid1,retry,cold0,cold1]:
 assert sub(v)['id']==identity
 assert v['records']=={'asset':0,'intent':0,'subscription_history':1,'source_subscribe_complete':1}and v['slots']==0
assert [sub(v)['lack_episode']for v in [initial,false1,invalid1,retry,cold1]]==[1,3,3,1,1]
assert false1['source']['calls']['module_execute']-false0['source']['calls']['module_execute']==1
assert false1['clone']['calls']['module_execute']==false0['clone']['calls']['module_execute']
failed=max((j for j in invalid1['jobs']if j['kind']=='subscription'and j['state']=='failed'),key=lambda x:x['created_at'])
assert failed['error_code']=='PLUGIN_MEDIA_EXISTS_INVALID'
retried=next(j for j in retry['jobs']if j['id']==failed['id'])
assert retried['state']=='succeeded'and retried['generation']>failed['generation']
for k in ['source','clone']:
 assert retry[k]['pid']!=cold1[k]['pid']
 assert cold0[k]['pid']==cold1[k]['pid']
 assert cold1[k]['calls'].get('module_execute',0)==0
 assert cold1[k]['calls'].get('module_page_size',0)==0
assert retry['main_pid']!=cold1['main_pid']
for name,text in [('01-initial','已下载 2 / 3'),('02-false','已下载 0 / 3'),('03-invalid-job','插件媒体存在信息缺少有效的季集对象'),('04-retry-restored','已下载 2 / 3'),('05-cold-loaded','已下载 2 / 3')]:
 assert text in (root/'mediaexists38r4-browser'/(name+'.dom.txt')).read_text()
aria=(root/'mediaexists38r5-browser/01-final-download-progress.dom.txt').read_text()
assert '下载进度' in aria and '已下载 2 / 3'in aria and '入库进度'not in aria
versions=json.loads((root/'mediaexists38-r4-r5-input-comparison.json').read_text());assert versions['backend_inputs_unchanged']
proof={'passed':True,'kind':'Actual main + IAB74 full flow; IAB75 final ARIA-only delta','subscription':identity,'displayed_downloaded':[2,0,0,2,2],'total':3,'retry_same_job':failed['id'],'pids_before':[retry['main_pid'][0],retry['source']['pid'],retry['clone']['pid']],'pids_after':[cold1['main_pid'][0],cold1['source']['pid'],cold1['clone']['pid']],'cold_module_replay':0,'assets_slots_intents':0,'existing_completed_history_and_event':1,'r4_cli_seconds':2.93,'r4_browser_gate_seconds':585.53,'r5_browser_gate_seconds':229.50,'r4_r5_backend_inputs_unchanged':True}
(root/'mediaexists38-browser-verdict.json').write_text(json.dumps(proof,indent=2)+'\n');print(proof)
