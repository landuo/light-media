from pathlib import Path
import subprocess,tarfile,io
root=Path('work/plugin-no-official-auth-20261026/mediaexists38-runtime');root.mkdir(exist_ok=True)
cmd=['ssh','-o','BatchMode=yes','-i','/Users/accidia/.ssh/ssh.pem','-p','20014','root@202.189.12.139','python3 -']
script='''import pathlib,tarfile,sys
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A')
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|')as tar:
 for p in sorted(r.glob('mediaexists38*')):
  if p.is_dir() and p.name.endswith('-evidence'):
   for f in sorted(p.rglob('*')):
    if f.is_file():tar.add(f,arcname=str(f.relative_to(r)),recursive=False)
  elif p.is_file() and p.suffix in ['.log','.json']:tar.add(p,arcname=p.name,recursive=False)
'''
output=subprocess.check_output(cmd,input=script.encode())
with tarfile.open(fileobj=io.BytesIO(output))as t:t.extractall(root,filter='data')
print('downloaded',len([p for p in root.rglob('*')if p.is_file()]),'files')
