import json,pathlib,http.cookiejar,urllib.request,sqlite3,sys
r=pathlib.Path('/tmp/light-media-plugin-scope-dRZTQ91A');s=json.loads((r/'mediaexists38r5-ui-state.json').read_text());mode=sys.argv[1]
c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(m,p,b=None):
 with c.open(urllib.request.Request(s['origin']+p,data=json.dumps(b).encode()if b is not None else None,headers={'Content-Type':'application/json'},method=m))as x:return json.loads(x.read())
req('POST','/api/auth/login',{'username':'service-acceptance','password':'owned-service-browser-password'})
if mode in ['false','restore']:
 cfg=dict(s['source_config']);cfg['result']=False if mode=='false'else None;req('PUT','/api/plugins/'+s['source'],cfg)
if mode in ['invalid','restore','complete']:
 cfg=dict(s['clone_config'])
 cfg['result']={'seasons':None}if mode=='invalid'else {'type':'电视剧','seasons':{'1':[1,2,3]if mode=='complete'else[1,3]}}
 req('PUT','/api/plugins/'+s['clone'],cfg)
proof={'mode':mode,'source':req('GET','/api/v1/plugin/'+s['source']+'/snapshot'),'clone':req('GET','/api/v1/plugin/'+s['clone']+'/snapshot'),'subscriptions':req('GET','/api/subscriptions')['data'],'jobs':req('GET','/api/jobs')['data']}
db=sqlite3.connect('file:'+str(pathlib.Path(s['data_dir'])/'light-media.db')+'?mode=ro',uri=True)
proof['records']={kind:db.execute('SELECT count(*) FROM records WHERE kind=?',(kind,)).fetchone()[0]for kind in ['asset','intent','subscription_history','source_subscribe_complete']}
proof['slots']=db.execute('SELECT count(*) FROM asset_slots').fetchone()[0];db.close()
proof['main_pid']=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  command=(p/'cmdline').read_bytes().split(b'\0')
  if command and b'server-platform38r5-'in command[0]and s['data_dir'].encode()in command:proof['main_pid'].append(int(p.name))
 except OSError:pass
(r/('mediaexists38r5-browser-'+mode+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print({'mode':mode,'pids':[proof['main_pid'],proof['source']['pid'],proof['clone']['pid']],'subscriptions':[(x['id'],x.get('lack_episode'))for x in proof['subscriptions']['items']],'records':proof['records'],'slots':proof['slots']})
