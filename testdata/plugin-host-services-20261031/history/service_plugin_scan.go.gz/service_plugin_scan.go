package fnos

import "context"

// ScanRoot is an explicit whole-library request. Scan retains its existing
// strict-child contract. Roots come only from a fresh authenticated library
// listing; callers cannot provide a replacement root or an arbitrary GUID.
// Success means the server accepted a scan, never that indexing completed.
func (s *Service) ScanRoot(ctx context.Context, libraryGUID string, before func() error) ([]string, error) {
	if !detailGUID.MatchString(libraryGUID) {
		return nil, &ServiceError{Code: "invalid_input"}
	}
	current, err := s.session(ctx)
	if err != nil {
		return nil, err
	}
	if !current.admin {
		return nil, &ServiceError{Code: "unauthorized"}
	}
	libraries, err := current.libraries(ctx)
	if err != nil {
		return nil, err
	}
	library, found := serviceLibrary(libraries, libraryGUID)
	if !found || len(library.Directories) == 0 {
		return nil, &ServiceError{Code: "invalid_input"}
	}
	for _, dir := range library.Directories {
		if !servicePath(dir, false) {
			return nil, &ServiceError{Code: "invalid_input"}
		}
	}
	if before != nil {
		if err := before(); err != nil {
			return nil, err
		}
	}
	if err = current.call(ctx, "/mdb/scan/"+libraryGUID, map[string][]string{"dir_list": library.Directories}, "", nil); err != nil {
		return nil, err
	}
	return append([]string{}, library.Directories...), nil
}
