package fnos

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"reflect"
	"testing"
)

func TestPluginExplicitRootScanKeepsOrdinaryStrictChildBoundary(t *testing.T) {
	var calls int
	adapter := testService(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/v/api/v1/mdb/scan/"+serviceLibGUID || r.Method != "POST" {
			t.Fatal("unexpected scan endpoint", r.URL.Path)
		}
		var input struct {
			Directories []string `json:"dir_list"`
		}
		if json.NewDecoder(r.Body).Decode(&input) != nil || !reflect.DeepEqual(input.Directories, []string{"/vol2/media"}) {
			t.Fatal("fresh configured library roots", input)
		}
		calls++
		fmt.Fprint(w, `{"code":0,"data":null}`)
	})
	if err := adapter.Scan(context.Background(), serviceLibGUID, "/vol2/media"); err == nil {
		t.Fatal("ordinary scan's strict-child policy changed")
	}
	paths, err := adapter.ScanRoot(context.Background(), serviceLibGUID, nil)
	if err != nil || !reflect.DeepEqual(paths, []string{"/vol2/media"}) || calls != 1 {
		t.Fatal("explicit root scan", paths, err, calls)
	}
	denied := errors.New("revoked invocation")
	_, err = adapter.ScanRoot(context.Background(), serviceLibGUID, func() error { return denied })
	if !errors.Is(err, denied) || calls != 1 {
		t.Fatal("revoked scan executed", err, calls)
	}
	_, err = adapter.ScanRoot(context.Background(), serviceMovieGUID, nil)
	if err == nil || calls != 1 {
		t.Fatal("unconfigured library accepted", err, calls)
	}
}
