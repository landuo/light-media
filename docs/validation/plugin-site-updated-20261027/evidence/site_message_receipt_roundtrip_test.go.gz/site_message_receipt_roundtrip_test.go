package app

import (
	"context"
	"testing"

	"light-media/internal/sites"
)

func TestSiteMessageReceiptStillReadableAfterNullableDTOAdaptation(t *testing.T) {
	a := newTestApp(t)
	siteMessageOwnedFIFOSender(t, a)
	ctx := context.Background()
	job := siteMessageClaimBatch(t, a)
	r := siteMessageSeedCollectedDTO(t, a, job, "nullable-receipt", &sites.SourceUserData{MessageUnread: 1, Messages: [][]any{{"head", "date", "body"}}})
	stored, err := a.pluginStore.readSiteMessageCollection(ctx, a.Store.DB, r.ID)
	if err != nil {
		t.Fatal("source collection roundtrip", err)
	}
	stored.Steps[0].Business, err = siteMessageBusinessAt(stored.Name, stored.URL, stored.Snapshot, stored.Steps[0])
	if err != nil {
		t.Fatal(err)
	}
	stored.Steps[0].State = "routing"
	tx, err := a.Store.DB.BeginTx(ctx, nil)
	if err != nil {
		t.Fatal(err)
	}
	if err = a.pluginStore.saveSiteMessageCollection(ctx, tx, stored); err != nil {
		tx.Rollback()
		t.Fatal(err)
	}
	if err = tx.Commit(); err != nil {
		t.Fatal(err)
	}
	identity := siteMessageIdentity{r.ID, 0}
	route, err := a.initSiteMessageNotice(ctx, identity, stored.Steps[0].Business)
	if err != nil {
		t.Fatal("init existing site notice", err)
	}
	initial, _, err := a.pluginStore.readNoticeRoute(ctx, a.Store.DB, route)
	if err != nil {
		t.Fatal("existing site notice roundtrip before routing", err)
	}
	if err = a.requireNoticeV2Execution(ctx, initial); err != nil {
		t.Fatal("existing site notice execution grant", err)
	}
	if err = a.runNoticeRoute(ctx, route); err != nil {
		current, steps, readErr := a.pluginStore.readNoticeRoute(ctx, a.Store.DB, route)
		kinds := []string{}
		for _, step := range steps {
			kinds = append(kinds, step.Kind)
		}
		t.Log("route diagnostic", current.Count, current.Complete, current.SourceError, kinds, readErr)
		t.Fatal("existing site notice routing", err)
	}
}
