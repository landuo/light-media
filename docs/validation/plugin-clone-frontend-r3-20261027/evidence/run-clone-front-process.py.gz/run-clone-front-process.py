import subprocess,pathlib
w=pathlib.Path('work/plugin-no-official-auth-20261026');remote='/tmp/light-media-plugin-scope-dRZTQ91A'
files=[w/n for n in ['clone-front-process-linux','clone-front-process-v2-linux','clone-front-exact-process-linux','clone-front-process-linux.test']]
p=subprocess.run(['scp','-q','-i','/Users/accidia/.ssh/ssh.pem','-P','20014',*[str(p) for p in files],f'root@202.189.12.139:{remote}/'])
if p.returncode:raise SystemExit(p.returncode)
base=f'TMPDIR={remote}/tmp PLUGIN_PROCESS_SERVER_BINARY={remote}/server-platform3-20261027-linux UI3133_PROCESS_RESOURCE_WATCH_ONLY=true UI3133_PROCESS_FIXTURE_BINARY={remote}/ui3133-fixture-linux UI3133_PROCESS_V2_FIXTURE_BINARY={remote}/ui3133-fixture-v2-linux UI3133_PROCESS_FRONTEND_DIR={remote}/ui3133-ui OWNED_FRONTEND_PROCESS_FIXTURE_BINARY={remote}/clone-front-process-linux OWNED_FRONTEND_PROCESS_FIXTURE_BINARY_V2={remote}/clone-front-process-v2-linux OWNED_FRONTEND_EXACT_PROCESS_FIXTURE_BINARY={remote}/clone-front-exact-process-linux'
# Filenames are derived from parent-provided prior UI hold assets, no new server.
for dev in ['false','true']:
 with (w/f'clone-front-process-{dev}.log').open('w') as log:
  cmd=f'{base} CLONE_FRONTEND_PROCESS_DEV={dev} {remote}/clone-front-process-linux.test -test.run=^TestPluginUI3133ProductionCLI$ -test.v -test.timeout=3m'
  p=subprocess.run(['ssh','-o','BatchMode=yes','-i','/Users/accidia/.ssh/ssh.pem','-p','20014','root@202.189.12.139',cmd],stdout=log,stderr=subprocess.STDOUT)
 print(dev,p.returncode,flush=True)
 if p.returncode:break
